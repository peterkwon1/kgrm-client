<template>
   <div id="app">

    <header class="sticky-header d-flex bg-transparent flex-wrap align-items-center justify-content-between py-2 sticky-top">
<b-button type="button" class="btn btn-sm btn-link" id="back-arrow"  onclick="location.href='/main/home'">
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
    <path d="M20 12.75C20.4142 12.75 20.75 12.4142 20.75 12C20.75 11.5858 20.4142 11.25 20 11.25V12.75ZM4 11.25C3.58579 11.25 3.25 11.5858 3.25 12C3.25 12.4142 3.58579 12.75 4 12.75V11.25ZM20 11.25L4 11.25V12.75L20 12.75V11.25Z" />
    <path d="M10.5303 6.53033C10.8232 6.23744 10.8232 5.76256 10.5303 5.46967C10.2374 5.17678 9.76256 5.17678 9.46967 5.46967L10.5303 6.53033ZM4 12L3.46967 11.4697C3.17678 11.7626 3.17678 12.2374 3.46967 12.5303L4 12ZM9.46967 18.5303C9.76256 18.8232 10.2374 18.8232 10.5303 18.5303C10.8232 18.2374 10.8232 17.7626 10.5303 17.4697L9.46967 18.5303ZM9.46967 5.46967L3.46967 11.4697L4.53033 12.5303L10.5303 6.53033L9.46967 5.46967ZM3.46967 12.5303L9.46967 18.5303L10.5303 17.4697L4.53033 11.4697L3.46967 12.5303Z"  />
  </svg>
</b-button>
<ul class="nav nav-pills">
  <li class="nav-item">
    <b-button type="button" class="btn btn-sm btn-link" id="right" >
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
        <path d="M9 6L12 3M12 3L15 6M12 3L12 15"   stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M7.5 9L7 9C4.79086 9 3 10.7909 3 13L3 17C3 19.2091 4.79086 21 7 21L17 21C19.2091 21 21 19.2091 21 17L21 13C21 10.7909 19.2091 9 17 9L16.5 9"   stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </b-button>
  </li>
  <li class="nav-item">
    <b-button type="button" class="btn btn-sm btn-link" data-bs-toggle="button" id="right2">
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
        <path d="M9.5054 7.93631L12 2.90354L14.4946 7.93631C14.6957 8.34211 15.0837 8.62187 15.5306 8.68653L21.102 9.4926L17.0727 13.4032C16.7479 13.7185 16.5989 14.1737 16.6759 14.6205L17.6278 20.1465L12.6392 17.5352C12.2389 17.3257 11.7611 17.3257 11.3608 17.5352L6.37222 20.1465L7.32411 14.6205C7.40109 14.1737 7.25208 13.7185 6.92727 13.4032L2.89797 9.4926L8.46937 8.68653C8.91633 8.62187 9.30425 8.34211 9.5054 7.93631ZM21.2879 9.31222L21.2877 9.31244L21.2879 9.31222Z"   stroke-width="1.5"/>
      </svg>
    </b-button>

  </li>
</ul>
</header>
  
  
<!--content s-->
<div class="container position-absolute pb-6 top-0">
  <b-carousel
  id="carousel-fade"
    style="text-shadow: 0px 0px 2px #000; margin-bottom:2rem"
    fade
    indicators
    img-width="1024"
    img-height="480"
  >
    <b-carousel-slide
      caption=""
      img-src="https://cdn.pixabay.com/photo/2017/03/22/17/39/kitchen-2165756__340.jpg"
    ></b-carousel-slide>
    <b-carousel-slide
      caption=""
      img-src="https://cdn.pixabay.com/photo/2017/03/19/01/43/living-room-2155376__340.jpg"
    ></b-carousel-slide>
    <b-carousel-slide
      caption=""
      img-src="https://cdn.pixabay.com/photo/2017/03/28/12/11/chairs-2181960__340.jpg"
    ></b-carousel-slide>
  </b-carousel>
 


  <section>
  <div class="detail_title">
<p class="body2 light_txt_lgrey">최초 등록일 2022.09.19<span class="line-grey"></span>최근 수정일 2022.09.22</p>
    <span class="label-outline-circle-main">월세</span>
    <h3>보증금 <strong>1000</strong><span class="detail_title_slash"></span>월세 <strong>60</strong></h3>
  </div>
</section>



  <section class="detail_section">
    <div class="option_info">
      <ul>
        <li>
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
            <g clip-path="url(#clip0_3416_44128)">
              <path d="M21 22H3V10.9103L11.8785 3L21.0011 11.1276V21.999L21 22ZM3.84861 21.1763H20.1514V11.49L11.8785 4.11813L3.84861 11.2727V21.1763Z" fill="black"/>
              <path d="M11.9868 11.735C11.712 11.735 11.4871 11.6516 11.31 11.4838C11.1339 11.316 11.0448 11.1152 11.0448 10.8784C11.0448 10.6416 11.1328 10.4316 11.31 10.2679C11.4861 10.1042 11.712 10.0228 11.9868 10.0228C12.2615 10.0228 12.4864 10.1011 12.6635 10.2565C12.8396 10.413 12.9287 10.6087 12.9287 10.8444C12.9287 11.0957 12.8428 11.3067 12.6699 11.4776C12.497 11.6485 12.27 11.735 11.9878 11.735H11.9868ZM11.2453 18.8371V12.7399H12.7155V18.8371H11.2453Z" fill="black"/>
            </g>
            <defs>
              <clipPath id="clip0_3416_44128">
                <rect width="18" height="19" fill="white" transform="translate(3 3)"/>
              </clipPath>
            </defs>
          </svg>
          <p class="body2 light_txt_grey">오픈형 원룸
            (욕실1개)</p>
        </li>
        <li>
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
            <g clip-path="url(#clip0_3416_44117)">
              <path d="M16.0536 21H3.03131V7.92938H16.0536V21ZM3.83889 20.1894H15.246V8.73996H3.83889V20.1894V20.1894Z" fill="black"/>
              <path d="M21 20.155H17.269V20.9656H21V20.155Z" fill="black"/>
              <path d="M20.8991 7.8949H17.168V8.70548H20.8991V7.8949Z" fill="black"/>
              <path d="M19.4878 8.38531H18.6802V20.5947H19.4878V8.38531Z" fill="black"/>
              <path d="M3.80758 3.10132H3V6.84621H3.80758V3.10132Z" fill="black"/>
              <path d="M16.0222 3H15.2147V6.74489H16.0222V3Z" fill="black"/>
              <path d="M15.5337 4.51782H3.36945V5.3284H15.5337V4.51782Z" fill="black"/>
              <path d="M9.69387 14.6167H3.03131V7.92938H9.69387V14.6167ZM3.83889 13.8061H8.88628V8.73996H3.83889V13.8061V13.8061Z" fill="black"/>
            </g>
            <defs>
              <clipPath id="clip0_3416_44117">
                <rect width="18" height="18" fill="white" transform="translate(3 3)"/>
              </clipPath>
            </defs>
          </svg>
          <p class="body2 light_txt_grey">전용 23.14㎡</p>
        </li>
        <li>
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
            <g clip-path="url(#clip0_3416_44124)">
              <path d="M14.9368 8.16756H4V3.09888H14.9368V8.16756ZM4.8027 7.37635H14.1341V3.89009H4.8027V7.37635Z" fill="black"/>
              <path d="M14.9368 12.4451H4V7.3764H14.9368V12.4451ZM4.8027 11.6539H14.1341V8.16761H4.8027V11.6539Z" fill="black"/>
              <path d="M14.9368 16.7226H4V11.6539H14.9368V16.7226ZM4.8027 15.9313H14.1341V12.4451H4.8027V15.9313Z" fill="black"/>
              <path d="M14.9368 21H4V15.9313H14.9368V21ZM4.8027 20.2088H14.1341V16.7225H4.8027V20.2088Z" fill="black"/>
              <path d="M20.1042 20.1554H16.3958V20.9466H20.1042V20.1554Z" fill="black"/>
              <path d="M20.0039 3H16.2954V3.79121H20.0039V3Z" fill="black"/>
              <path d="M18.6022 3.51428H17.7995V20.5985H18.6022V3.51428Z" fill="black"/>
            </g>
            <defs>
              <clipPath id="clip0_3416_44124">
                <rect width="16.1053" height="18" fill="white" transform="translate(4 3)"/>
              </clipPath>
            </defs>
          </svg>
          <p class="body2 light_txt_grey">2층/4층</p>
        </li>
        <li>
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
            <g clip-path="url(#clip0_3416_44129)">
              <path d="M11.5 22C6.26173 22 2 17.7383 2 12.5C2 7.26173 6.26173 3 11.5 3C16.7383 3 21 7.26173 21 12.5C21 17.7383 16.7383 22 11.5 22ZM11.5 3.84916C6.72983 3.84916 2.84916 7.72983 2.84916 12.5C2.84916 17.2702 6.72983 21.1508 11.5 21.1508C16.2702 21.1508 20.1508 17.2702 20.1508 12.5C20.1508 7.72983 16.2702 3.84916 11.5 3.84916Z" fill="black"/>
              <path d="M15.196 9.38889C14.9115 8.94626 14.506 8.60554 13.9795 8.36883C13.453 8.13213 12.8225 8.01324 12.087 8.01324H8.6712V17.803H10.2135V13.9202H12.088C12.8236 13.9202 13.4541 13.8013 13.9806 13.5646C14.506 13.3269 14.9115 12.9872 15.197 12.5446C15.4815 12.102 15.6237 11.5755 15.6237 10.9673C15.6237 10.3591 15.4815 9.83257 15.197 9.38995L15.196 9.38889ZM13.5528 12.1826C13.2089 12.4713 12.6962 12.6157 12.0169 12.6157H10.2135V9.31777H12.0169C12.6973 9.31777 13.2089 9.46 13.5528 9.74447C13.8967 10.0289 14.0687 10.4365 14.0687 10.9662C14.0687 11.4959 13.8967 11.8939 13.5528 12.1826Z" fill="black"/>
            </g>
            <defs>
              <clipPath id="clip0_3416_44129">
                <rect width="19" height="19" fill="white" transform="translate(2 3)"/>
              </clipPath>
            </defs>
          </svg>
          <p class="body2 light_txt_grey">주차 1대 가능</p>
        </li>
      </ul>
    </div>
  </section>

  <section>

    <div class="list_basic">
    <ul>
      <li>
        <div class="title">매물번호</div>37581502
      </li>
      <li>
        <div class="title">임대종류</div>월세
      </li>
      <li>
        <div class="title">보증금</div>1,670만원
      </li>
      <li>
        <div class="title">월세</div>60만원
      </li>
      <li>
        <div class="title">관리비</div>8만원
      </li>
      <li>
        <div class="title">관리비 포함</div>수도, 전기, 가스
      </li>
      <li>
        <div class="title">입주가능일</div>2023년 01월 중순 협의가능
      </li>   
    </ul>
    </div>
    <div class="item_num">
      <ul>
        <li>등록번호 33645154<span>조회수 3875</span></li>
        <li>※ 중개사무소 대표가 직접 확인하고 승인한 매물입니다.</li>
      </ul>
    </div>

  </section>

<hr>

  <section>
    <div class="list_basic">
      <ul>
        <li>
          <div class="title">승인일자</div>2023-01-15
        </li>
        <li>
        <div class="title">면적</div>
        <p id="change_value">대지면적 85.16㎡<br>
          연면적 58.35㎡</p>
        <b-button type="button" onclick="myFunction()" class="btn btn-sm position-absolute end-16 btn-link border">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g clip-path="url(#clip0_3310_12464)">
              <path d="M20.3333 12C20.3333 16.6 16.6 20.3333 12 20.3333C7.4 20.3333 4.59166 15.7 4.59166 15.7M4.59166 15.7H8.35833M4.59166 15.7V19.8666M3.66666 12C3.66666 7.39996 7.36666 3.66663 12 3.66663C17.5583 3.66663 20.3333 8.29996 20.3333 8.29996M20.3333 8.29996V4.13329M20.3333 8.29996H16.6333" stroke="var(--bs-purple)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            </g>
            <defs>
              <clipPath id="clip0_3310_12464">
                <rect width="20" height="20" fill="white" transform="translate(2 2)"/>
              </clipPath>
            </defs>
          </svg>

        </b-button>
      </li>
        <li>
          <div class="title">건물유형</div>공동주택
        </li>
        <li>
          <div class="title">집 형태</div>빌라형
        </li>
        <li>
          <div class="title">방 형태</div>오픈형 원룸
        </li>
        <li>
          <div class="title">방 평수</div>33㎡
          <b-button type="button" onclick="myFunction()" class="btn btn-sm position-absolute end-16 btn-link border">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g clip-path="url(#clip0_3310_12464)">
              <path d="M20.3333 12C20.3333 16.6 16.6 20.3333 12 20.3333C7.4 20.3333 4.59166 15.7 4.59166 15.7M4.59166 15.7H8.35833M4.59166 15.7V19.8666M3.66666 12C3.66666 7.39996 7.36666 3.66663 12 3.66663C17.5583 3.66663 20.3333 8.29996 20.3333 8.29996M20.3333 8.29996V4.13329M20.3333 8.29996H16.6333" stroke="var(--bs-purple)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            </g>
            <defs>
              <clipPath id="clip0_3310_12464">
                <rect width="20" height="20" fill="white" transform="translate(2 2)"/>
              </clipPath>
            </defs>
          </svg>

        </b-button>
        </li>
        <li>
          <div class="title">해당층/총층</div>7 / 11층
        </li>
        <li>
          <div class="title">방 방향</div>동향  *창문문 기준
        </li>
        <li>
          <div class="title">기본 옵션</div>
          <label>에어컨</label>
          <label>냉장고</label>
          <label>세탁기</label>
        </li>
        <li>
          <div class="title">기타 시설</div>엘리베이터, 주차
        </li>
        <li>
          <div class="title">주차</div>세대당 1대 가능
        </li>
        <li>
          <div class="title">가능반려동물</div>강아지
        </li>
        <li>
          <div class="title">대출 관련</div>불가능
        </li>
      </ul>
    </div>

    <div class="detail_info_txt">
      ※ 매매 수수료는 NO / 임대차는 임차인 수수료 있습니다.
      ※ 현장 방문은 예약제이며, 방문예약 중 입니다.

      ♣ https://blog.naver.com/jejudo3355 ;

      연락처 : 743-9900 / 010-7179-2998
      ⓞ 사무실 : 한라초.한라중 서쪽, 부영5차 상가
    </div>


  </section>

  <hr>


  <section>
    <div class="subtitle_wrap Subtitle1">위치 정보</div>

   <!--map-->

    <div class="subtitle_wrap mt-4 Subtitle1">등록자 정보</div>

    <div class="user_info">
      <ul>
        <li>
          <img src="https://img.freepik.com/free-photo/smiling-asian-man-sitting-desk-front-laptop-office-looking-camera_1098-20487.jpg?size=626&ext=jpg&uid=R10698311&ga=GA1.2.1232995836.1668049586&semt=sph" class="avatar-64">
        </li>
        <li>
          <p class="Subtitle1 mb-2">김캥캥</p>
          <div class="list-btn">
            <b-button type="button" class="btn btn-sm   btn-outline-primary">
              전화문의
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" style="margin-left:0">
                <path d="M4.10382 5.89027L5.52851 4.46557C6.3121 3.68199 7.58271 3.67038 8.3521 4.43978L9.08652 5.17419C9.89089 5.97856 10.0347 7.23364 9.43985 8.22019L8.71599 9.41967C8.47237 9.81717 8.58008 10.2753 8.85307 10.6395C10.6173 12.9935 11.3167 13.6929 13.3575 15.144C13.7285 15.4078 14.1799 15.5247 14.5774 15.2811L15.7769 14.5572C16.7634 13.9623 18.0185 14.1062 18.8228 14.9105L19.5573 15.6449C20.3267 16.4143 20.3151 17.6849 19.5315 18.4685L18.5 19.5L18.0928 19.8792C17.2308 20.7412 15.9438 21.007 14.8256 20.5585L14.2771 20.3376C9.66559 18.2763 5.74804 14.43 3.64545 9.70599L3.42459 9.15745C2.97601 8.03927 3.24188 6.75221 4.10382 5.89027Z"   stroke-width="1.5" stroke-miterlimit="10"/>
                <path d="M20 11C20 7.13401 16.866 4 13 4"   stroke-width="1.5" stroke-linecap="round"/>
                <path d="M17 11C17 8.79086 15.2091 7 13 7"   stroke-width="1.5" stroke-linecap="round"/>
              </svg>
            </b-button>
            <b-button type="button" class="btn btn-sm btn-primary">
              채팅하기
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                <g clip-path="url(#clip0_151_4749)">
                  <path d="M7.92289 17.6365L17.4408 17.6669C18.9793 17.6669 20.2306 16.4309 20.2306 14.9113V7.51555C20.2306 5.99588 18.9793 4.75989 17.4408 4.75989H6.55879C5.02033 4.75989 3.76904 5.99588 3.76904 7.51555V14.9214L3.82033 19.9667C3.82033 20.2098 4.09725 20.3314 4.29212 20.1794L7.70751 17.7176C7.76904 17.6669 7.85109 17.6365 7.93315 17.6365H7.92289Z" stroke="#fff" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"/>
                  <path d="M7.19487 9.01489H16.7641" stroke="#fff" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"/>
                  <path d="M7.19487 12.4088H16.7641" stroke="#fff" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"/>
                </g>
                <defs>
                  <clipPath id="clip0_151_4749">계약 
                    <rect width="18" height="17" fill="white" transform="translate(3 4)"/>
                  </clipPath>
                </defs>
              </svg>
            </b-button>
          </div>
        </li>
      </ul>
      <p class="mt-3 body2 light_txt_lgrey">공지) 개인과의 직거래시 언제나 안전에 유의하세요.</p>
    </div>
  
  </section>


  <div class="bottom-btn-group" role="group" aria-label="Basic example">
  <b-button type="button" variant="btn btn-full btn-primary w-100" onclick="location.href=''">계약진행</b-button>
  </div>

</div>
</div>
  
  </div>
</template>