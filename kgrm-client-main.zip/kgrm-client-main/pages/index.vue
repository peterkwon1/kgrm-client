<template>
  <div class="wrap">

    <!--alarm modal s-->
    <b-modal id="modal-scoped">
    <template #modal-header="{ close }">
     <h5 class="fs-5">알림</h5>
      <!-- Emulate built in modal header close button action -->
      <b-button size="lg" variant="outline-danger" @click="close()" class="btn-close"></b-button>
    </template>

    <template #default="{ hide }">
      <div class="modal-body">
              <div class="Subtitle1 py-3">새로운 알림</div>
              <div class="alarm_list new">
                <ul>
                  <li>
                    <img src="https://img.freepik.com/free-photo/smiling-asian-man-sitting-desk-front-laptop-office-looking-camera_1098-20487.jpg?size=626&amp;ext=jpg&amp;uid=R10698311&amp;ga=GA1.2.1232995836.1668049586&amp;semt=sph" class="avatar-64">
                  </li>
                  <li>
                    <p class="Subtitle2">유저명</p>
                    <p class="body2 mb-2">메세지를 확인했습니다.</p>
                    <p class="caption1">1분 전</p>
                  </li>
                </ul>

              </div>
              <div class="alarm_list">
                <ul>
                  <li>
                    <img src="https://img.freepik.com/free-photo/smiling-asian-man-sitting-desk-front-laptop-office-looking-camera_1098-20487.jpg?size=626&amp;ext=jpg&amp;uid=R10698311&amp;ga=GA1.2.1232995836.1668049586&amp;semt=sph" class="avatar-64">
                  </li>
                  <li>
                    <p class="Subtitle2">유저명</p>
                    <p class="body2 mb-2">메세지를 확인했습니다.</p>
                    <p class="caption1">1분 전</p>
                  </li>
                </ul>

              </div>
              <div class="alarm_list">
                <ul>
                  <li>
                    <img src="https://img.freepik.com/free-photo/smiling-asian-man-sitting-desk-front-laptop-office-looking-camera_1098-20487.jpg?size=626&amp;ext=jpg&amp;uid=R10698311&amp;ga=GA1.2.1232995836.1668049586&amp;semt=sph" class="avatar-64">
                  </li>
                  <li>
                    <p class="Subtitle2">유저명</p>
                    <p class="body2 mb-2">메세지를 확인했습니다.</p>
                    <p class="caption1">1분 전</p>
                  </li>
                </ul>

              </div>

            </div>
    </template>

    <template #modal-footer="{ ok }">
       <!-- Emulate built in modal footer ok and cancel button actions -->
      <b-button size="lg" variant="info w-100" @click="ok()">
        전체보기
      </b-button>

    </template>
  </b-modal>
    <!--alarm modal e-->

    <nuxt-child/>
  </div>
  
</template>

<script>
export default {
  asyncData({ route, redirect }) {
    const path = route.path;

    if (path === '/') {
      redirect('/main/home');
    }

    return { path };
  }
}
</script>

