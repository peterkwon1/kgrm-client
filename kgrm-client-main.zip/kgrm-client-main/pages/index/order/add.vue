<template>
    <div id="app">
<!--header s-->
<header class="sticky-header d-flex bg-white flex-wrap align-items-center justify-content-between py-2 sticky-top">
    <button type="button" class="btn btn-sm btn-link" onclick="location.href='index.html'">
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
        <path d="M20 12.75C20.4142 12.75 20.75 12.4142 20.75 12C20.75 11.5858 20.4142 11.25 20 11.25V12.75ZM4 11.25C3.58579 11.25 3.25 11.5858 3.25 12C3.25 12.4142 3.58579 12.75 4 12.75V11.25ZM20 11.25L4 11.25V12.75L20 12.75V11.25Z" fill="#232C34"/>
        <path d="M10.5303 6.53033C10.8232 6.23744 10.8232 5.76256 10.5303 5.46967C10.2374 5.17678 9.76256 5.17678 9.46967 5.46967L10.5303 6.53033ZM4 12L3.46967 11.4697C3.17678 11.7626 3.17678 12.2374 3.46967 12.5303L4 12ZM9.46967 18.5303C9.76256 18.8232 10.2374 18.8232 10.5303 18.5303C10.8232 18.2374 10.8232 17.7626 10.5303 17.4697L9.46967 18.5303ZM9.46967 5.46967L3.46967 11.4697L4.53033 12.5303L10.5303 6.53033L9.46967 5.46967ZM3.46967 12.5303L9.46967 18.5303L10.5303 17.4697L4.53033 11.4697L3.46967 12.5303Z" fill="#232C34"/>
      </svg>
    </button>
 
        <button type="button" class="btn btn-md btn-dark" id="liveToastBtn" >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M15.8808 4H8.11111C6.39436 4 5 5.39155 5 7.087V18.3554C5 19.7949 6.03972 20.4027 7.31318 19.7069L11.2464 17.5396C11.6655 17.3077 12.3425 17.3077 12.7536 17.5396L16.6868 19.7069C17.9603 20.4107 19 19.8029 19 18.3554V7.087C18.9919 5.39155 17.5976 4 15.8808 4Z" stroke="var(--bs-dark)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M11 11.25L11.8182 12L14 10" stroke="var(--bs-dark)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          임시저장
        </button>
       </header>
<!--header e-->

<!--content s-->

<div class="container pb-8">

<div class="stepper-wrapper">
  <div class="stepper-item active">
    <div class="step-counter">1</div>
    <div class="step-name">유형/일자</div>
  </div>
  <div class="stepper-item">
    <div class="step-counter">2</div>
    <div class="step-name">조건/위치</div>
  </div>
  <div class="stepper-item">
    <div class="step-counter">3</div>
    <div class="step-name">차임/면적</div>
  </div>
  <div class="stepper-item">
    <div class="step-counter">4</div>
    <div class="step-name">방/층</div>
  </div>
  <div class="stepper-item">
    <div class="step-counter">5</div>
    <div class="step-name">중요</div>
  </div>
</div>

 
<div class="px-3">
<div class="subtitle_wrap2 Subtitle1 pt-4">
  <h5>어떤 계약 유형을 원하시나요?</h5>
</div>

<div class="btn-group3">
  <input type="checkbox" class="btn-check " id="btn-check-1" autocomplete="off">
  <label class="btn btn-shadow-outline shadow2 w-50" for="btn-check-1">
    월세
  </label>
  <input type="checkbox" class="btn-check " id="btn-check-2" autocomplete="off">
  <label class="btn btn-shadow-outline shadow2 w-50  " for="btn-check-2">
    전세
  </label>

</div>

<div class="caption1 light_txt_lgrey p-4 px-0">※ 1년 이내의 계약을 원하신다면 단기임대를 선택해주세요.</div>

<div class="subtitle_wrap2 Subtitle1 pt-4">
  <h5>입주 일정을 알려주시겠어요?</h5>
</div>

<div class="order-date-select">
  <div class="body1-title">언제부터 입주하실 수 있나요?</div>
  <div class="btn-group d-flex gap-3">

  <div class="dropdown">
    <b-form-select v-model="selected" :options="options" class="lg select-year"></b-form-select>
  </div>
    <div class="dropdown">
 
      <b-form-select v-model="selected2" :options="options2" class="lg select-month"></b-form-select>  
    </div>
    <div class="dropdown">
      <b-form-select v-model="selected3" :options="options3" class="lg select-day"></b-form-select> 
      
    </div>
  </div>

  <div class="body1-title pt-4">언제까지 입주하셔야 하나요?</div>
  <div class="btn-group d-flex gap-3">

    <div class="dropdown">
      <b-form-select v-model="selected4" :options="options4" class="lg select-year"></b-form-select>

     
    </div>
    <div class="dropdown">
      <b-form-select v-model="selected5" :options="options5" class="lg select-month"></b-form-select>  

    </div>
    <div class="dropdown">
      <b-form-select v-model="selected6" :options="options6" class="lg select-day"></b-form-select> 

    </div>
  </div>

</div>

  <div class="alert alert-secondary text-center mt-4" role="alert">
    총 <span>10일</span> 안에 입주하고 싶어요!
  </div>


</div>
<div aria-live="polite" aria-atomic="true" class="d-flex position-fixed justify-content-center top-50 align-items-center w-100">
  <div id="liveToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="toast-body">
      <ul>
        <li>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M21.25 12C21.25 17.1086 17.1086 21.25 12 21.25C6.89137 21.25 2.75 17.1086 2.75 12C2.75 6.89137 6.89137 2.75 12 2.75C17.1086 2.75 21.25 6.89137 21.25 12Z" stroke="#ffffff" stroke-width="1.5"/>
            <path fill-rule="evenodd" clip-rule="evenodd" d="M12 7C12.5523 7 13 7.44772 13 8L13 12.5C13 13.0523 12.5523 13.5 12 13.5C11.4477 13.5 11 13.0523 11 12.5L11 8C11 7.44772 11.4477 7 12 7Z" fill="#ffffff"/>
            <path fill-rule="evenodd" clip-rule="evenodd" d="M12 14.5C12.5523 14.5 13 14.9477 13 15.5L13 16C13 16.5523 12.5523 17 12 17C11.4477 17 11 16.5523 11 16L11 15.5C11 14.9477 11.4477 14.5 12 14.5Z" fill="#ffffff"/>
          </svg>
        </li>
        <li>
          <p class="Subtitle2">임시저장이 완료되었습니다!</p>
          마이페이지 > 임시저장에서 확인 해주세요.
        </li>
        <li>
          <button type="button" class="btn btn-sm" data-bs-dismiss="toast" aria-label="Close">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M7.79289 7.79289C8.18342 7.40237 8.81658 7.40237 9.20711 7.79289L16.2071 14.7929C16.5976 15.1834 16.5976 15.8166 16.2071 16.2071C15.8166 16.5976 15.1834 16.5976 14.7929 16.2071L7.79289 9.20711C7.40237 8.81658 7.40237 8.18342 7.79289 7.79289Z" fill="#ffffff"/>
              <path fill-rule="evenodd" clip-rule="evenodd" d="M16.2071 7.79289C16.5976 8.18342 16.5976 8.81658 16.2071 9.20711L9.20711 16.2071C8.81658 16.5976 8.18342 16.5976 7.79289 16.2071C7.40237 15.8166 7.40237 15.1834 7.79289 14.7929L14.7929 7.79289C15.1834 7.40237 15.8166 7.40237 16.2071 7.79289Z" fill="#ffffff"/>
            </svg>
          </button>
        </li>
      </ul>
    </div>
  </div>
</div>

</div>

<div class="bottom-btn-group-50 bottom-20 justify-content-end" role="group" aria-label="Basic example">
  <button type="button" class="d-none btn btn-lg btn-outline-light">이전</button>
  <button type="button" class="btn btn-lg btn-outline-primary"  data-animation="5" onclick="location.href='order-2.html'">다음</button>
</div>

<!--content e-->


</div>
</template>
<script>
  export default {
    data() {
      return {
        selected: '2023',
        options: [
          { value: '2023', text: '2023' },
          { value: '2024', text: '2024' },
         ],
         selected2: '11',
        options2: [
          { value: '12', text: '12' },
          { value: '11', text: '11' },
          { value: '10', text: '10' },
          { value: '9', text: '9' },
          { value: '8', text: '8' },
          { value: '7', text: '7' },
          { value: '6', text: '6' },
          { value: '5', text: '5' },
          { value: '4', text: '4' },
          { value: '3', text: '3' },
          { value: '2', text: '2' },
          { value: '1', text: '1' },
         ],
         selected3: '20',
        options3: [
          { value: '31', text: '31' },
          { value: '30', text: '30' },
          { value: '29', text: '29' },
          { value: '28', text: '28' },
          { value: '27', text: '27' },
          { value: '26', text: '26' },
          { value: '25', text: '25' },
          { value: '24', text: '24' },
          { value: '23', text: '23' },
          { value: '22', text: '22' },
          { value: '21', text: '21' },
          { value: '20', text: '20' },
          { value: '19', text: '19' },
          { value: '18', text: '18' },
          { value: '17', text: '17' },
          { value: '16', text: '16' },
          { value: '15', text: '15' },
          { value: '14', text: '14' },
          { value: '13', text: '13' },
          { value: '12', text: '12' },
          { value: '11', text: '11' },
          { value: '10', text: '10' },
          { value: '9', text: '9' },
          { value: '8', text: '8' },
          { value: '7', text: '7' },
          { value: '6', text: '6' },
          { value: '5', text: '5' },
          { value: '4', text: '4' },
          { value: '3', text: '3' },
          { value: '2', text: '2' },
          { value: '1', text: '1' },
         ],
         selected4: '2023',
        options4: [
          { value: '2023', text: '2023' },
          { value: '2024', text: '2024' },
         ],
         selected5: '11',
        options5: [
          { value: '12', text: '12' },
          { value: '11', text: '11' },
          { value: '10', text: '10' },
          { value: '9', text: '9' },
          { value: '8', text: '8' },
          { value: '7', text: '7' },
          { value: '6', text: '6' },
          { value: '5', text: '5' },
          { value: '4', text: '4' },
          { value: '3', text: '3' },
          { value: '2', text: '2' },
          { value: '1', text: '1' },
         ],
         selected6: '20',
        options6: [
          { value: '31', text: '31' },
          { value: '30', text: '30' },
          { value: '29', text: '29' },
          { value: '28', text: '28' },
          { value: '27', text: '27' },
          { value: '26', text: '26' },
          { value: '25', text: '25' },
          { value: '24', text: '24' },
          { value: '23', text: '23' },
          { value: '22', text: '22' },
          { value: '21', text: '21' },
          { value: '20', text: '20' },
          { value: '19', text: '19' },
          { value: '18', text: '18' },
          { value: '17', text: '17' },
          { value: '16', text: '16' },
          { value: '15', text: '15' },
          { value: '14', text: '14' },
          { value: '13', text: '13' },
          { value: '12', text: '12' },
          { value: '11', text: '11' },
          { value: '10', text: '10' },
          { value: '9', text: '9' },
          { value: '8', text: '8' },
          { value: '7', text: '7' },
          { value: '6', text: '6' },
          { value: '5', text: '5' },
          { value: '4', text: '4' },
          { value: '3', text: '3' },
          { value: '2', text: '2' },
          { value: '1', text: '1' },
         ]
      }
    }
  }
</script>