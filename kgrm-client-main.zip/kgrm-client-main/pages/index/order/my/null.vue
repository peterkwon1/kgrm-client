<template>
    <div id="app">
      <b-tabs
    active-nav-item-class="font-weight-bold text-uppercase"
    active-tab-class="font-weight-bold"
    content-class="mt-2"
    class="full-width bg-light"
  >
  <!--content s-->
  <!--내 주문서 tab-->
    <b-tab title="내 주문서" active>

<div class="container pb-6">

  <div class="radio-nav d-flex gap-2 py-3">
  <b-form-group label="" v-slot="{ ariaDescribedby }">
      <b-form-radio-group
        id="btn-radios-1"
        class="gap-2"
        v-model="selected"
        :options="options"
        :aria-describedby="ariaDescribedby"
        name="radios-btn-default"
        buttons
      ></b-form-radio-group>
    </b-form-group>
</div>


<div class="subtitle_wrap Subtitle1 pt-2">
  <h6>전체 <span>0</span>건</h6>
</div>

 
<div class="center-wrap">
<div class="subtitle_wrap Subtitle1 text-center">
<img src="../../../../assets/img/2x/illust_04.png" class="w-10rem" data-aos="fade-up" data-aos-delay="200" data-aos-duration="1000">
<div class="body1 light_txt_lgrey pt-5">아직 작성된 주문서가 없습니다.</div>
<h3 class="pt-2">내 조건에 딱 맞는<br>원룸을 주문해볼까요?</h3>
<b-button type="button" variant="lg btn-primary mt-4 w-100" onclick="location.href='/map/list'">원룸 주문하기</b-button>
<b-button type="button" variant="lg btn-outline-primary mt-3 w-100" onclick="location.href='/map/list'">공인중개사로 전환하기</b-button>

</div>
   </div>

</div>
</b-tab>
 <!--임시저장 tab-->
<b-tab title="임시저장">
  <div class="container pb-6">

<div class="subtitle_wrap Subtitle1 pt-4">
<h6>전체 <span>0</span>건</h6>
</div>


<div class="center-wrap">
<div class="subtitle_wrap Subtitle1 text-center">
<img src="../../../../assets/img/2x/illust_04.png" class="w-10rem" data-aos="fade-up" data-aos-delay="200" data-aos-duration="1000">
<div class="body1 light_txt_lgrey pt-5">아직 작성된 주문서가 없습니다.</div>
<h3 class="pt-2">내 조건에 딱 맞는<br>원룸을 주문해볼까요?</h3>
<b-button type="button" variant="lg btn-primary mt-4 w-100" onclick="location.href='/map/list'">원룸 주문하기</b-button>
<b-button type="button" variant="lg btn-outline-primary mt-3 w-100" onclick="location.href='/map/list'">공인중개사로 전환하기</b-button>

</div>
 </div>

</div>
</b-tab>
 <!--리뷰 tab-->
    <b-tab title="리뷰">
      <div class="container pb-6">

<div class="radio-nav d-flex gap-2 py-3">
<b-form-group label="" v-slot="{ ariaDescribedby }">
    <b-form-radio-group
      id="btn-radios-1"
      class="gap-2"
      v-model="selected2"
      :options="options2"
      :aria-describedby="ariaDescribedby"
      name="radios-btn-default"
      buttons
    ></b-form-radio-group>
  </b-form-group>
</div>


<div class="subtitle_wrap Subtitle1 pt-2">
<h6>전체 <span>0</span>건</h6>
</div>


<div class="center-wrap">
<div class="subtitle_wrap Subtitle1 text-center">
<img src="../../../../assets/img/2x/illust_04.png" class="w-10rem" data-aos="fade-up" data-aos-delay="200" data-aos-duration="1000">
<div class="body1 light_txt_lgrey pt-5">아직 작성된 주문서가 없습니다.</div>
<h3 class="pt-2">내 조건에 딱 맞는<br>원룸을 주문해볼까요?</h3>
<b-button type="button" variant="lg btn-primary mt-4 w-100" onclick="location.href='/map/list'">원룸 주문하기</b-button>
<b-button type="button" variant="lg btn-outline-primary mt-3 w-100" onclick="location.href='/map/list'">공인중개사로 전환하기</b-button>

</div>
 </div>

</div>    
    </b-tab>
  </b-tabs>

<!--content e-->
    </div>
</template>
<script>
  export default {
    data() {
      return {
        selected: '전체',
        options: [
          { text: '전체', value: '전체' },
          { text: '작성완료', value: '작성완료' },
          { text: '대기중', value: '대기중' },
          { text: '매칭완료', value: '매칭완료' },
          { text: '취소', value: '취소' }
        ],
        selected2: '전체',
        options2: [
          { text: '전체', value: '전체' },
          { text: '작성가능', value: '작성가능' },
          { text: '작성완료', value: '작성완료' }
        ]
      }
    }
  }
</script>