<template>
    <div id="app">
<!--header s-->
    <header class="sticky-header d-flex bg-white flex-wrap align-items-center justify-content-start py-3 border-bottom">
            
           <b-button type="button" class="btn btn-sm position-absolute start-16 btn-link" onclick="location.href='join'">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M20 12.75C20.4142 12.75 20.75 12.4142 20.75 12C20.75 11.5858 20.4142 11.25 20 11.25V12.75ZM4 11.25C3.58579 11.25 3.25 11.5858 3.25 12C3.25 12.4142 3.58579 12.75 4 12.75V11.25ZM20 11.25L4 11.25V12.75L20 12.75V11.25Z" fill="#232C34"/>
<path d="M10.5303 6.53033C10.8232 6.23744 10.8232 5.76256 10.5303 5.46967C10.2374 5.17678 9.76256 5.17678 9.46967 5.46967L10.5303 6.53033ZM4 12L3.46967 11.4697C3.17678 11.7626 3.17678 12.2374 3.46967 12.5303L4 12ZM9.46967 18.5303C9.76256 18.8232 10.2374 18.8232 10.5303 18.5303C10.8232 18.2374 10.8232 17.7626 10.5303 17.4697L9.46967 18.5303ZM9.46967 5.46967L3.46967 11.4697L4.53033 12.5303L10.5303 6.53033L9.46967 5.46967ZM3.46967 12.5303L9.46967 18.5303L10.5303 17.4697L4.53033 11.4697L3.46967 12.5303Z" fill="#232C34"/>
</svg>

           </b-button>
       </header>
<!--header e-->

<!--content s-->
<div class="container">
 
<div class="subtitle_wrap Subtitle1 pt-4">
<h4>회원가입</h4>
</div>

<div class="py-3">


<div class="input-title">이메일 주소</div>
<div class="d-flex gap-2 align-items-center mb-3">
<b-form-input v-model="memId" placeholder="이메일을 입력하세요" class=" "></b-form-input>
</div>

<div class="input-title">비밀번호</div>
<b-container fluid>
    <b-row class="my-1">
      <b-col sm="12">
        <b-form-input v-model="memPassword" type="password" placeholder="비밀번호를 입력하세요" class="mb-3"></b-form-input>
      </b-col>
    </b-row>
  </b-container>
  
  <div class="input-title">비밀번호 확인</div>
<b-container fluid>
    <b-row class="my-1">
      <b-col sm="12">
        <b-form-input v-model="confirmedPassword" :state="confirmedPasswordCheck" type="password" placeholder="비밀번호를 다시 입력하세요" class="mb-3"></b-form-input>
        <b-form-invalid-feedback id="input-live-feedback">비밀번호가 일치하지 않습니다</b-form-invalid-feedback>
      </b-col>
    </b-row>
  </b-container>

<div class="input-title">닉네임</div>
<b-form-input v-model="memNickname" placeholder="닉네임을 입력하세요" class="mb-3"></b-form-input>
 

<div class="input-title">휴대폰 번호</div>
<b-form-input v-model="memMobile" placeholder="01012345678" class="mb-1"></b-form-input>
<b-form-input v-model="memName" placeholder="이동욱" class="mb-3"></b-form-input>

 
<div class="input-title">생년월일</div>
<b-form-input v-model="memBirth" placeholder="1977 / 12 / 13" class="mb-3"></b-form-input>

</div>


<b-button type="button" class="btn btn-full btn-primary w-100 fixed-bottom" @click="join">회원가입</b-button>
 
</div>
<!--content e-->

</div>
</template>


<script>
 
  export default {
    data() {
      return {
        memId: '',
        memPassword: '',
        memNickname: '',
        memName: '',
        memMobile: '',
        memBirth: '',
        confirmedPassword: ''
      }
    },
    computed: {
      confirmedPasswordCheck() {
        return this.memPassword == this.confirmedPassword;
      }
    },
    methods: {
      async join() {
        try {
          const format = {
            memId: this.memId,
            memPassword: this.memPassword,
            memNickname: this.memNickname,
            memName: this.memName,
            memMobile: this.memMobile,
            memBirth: this.memBirth,
            memRole: 'user',
            memProvider: 'form'
          };

          await this.$axios.post('/user/login', { ...format });

          this.$router.replace('/login/success');
        } catch (e) {
          if (e.response) console.log(e.response.data.message);
        }
      }
    }
  }
</script>
 