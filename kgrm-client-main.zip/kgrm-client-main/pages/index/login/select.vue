<template>
    <div id="app">
<!--header s-->
    <header class="sticky-header d-flex bg-white flex-wrap align-items-center justify-content-start py-3 border-bottom">
            
           <b-button type="button" class="btn btn-sm position-absolute start-16 btn-link" onclick="location.href='/login'">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M20 12.75C20.4142 12.75 20.75 12.4142 20.75 12C20.75 11.5858 20.4142 11.25 20 11.25V12.75ZM4 11.25C3.58579 11.25 3.25 11.5858 3.25 12C3.25 12.4142 3.58579 12.75 4 12.75V11.25ZM20 11.25L4 11.25V12.75L20 12.75V11.25Z" fill="#232C34"/>
<path d="M10.5303 6.53033C10.8232 6.23744 10.8232 5.76256 10.5303 5.46967C10.2374 5.17678 9.76256 5.17678 9.46967 5.46967L10.5303 6.53033ZM4 12L3.46967 11.4697C3.17678 11.7626 3.17678 12.2374 3.46967 12.5303L4 12ZM9.46967 18.5303C9.76256 18.8232 10.2374 18.8232 10.5303 18.5303C10.8232 18.2374 10.8232 17.7626 10.5303 17.4697L9.46967 18.5303ZM9.46967 5.46967L3.46967 11.4697L4.53033 12.5303L10.5303 6.53033L9.46967 5.46967ZM3.46967 12.5303L9.46967 18.5303L10.5303 17.4697L4.53033 11.4697L3.46967 12.5303Z" fill="#232C34"/>
</svg>

           </b-button>
       </header>
<!--header e-->

<!--content s-->
<div class="container">
 
<div class="subtitle_wrap Subtitle1 pt-4">
<h4>회원가입</h4>
</div>

<div class="center-wrap py-3">

<div class="join-icon-btn">

<ul>

  <li>
    <b-button type="button" class="btn btn-shadow" onclick="location.href='join'">
      <span class="body2 light_txt_lgrey">집을 구하고 싶거나 빌려주고 싶어요</span>
      <svg viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <g clip-path="url(#clip0_3393_16279)">
          <path d="M3.67001 7.44L12.5 12.55L21.27 7.47M12.5 21.61V12.54" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"></path>
          <path d="M22.11 12.83V9.17C22.11 7.79 21.12 6.11 19.91 5.44L14.57 2.48C13.43 1.84 11.57 1.84 10.43 2.48L5.09001 5.44C3.88001 6.11 2.89001 7.79 2.89001 9.17V14.83C2.89001 16.21 3.88001 17.89 5.09001 18.56L10.43 21.52C11 21.84 11.75 22 12.5 22C13.25 22 14 21.84 14.57 21.52" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"></path>
          <path d="M23.5 22L22.5 21M19.7 21.4C20.5487 21.4 21.3626 21.0629 21.9627 20.4627C22.5629 19.8626 22.9 19.0487 22.9 18.2C22.9 17.3513 22.5629 16.5374 21.9627 15.9373C21.3626 15.3371 20.5487 15 19.7 15C18.8513 15 18.0374 15.3371 17.4373 15.9373C16.8371 16.5374 16.5 17.3513 16.5 18.2C16.5 19.0487 16.8371 19.8626 17.4373 20.4627C18.0374 21.0629 18.8513 21.4 19.7 21.4V21.4Z" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"></path>
        </g>
        <defs>
          <clipPath id="clip0_3393_16279">
            <rect width="24" height="24" fill="white" transform="translate(0.5)"></rect>
          </clipPath>
        </defs>
      </svg>

      <span class="button_medium">일반회원 가입</span>

    </b-button>
  </li>
  <li>
    <b-button type="button" class="btn btn-shadow" onclick="location.href='signup'">
      <span class="body2 light_txt_lgrey">공인중개사 입니다.</span>
      <svg viewBox="0 0 55 54" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M16.0025 39.3525L21.1775 44.5275M45.0275 33.5925C42.8303 35.7841 40.0765 37.3343 37.063 38.0758C34.0495 38.8173 30.8908 38.7219 27.9275 37.8L17.33 48.375C16.565 49.1625 15.0575 49.635 13.9775 49.4775L9.07249 48.8025C7.45249 48.5775 5.94499 47.0475 5.69749 45.4275L5.02249 40.5225C4.86499 39.4425 5.38249 37.935 6.12499 37.17L16.7 26.595C14.9 20.745 16.295 14.1075 20.93 9.49497C27.5675 2.85747 38.345 2.85747 45.005 9.49497C51.665 16.1325 51.665 26.955 45.0275 33.5925V33.5925Z" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
        <path d="M33.125 24.75C34.0201 24.75 34.8786 24.3944 35.5115 23.7615C36.1444 23.1286 36.5 22.2701 36.5 21.375C36.5 20.4799 36.1444 19.6214 35.5115 18.9885C34.8786 18.3556 34.0201 18 33.125 18C32.2299 18 31.3714 18.3556 30.7385 18.9885C30.1056 19.6214 29.75 20.4799 29.75 21.375C29.75 22.2701 30.1056 23.1286 30.7385 23.7615C31.3714 24.3944 32.2299 24.75 33.125 24.75Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
      </svg>
      <span class="button_medium">중개사회원 가입</span>

    </b-button>
  </li>
</ul>
 


</div>
 
</div>
 
</div>
<!--content e-->

</div>
</template>


