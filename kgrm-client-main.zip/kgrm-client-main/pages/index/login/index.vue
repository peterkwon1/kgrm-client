<template>
    <div id="app">
<!--header s-->
    <header class="sticky-header d-flex bg-white flex-wrap align-items-center justify-content-start py-3 border-bottom">
            
           <b-button type="button" class="btn btn-sm position-absolute start-16 btn-link" data-bs-toggle="modal" data-bs-target="#alarm">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M20 12.75C20.4142 12.75 20.75 12.4142 20.75 12C20.75 11.5858 20.4142 11.25 20 11.25V12.75ZM4 11.25C3.58579 11.25 3.25 11.5858 3.25 12C3.25 12.4142 3.58579 12.75 4 12.75V11.25ZM20 11.25L4 11.25V12.75L20 12.75V11.25Z" fill="#232C34"/>
<path d="M10.5303 6.53033C10.8232 6.23744 10.8232 5.76256 10.5303 5.46967C10.2374 5.17678 9.76256 5.17678 9.46967 5.46967L10.5303 6.53033ZM4 12L3.46967 11.4697C3.17678 11.7626 3.17678 12.2374 3.46967 12.5303L4 12ZM9.46967 18.5303C9.76256 18.8232 10.2374 18.8232 10.5303 18.5303C10.8232 18.2374 10.8232 17.7626 10.5303 17.4697L9.46967 18.5303ZM9.46967 5.46967L3.46967 11.4697L4.53033 12.5303L10.5303 6.53033L9.46967 5.46967ZM3.46967 12.5303L9.46967 18.5303L10.5303 17.4697L4.53033 11.4697L3.46967 12.5303Z" fill="#232C34"/>
</svg>

           </b-button>
       </header>
<!--header e-->

<!--content s-->

<div class="container">
<div class="center-wrap py-3">

  <div class="text-center pb-5">
    <h4>캥거룸 지금 바로 시작하기</h4>
    <p class="light_txt_lgrey mt-2">내가 살고싶은 원룸 주문, 간편하게 시작해보세요!</p>
  </div>

  <!-- ID/PW input s-->
  <div class="input-title">아이디</div>
  <div class=" mb-3">
    <input v-model="memId" type="email" class="form-control" id="Input" placeholder="아이디를 입력하세요">
   </div>
  <div class="input-title">비밀번호</div>
  <div class="">
    <input v-model="memPassword" type="password" class="form-control" id="Password" placeholder="비밀번호를 입력하세요">
   </div>

  <div class="form-check py-4">
    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
    <label class="form-check-label" for="flexCheckDefault">
      자동 로그인
    </label>
  </div>
  <!-- ID/PW input e-->

    <!-- login button s-->
  <div class="login-btn-wrap">
    <b-button type="button" class="btn btn-lg btn-primary w-100 " @click="login">로그인</b-button>
<!--  <b-button type="button" class="btn btn-lg btn-primary w-100 " @click="toast('b-toaster-top-center')">로그인</b-button>-->
    <b-button type="button" class="btn btn-lg btn-outline-info w-100" @click="loginWithNaver">
      <img src="../../../assets/img/icon/sns/naver-green.png" class="w-24 me-2">네이버 아이디로 로그인
    </b-button>
    <b-button type="button" class="btn btn-lg btn-outline-info w-100" @click="loginWithKakao">
      <img src="../../../assets/img/icon/sns/kakao.png" class="w-24 me-2">카카오톡 아이디로 로그인
    </b-button>
    <b-button type="button" class="d-none btn btn-lg btn-outline-info w-100">
      <img src="../../../assets/img/icon/sns/Google.png" class="w-24 me-2">구글 아이디로 로그인
    </b-button>
  </div>
  <!-- login button e-->

<!--ID/PW/JOIN s-->
  <div class="sign-up-btn-wrap">
    <b-button type="button" class="btn btn-sm btn-link" onclick="location.href='login/find-id'">아이디 찾기</b-button>
    <span class="line-grey"></span>
    <a class="btn btn-sm btn-link" onclick="location.href='login/password-reset'">비밀번호 변경</a>
    <span class="line-grey"></span>
    <b-button type="button" class="btn btn-sm btn-link-purple" onclick="location.href='login/join'">회원가입</b-button>
   </div>
<!--ID/PW/JOIN e-->

</div> 
 </div>
<!--content e-->

</div>
</template>


<script>
  export default {
    head: {
      script: [
        { src: 'https://static.nid.naver.com/js/naveridlogin_js_sdk_2.0.2.js' },
        { src: 'https://developers.kakao.com/sdk/js/kakao.min.js' }
      ]
    },
    data() {
      return {
        memId: '',
        memPassword: '',
        counter: 0
      }
    },
    methods: {
      async login() {
        try {
          const format = {
            memId: this.memId,
            memPassword: this.memPassword
          };
          const { data: result } = await this.$axios.post('/user/login', { ...format });

          await this.setUserByToken(result.token);
          await this.setUserById(result.uid);

          this.$router.push('/main/home');
        } catch (e) {
          if (e.response) console.log(e.response.data.message);
        }
      },
      async setUserByToken(t) {
        try {
          this.$cookies.set('token', t, {
            path: '/',
            maxAge: 60 * 60 * 24 * 365 * 100,
          });
        } catch (e) {
          if (e.response) console.log(e.response.data.message);
        }
      },
      async setUserById(uid) {
        try {
          this.$cookies.set('uid', uid, {
            path: '/',
            maxAge: 60 * 60 * 24 * 365 * 100,
          });
        } catch (e) {
          if (e.response) console.log(e.response.data.message);
        }
      },
      loginWithNaver() {
        const naverLogin = new naver.LoginWithNaverId({
          clientId: 'U_h9NXFqlJpAiOPMQ7Ul', // Naver client key
          callbackUrl: `${window.location.origin}/login/oauth2/naver`,
          callbackHandle: true
        })
        naverLogin.init()
        naverLogin.reprompt()


      },
      loginWithKakao() {
        Kakao.init('b5935936ae15baa0443c34db10cca0d9')
        Kakao.Auth.authorize({
          redirectUri: `${window.location.origin}/login/oauth2/kakao`
        })
      },
      toast(toaster, append = false) {
        this.counter++
        this.$bvToast.toast(`아이디를 확인해주세요.`, {
          title: `Toaster ${toaster}`,
          toaster: toaster,
          solid: true,
          appendToast: append
        })
      }
    }
  }
</script>