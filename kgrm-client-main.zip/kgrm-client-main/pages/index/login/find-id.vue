<template>
    <div id="app">
<!--header s-->
    <header class="d-none sticky-header d-flex bg-white flex-wrap align-items-center justify-content-start py-3 border-bottom">
            
           <b-button type="button" class="btn btn-sm position-absolute start-16 btn-link" onclick="location.href='join'">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M20 12.75C20.4142 12.75 20.75 12.4142 20.75 12C20.75 11.5858 20.4142 11.25 20 11.25V12.75ZM4 11.25C3.58579 11.25 3.25 11.5858 3.25 12C3.25 12.4142 3.58579 12.75 4 12.75V11.25ZM20 11.25L4 11.25V12.75L20 12.75V11.25Z" fill="#232C34"/>
<path d="M10.5303 6.53033C10.8232 6.23744 10.8232 5.76256 10.5303 5.46967C10.2374 5.17678 9.76256 5.17678 9.46967 5.46967L10.5303 6.53033ZM4 12L3.46967 11.4697C3.17678 11.7626 3.17678 12.2374 3.46967 12.5303L4 12ZM9.46967 18.5303C9.76256 18.8232 10.2374 18.8232 10.5303 18.5303C10.8232 18.2374 10.8232 17.7626 10.5303 17.4697L9.46967 18.5303ZM9.46967 5.46967L3.46967 11.4697L4.53033 12.5303L10.5303 6.53033L9.46967 5.46967ZM3.46967 12.5303L9.46967 18.5303L10.5303 17.4697L4.53033 11.4697L3.46967 12.5303Z" fill="#232C34"/>
</svg>

           </b-button>
       </header>
<!--header e-->

<!--content s-->
<div class="container">
 
  <div class="center-wrap px-3">
    <div class="subtitle_wrap Subtitle1 text-center">
      <!--icon-->
         <div class="check-circle bg-primary rounded-circle" data-aos="fade-up" data-aos-delay="200" data-aos-duration="1000">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M4.53033 12.4697C4.23744 12.1768 3.76256 12.1768 3.46967 12.4697C3.17678 12.7626 3.17678 13.2374 3.46967 13.5303L4.53033 12.4697ZM8.46967 18.5303C8.76256 18.8232 9.23744 18.8232 9.53033 18.5303C9.82322 18.2374 9.82322 17.7626 9.53033 17.4697L8.46967 18.5303ZM3.46967 13.5303L8.46967 18.5303L9.53033 17.4697L4.53033 12.4697L3.46967 13.5303Z" fill="#fff"/>
<path d="M20.5244 7.53021C20.8173 7.23724 20.8171 6.76237 20.5241 6.46955C20.2312 6.17674 19.7563 6.17687 19.4635 6.46985L20.5244 7.53021ZM8.46952 17.4699C8.17671 17.7628 8.17684 18.2377 8.46981 18.5305C8.76279 18.8233 9.23766 18.8232 9.53047 18.5302L8.46952 17.4699ZM19.4635 6.46985L8.46952 17.4699L9.53047 18.5302L20.5244 7.53021L19.4635 6.46985Z" fill="#fff"/>
</svg>
        </div>
 <!--icon-->

      <div class="body1 pt-4">
        회원가입 시 사용한 아이디는
      </div>
      <h3 class="pt-3">
        kangaroo@naver.com
      </h3>
      <div class="body1 pt-3">
        입니다.
      </div>
    </div>
   
</div>
<b-button type="button" class="btn btn-full btn-primary w-100 fixed-bottom" onclick="location.href='/login'">로그인 하기</b-button>
</div>
<!--content e-->

</div>
</template>

 
 