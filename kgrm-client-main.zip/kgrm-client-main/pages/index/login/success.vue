<template>
    <div id="app">
 
<!--content s-->
<div class="container">
 
  <div class="success_wrap">
<div class="subtitle_wrap Subtitle1 pt-8">
  <img src="../../../assets/img/2x/illust_01.png" data-aos="fade-up" data-aos-delay="200" data-aos-duration="1000" class="w-50 py-5">

  <h2>내 취향에 딱 맞는 집,<br>
    캥거룸이 대신 찾아드릴게요.</h2>
  <p>캥거룸만의 특별한 매칭서비스를 이용해보세요.</p>

</div>
</div>


  <button type="button" class="btn btn-full btn-shadow w-100 fixed-bottom" onclick="location.href='/login'">캥거룸 시작하기</button>
  </div>
 
  
</div>
<!--content e-->

</div>
</template>
 