<template>
  <v-layout column> </v-layout>
</template>

<script>
export default {
  head: {
    script: [
      { src: 'https://static.nid.naver.com/js/naveridlogin_js_sdk_2.0.2.js' },
    ]
  },
  layout: 'layout_login',
  mounted() {
    const naverLogin = new naver.LoginWithNaverId({
      clientId: 'U_h9NXFqlJpAiOPMQ7Ul'
    })
    naverLogin.init()

    this.loginWithNaver(naverLogin);
  },
  methods: {
    async loginWithNaver(naverLogin) {

      naverLogin.getLoginStatus(async (status) => {
        if (status) {
          const format = {
            memPassword: naverLogin.user.id,
            memName: naverLogin.user.name,
            memId: naverLogin.user.email,
            memNickname: naverLogin.user.nickname,
            memBirth: naverLogin.user.birthday,
            memMobile: naverLogin.user.mobile,
            memRole: 'user',
            memProvider: 'naver'
          }

          const { data: result } = await this.$axios.post('/user/login', { ...format });
          await this.setUserByToken(result.token);
          await this.setUserById(result.uid);

          this.$router.replace('/main/home');
        } else {
          console.log('AccessToken이 올바르지 않습니다.')
        }
      });

    },
    async setUserByToken(t) {
      try {
        this.$cookies.set('token', t, {
          path: '/',
          maxAge: 60 * 60 * 24 * 365 * 100,
        });
      } catch (e) {
        if (e.response) console.log(e.response.data.message);
      }
    },
    async setUserById(uid) {
      try {
        this.$cookies.set('uid', uid, {
          path: '/',
          maxAge: 60 * 60 * 24 * 365 * 100,
        });
      } catch (e) {
        if (e.response) console.log(e.response.data.message);
      }
    },
  }
}
</script>
