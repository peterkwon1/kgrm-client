<template>
  <v-layout column> </v-layout>
</template>

<script>
export default {
  head: {
    script: [
      { src: 'https://developers.kakao.com/sdk/js/kakao.min.js' }
    ]
  },
  layout: 'layout_login',
  async asyncData({ app, query, store }){

    const config = {
      headers: {
        'Content-type': 'application/x-www-form-urlencoded;charset=utf-8',
        'Authorization': 'Bearer '
      }
    };
    const param = {
      grant_type: 'authorization_code',
      client_id: 'b5935936ae15baa0443c34db10cca0d9',
      redirect_uri: 'http://127.0.0.1:3000/login/oauth2/kakao',
      code: query.code,
    };

    const queryString = await store.dispatch('queryString', param)

    try {
      const tokenInfo = await app.$axios.post('https://kauth.kakao.com/oauth/token?' + queryString, {}, config)
      config.headers.Authorization += tokenInfo.data.access_token

      const userInfo = await app.$axios.post('https://kapi.kakao.com/v2/user/me', {}, config)

      const info = {
        id: userInfo.data.id,
        age: userInfo.data.kakao_account.age_range,
        gender: userInfo.data.kakao_account.gender,
        nickname: userInfo.data.properties.nickname,
        profile_image: userInfo.data.properties.profile_image,
      }

      console.log(info)

    } catch (e) {
      console.log(e)
    }

  },
}
</script>