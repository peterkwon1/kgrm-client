<template>
  <div id="app">
    <header class="d-flex bg-white flex-wrap justify-content-end align-items-center py-2 border-bottom">
      <div class="header_title Subtitle1">방 등록하기</div>
      <button type="button" class="btn btn-sm btn-link position-absolute end-1" data-bs-toggle="modal" data-bs-target="#delete">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
          <path d="M6.53033 5.46967C6.23744 5.17678 5.76256 5.17678 5.46967 5.46967C5.17678 5.76256 5.17678 6.23744 5.46967 6.53033L6.53033 5.46967ZM17.4697 18.5303C17.7626 18.8232 18.2374 18.8232 18.5303 18.5303C18.8232 18.2374 18.8232 17.7626 18.5303 17.4697L17.4697 18.5303ZM5.46967 6.53033L17.4697 18.5303L18.5303 17.4697L6.53033 5.46967L5.46967 6.53033Z" fill="#232C34"></path>
          <path d="M18.5303 6.53033C18.8232 6.23744 18.8232 5.76256 18.5303 5.46967C18.2374 5.17678 17.7626 5.17678 17.4697 5.46967L18.5303 6.53033ZM5.46967 17.4697C5.17678 17.7626 5.17678 18.2374 5.46967 18.5303C5.76256 18.8232 6.23744 18.8232 6.53033 18.5303L5.46967 17.4697ZM17.4697 5.46967L5.46967 17.4697L6.53033 18.5303L18.5303 6.53033L17.4697 5.46967Z" fill="#232C34"></path>
        </svg>
      </button>
    </header>

    <!--content s-->
    <div class="container pb-8">
      <b-tabs
        v-model="step"
        nav-class="py-4"
        active-nav-item-class="font-weight-bold text-uppercase"
        active-tab-class="font-weight-bold"
        content-class=" ">
        <b-tab title="집주소" :active="step === 0">
          <div class="px-3">
            <div class="subtitle_wrap2 Subtitle1">
              내놓을 집의 주소를 알려주세요.
            </div>

            <div class="address-regist">
              <div class="address-with-btn align-items-end">
                <div class="w-100">
                  <div class="input-title">주소</div>
                  <input class="form-control" id="roomAddr1" v-model="roomAddr1">
                </div>
                <button class="btn btn-primary w-40" type="button" @click="searchAddress">주소 검색</button>
              </div>

              <div>
                <div class="input-title mt-2">상세 주소</div>
                <input type="text" class="form-control" id="roomAddr2" v-model="roomAddr2">
              </div>

              <input id="roomSiDo" v-model="roomSiDo" hidden></input>
              <input id="roomSiGunGu" v-model="roomSiGunGu" hidden></input>
              <input id="roomEupMyeonDong" v-model="roomEupMyeonDong" hidden></input>
              <input id="roomLat" v-model="roomLat" hidden></input>
              <input id="roomLng" v-model="roomLng" hidden></input>
            </div>

            <div class="subtitle_wrap2 Subtitle1 pt-4">
              집주인에게 말씀드렸나요?
            </div>
            <div class="form-check">
              <input class="form-check-input" type="checkbox" id="isHostOk" v-model="isHostOk">
              <label class="form-check-label" for="isHostOk">
                네, 집주인에게 허락을 받았습니다.
              </label>
            </div>

            <div class="input-title pt-3">집 주인 연락처</div>
            <div class="form-floating mb-3">
              <input class="form-control" id="roomHostMobile" v-model="roomHostMobile" placeholder="집 주인 연락처를 입력하세요" :disabled="isHostOk">
              <label for="roomHostMobile">집 주인 연락처를 입력하세요</label>
            </div>

            <div class="d-none alert alert-secondary mt-4" role="alert">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" value="" id="agree">
                <label class="form-check-label fs-7" for="agree">
                  정확한 정보 확인을 위해 집 주인에게 연락이 갈수있음을 설명, 고지하고 동의 받았습니다.
                </label>
              </div>
            </div>
          </div>

          <div class="bottom-btn-group-50 bottom-0 justify-content-end" role="group" aria-label="Basic example">
            <button type="button" class="d-none btn btn-lg btn-outline-light">이전</button>
            <button type="button" class="btn btn-lg btn-outline-primary" @click="step = 1">다음</button>
          </div>
        </b-tab>
        <b-tab title="집정보" :active="step === 1">
          <div class="px-3">
            <div class="subtitle_wrap2 Subtitle1">
              내놓을 집의 정보를 입력해주세요.
            </div>

            <div class="d-flex ">
              <div class="">
                <div class="input-title">대지면적</div>
                <div class="room-info-input-wrap">
                  <div class="input-group mb-3 border-1 border-light w-50">
                    <input type="text" class="form-control border-0" placeholder="" v-model="roomLandArea">
                    <span class="input-group-text">평</span>
                  </div>
                  <div>{{ Math.round(roomLandArea * 3.3) }}㎡</div>
                </div>
              </div>
              <div class="">
                <div class="input-title">연면적</div>
                <div class="room-info-input-wrap">
                  <div class="input-group mb-3 border-1 border-light w-50">
                    <input type="text" class="form-control border-0" placeholder="" v-model="roomGrossFloorArea">
                    <span class="input-group-text">평</span>
                  </div>
                  <div>{{ Math.round(roomGrossFloorArea * 3.3) }}㎡</div>
                </div>
              </div>
            </div>

            <div class="d-flex gap-3">
              <div class="flex-basis-50">
                <div class="input-title">지목</div>
                <select class="form-select form-select-lg mb-4" v-model="roomJimok">
                  <option value="전">전</option>
                  <option value="답">답</option>
                  <option value="과수원">과수원</option>
                  <option value="목장용지">목장용지</option>
                  <option value="임야">임야</option>
                  <option value="광천지">광천지</option>
                  <option value="염전">염전</option>
                  <option value="대">대</option>
                  <option value="공장용지">공장용지</option>
                  <option value="학교용지">학교용지</option>
                  <option value="주차장">주차장</option>
                  <option value="주유소용지">주유소용지</option>
                  <option value="창고용지">창고용지</option>
                  <option value="도로">도로</option>
                  <option value="철도용지">철도용지</option>
                  <option value="제방">제방</option>
                  <option value="하천">하천</option>
                  <option value="구거">구거</option>
                  <option value="유지">유지</option>
                  <option value="양어장">양어장</option>
                  <option value="수도용지">수도용지</option>
                  <option value="공원">공원</option>
                  <option value="체육용지">체육용지</option>
                  <option value="유원지">유원지</option>
                  <option value="종교용지">종교용지</option>
                  <option value="사적지">사적지</option>
                  <option value="묘지">묘지</option>
                  <option value="잡종지">잡종지</option>
                </select>
              </div>
              <div class="flex-basis-50">
                <div class="input-title">지역/지구</div>
                <select class="form-select form-select-lg mb-4" aria-label=".form-select-lg example">
                  <option selected>Default</option>
                  <option value="1">One</option>
                  <option value="2">Two</option>
                  <option value="3">Three</option>
                </select>
              </div>
            </div>

            <div class="d-flex gap-3">
              <div class="flex-basis-50">
                <div class="input-title">건축물 용도</div>
                <select class="form-select form-select-lg mb-4" v-model="roomBuildingUsage">
                  <option value="단독주택">단독주택</option>
                  <option value="공동주택">공동주택</option>
                  <option value="1종 근린생활시설">1종 근린생활시설</option>
                  <option value="2종 근린생활시설">2종 근린생활시설</option>
                  <option value="문화 및 집회시설">문화 및 집회시설</option>
                  <option value="종교시설">종교시설</option>
                  <option value="판매시설">판매시설</option>
                  <option value="운수시설">운수시설</option>
                  <option value="의료시설">의료시설</option>
                  <option value="교육연구시설">교육연구시설</option>
                  <option value="노유자시설">노유자시설</option>
                  <option value="수련시설">수련시설</option>
                  <option value="운동시설">운동시설</option>
                  <option value="업무시설">업무시설</option>
                  <option value="숙박시설">숙박시설</option>
                  <option value="위락시설">위락시설</option>
                  <option value="공장">공장</option>
                  <option value="창고시설">창고시설</option>
                  <option value="위험물 저장 및 처리 시설">위험물 저장 및 처리 시설</option>
                  <option value="자동차 관련 시설">자동차 관련 시설</option>
                  <option value="동물 및 식물 관련 시설">동물 및 식물 관련 시설</option>
                  <option value="자원순환 관련 시설">자원순환 관련 시설</option>
                  <option value="교정 및 군사시설">교정 및 군사시설</option>
                  <option value="방송통신시설">방송통신시설</option>
                  <option value="발전시설">발전시설</option>
                  <option value="묘지 관련 시설">묘지 관련 시설</option>
                  <option value="관광 휴게 시설">관광 휴게 시설</option>
                  <option value="장례시설">장례시설</option>
                  <option value="야영장시설">야영장시설</option>
                  <option value="미등기건물">미등기건물</option>
                  <option value="그 밖의 토지 정착물">그 밖의 토지 정착물</option>
                </select>
              </div>
              <div class="flex-basis-50">
                <div class="input-title">건물 구조</div>
                <select class="form-select form-select-lg mb-4" v-model="roomBuildingStructure">
                  <option value="철골(철골철근)콘트리트조">철골(철골철근)콘트리트조</option>
                  <option value="통나무조">통나무조</option>
                  <option value="스틸하우스조">스틸하우스조</option>
                  <option value="철근콘크리트조">철근콘크리트조</option>
                  <option value="라멘조">라멘조</option>
                  <option value="철골조">철골조</option>
                  <option value="석조">석조</option>
                  <option value="프리캐스트콘크리트조">프리캐스트콘크리트조</option>
                  <option value="목구조">목구조</option>
                  <option value="연와조">연와조</option>
                  <option value="보강콘크리트조">보강콘크리트조</option>
                  <option value="황토조">황토조</option>
                  <option value="보강블럭조">보강블럭조</option>
                  <option value="ALC조">ALC조</option>
                  <option value="와이어패널조">와이어패널조</option>
                  <option value="조립식패널조">조립식패널조</option>
                  <option value="시멘트벽돌조">시멘트벽돌조</option>
                  <option value="목조">목조</option>
                  <option value="경량철골조">경량철골조</option>
                  <option value="석회 및 흙벽돌조, 돌담 및 토담조">석회 및 흙벽돌조, 돌담 및 토담조</option>
                  <option value="철파이프조">철파이프조</option>
                  <option value="컨테이너 건물">컨테이너 건물</option>
                </select>
              </div>
            </div>

            <div class="pb-2">
              <div class="">
                <div class="input-title">승인일자</div>
                <div class="room-info-input-wrap">
                  <div class="input-group mb-3 border-1 border-light w-48">
                    <input type="text" class="form-control border-0" placeholder="날짜 입력" v-model="roomConfirmedAt">
                  </div>
                </div>
              </div>
            </div>


            <div class="d-flex gap-3 ">
              <div class="">
                <div class="input-title">대출 총액</div>
                <div class="room-info-input-wrap">
                  <div class="input-group mb-3 border-1 border-light">
                    <input type="text" class="form-control border-0" placeholder="" v-model="roomTotalLoan">
                    <span class="input-group-text" id="basic-addon2-1">원</span>
                  </div>
                </div>
              </div>
              <div class="">
                <div class="input-title">보증금 총액</div>
                <div class="room-info-input-wrap">
                  <div class="input-group mb-3 border-1 border-light">
                    <input type="text" class="form-control border-0" placeholder="" v-model="roomTotalDeposit">
                    <span class="input-group-text" id="basic-addon2-2">원</span>
                  </div>
                </div>
              </div>
            </div>

            <div class="d-flex gap-3 ">
              <div class="file-upload-wrap">
                <div class="filebox preview-image">
                  <input class="upload-name" value="파일선택" disabled="disabled" >
                  <label for="roomThumbnailImg">
                    <span class="btn-upload import">
                      <img src="../../../assets/img/icon/upload.svg">
                      <span class="Subtitle1 upload-txt light_txt_grey"><span>*</span>대표 사진 업로드</span>
                    </span>
                  </label>
                  <label for="roomThumbnailImg"><input type="file" id="roomThumbnailImg" class="upload-hidden" @change="preview($event)"></label>
                </div>
                <div class="filebox preview-image">
                  <input class="upload-name" value="파일선택" disabled="disabled" >
                  <label for="roomImg">
                    <span class="btn-upload import">
                      <img src="../../../assets/img/icon/upload.svg">
                      <span class="Subtitle1 upload-txt light_txt_grey"><span>*</span>방 사진 업로드</span>
                    </span>
                  </label>
                  <label for="roomImg"><input type="file" id="roomImg" class="upload-hidden" @change="preview"></label>
                </div>
                <div class="filebox preview-image">
                  <input class="upload-name" value="파일선택" disabled="disabled" >
                  <label for="roomDoorImg">
                  <span class="btn-upload import">
                    <img src="../../../assets/img/icon/upload.svg">
                    <span class="Subtitle1 upload-txt light_txt_grey"><span>*</span>현관 사진 업로드</span>
                  </span>
                </label>
                <label for="roomDoorImg"><input type="file" id="roomDoorImg" class="upload-hidden" @change="preview"></label>
              </div>
              <div class="filebox preview-image">
                <input class="upload-name" value="파일선택" disabled="disabled" >
                <label for="roomBathroomImg">
                  <span class="btn-upload import">
                      <img src="../../../assets/img/icon/upload.svg">
                    <span class="Subtitle1 upload-txt light_txt_grey"><span>*</span>화장실 사진 업로드</span>
                  </span>
                </label>
                <label for="roomBathroomImg"><input type="file" id="roomBathroomImg" class="upload-hidden" @change="preview"></label>
              </div>

              <div class="filebox preview-image">
                <input class="upload-name" value="파일선택" disabled="disabled" >
                <label for="roomOptionalImg1">
                  <span class="btn-upload">
                      <img src="../../../assets/img/icon/upload.svg">
                    <span class="Subtitle1 upload-txt light_txt_grey">거실 사진 업로드</span>
                  </span>
                </label>
                <label for="roomOptionalImg1"><input type="file" id="roomOptionalImg1" class="upload-hidden" @change="preview"></label>
              </div>
              <div class="filebox preview-image">
                <input class="upload-name" value="파일선택" disabled="disabled" >
                <label for="roomOptionalImg2">
                  <span class="btn-upload">
                      <img src="../../../assets/img/icon/upload.svg">
                    <span class="Subtitle1 upload-txt light_txt_grey">사진 업로드</span>
                  </span>
                </label>
                <label for="roomOptionalImg2"><input type="file" id="roomOptionalImg2" class="upload-hidden" @change="preview"></label>
              </div>
              <div class="filebox preview-image">
                <input class="upload-name" value="파일선택" disabled="disabled" >
                <label for="roomOptionalImg3">
                  <span class="btn-upload">
                      <img src="../../../assets/img/icon/upload.svg">
                    <span class="Subtitle1 upload-txt light_txt_grey">사진 업로드</span>
                  </span>
                </label>
                <label for="roomOptionalImg3"><input type="file" id="roomOptionalImg3" class="upload-hidden" @change="preview"></label>
              </div>
              <div class="filebox preview-image">
                <input class="upload-name" value="파일선택" disabled="disabled" >
                <label for="roomOptionalImg4">
                  <span class="btn-upload">
                      <img src="../../../assets/img/icon/upload.svg">
                    <span class="Subtitle1 upload-txt light_txt_grey">사진 업로드</span>
                  </span>
                </label>
                <label for="roomOptionalImg4"><input type="file" id="roomOptionalImg4" class="upload-hidden" @change="preview"></label>
              </div>
              </div>
            </div>

          </div>
          <div class="bottom-btn-group-50 bottom-0 justify-content-end" role="group" aria-label="Basic example">
            <button type="button" class="btn btn-lg btn-outline-light" @click="step = 0">이전</button>
            <button type="button" class="btn btn-lg btn-outline-primary"@click="step = 2">다음</button>
          </div>
        </b-tab>

        <b-tab title="임대정보" :active="step === 2">
          <div class="px-3">
            <div class="subtitle_wrap2 Subtitle1">
             거래유형과 가격 정보를 알려주세요.
            </div>

            <div class="d-flex gap-4 pb-4">

              <div class="form-check">
                <input class="form-check-input" type="radio" id="roomContractType1" value="월세" v-model="roomContractType">
                <label class="form-check-label" for="roomContractType1">
                  월세
                </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" id="roomContractType2" value="전세" v-model="roomContractType">
                <label class="form-check-label" for="roomContractType2">
                  전세
                </label>
              </div>
            </div>

            <div class="d-flex gap-3">
              <div class="w-50">
                <div class="input-title">보증금</div>
                <div class="room-info-input-wrap">
                  <div class="input-group mb-3 border-1 border-light">
                    <input type="text" class="form-control border-0" placeholder="" v-model="roomDeposit">
                    <span class="input-group-text" id="basic-addon2">만원</span>
                  </div>
                 </div>
              </div>
              <div class="w-50" id="month-m">
                <div class="input-title">월차임</div>
                <div class="room-info-input-wrap">
                  <div class="input-group mb-3 border-1 border-light">
                    <input type="text" class="form-control border-0" placeholder="" v-model="roomMonthlyPrice" :disabled="roomContractType === '전세'">
                    <span class="input-group-text" id="basic-addon2">만원</span>
                  </div>
                 </div>
              </div>
            </div>

            <div class="d-flex gap-3 align-items-center">
              <div class="">
                <div class="input-title">관리비</div>
                <div class="room-info-input-wrap">
                  <div class="input-group border-1 border-light w-50">
                    <input type="text" class="form-control border-0 " placeholder="" v-model="roomManageFee">
                    <span class="input-group-text" id="basic-addon2">만원</span>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="" id="admin-none" @click="roomManageFee = '0'">
                    <label class="form-check-label" for="admin-none">
                      관리비가 없습니다.
                    </label>
                  </div>
                </div>
              </div>
             </div>

            <div v-if="roomManageFee !== '0'" id="admin-none-wrap">
              <div class="Subtitle1 pt-4">관리비 포함 내역</div>
              <div class="grid3-checkbox-wrap px-0 pt-4">
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="checkbox" id="inlineCheckbox10" value="수도" v-model="roomManageOptions">
                  <label class="form-check-label" for="inlineCheckbox10">수도</label>
                </div>
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="checkbox" id="inlineCheckbox11" value="전기" v-model="roomManageOptions">
                  <label class="form-check-label" for="inlineCheckbox11">전기</label>
                </div>
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="checkbox" id="inlineCheckbox12" value="가스" v-model="roomManageOptions">
                  <label class="form-check-label" for="inlineCheckbox12">가스</label>
                </div>
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="checkbox" id="inlineCheckbox13" value="공동경비" v-model="roomManageOptions">
                  <label class="form-check-label" for="inlineCheckbox13">공동경비</label>
                </div>
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="checkbox" id="inlineCheckbox14" value="주차비" v-model="roomManageOptions">
                  <label class="form-check-label" for="inlineCheckbox14">주차비</label>
                </div>
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="checkbox" id="inlineCheckbox15" value="정화조" v-model="roomManageOptions">
                  <label class="form-check-label" for="inlineCheckbox15">정화조</label>
                </div>
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="checkbox" id="inlineCheckbox16" value="계단청소" v-model="roomManageOptions">
                  <label class="form-check-label" for="inlineCheckbox16">계단청소</label>
                </div>
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="checkbox" id="inlineCheckbox17" value="인터넷" v-model="roomManageOptions">
                  <label class="form-check-label" for="inlineCheckbox17">인터넷</label>
                </div>
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="checkbox" id="inlineCheckbox18" value="유선TV" v-model="roomManageOptions">
                  <label class="form-check-label" for="inlineCheckbox18">유선TV</label>
                </div>
              </div>
            </div>

            <div class="subtitle_wrap2 Subtitle1 pt-4">입주가능일은 언제인가요?</div>

            <div class="pb-2">
              <div class="">
                <div class="input-title">입주가능일</div>
                <div class="room-info-input-wrap">
                  <div class="input-group mb-3 border-1 border-light">
                    <input type="text" class="form-control border-0" placeholder="EX) 2월 중순, 2월 12일" v-model="roomAvailableAt">
                  </div>
                </div>
              </div>
            </div>
            <div class="subtitle_wrap2 Subtitle1">크기와 구조는 어떻게 되어있나요?</div>
            <div class="d-flex gap-3">
              <div class="flex-basis-50">
                <div class="input-title">집 형태</div>
                <select class="form-select form-select-lg mb-4" v-model="roomHouseType">
                  <option value="빌라형">빌라형</option>
                  <option value="오피스텔형">오피스텔형</option>
                  <option value="단독형">단독형</option>
                </select>
              </div>
              <div class="flex-basis-50">
                <div class="input-title">방 구조</div>
                <select class="form-select form-select-lg mb-4" v-model="roomType">
                  <option value="오픈형 원룸">오픈형 원룸</option>
                  <option value="분리형 원룸">분리형 원룸</option>
                  <option value="복층형 원룸">복층형 원룸</option>
                </select>
              </div>
            </div>

            <div class="d-flex gap-3">
              <div class="flex-basis-50">
                <div class="input-title">총 층수</div>
                <select class="form-select form-select-lg mb-4" v-model="roomTotalFloor">
                  <option value="반지하">반지하</option>
                  <option value="1" selected>1층</option>
                  <option value="2">2층</option>
                  <option value="3">3층</option>
                  <option value="4">4층</option>
                  <option value="5">5층</option>
                  <option value="6">6층</option>
                  <option value="7">7층</option>
                  <option value="8">8층</option>
                  <option value="9">9층</option>
                  <option value="10">10층</option>
                  <option value="11">11층</option>
                  <option value="12">12층</option>
                  <option value="13">13층</option>
                  <option value="14">14층</option>
                  <option value="15">15층</option>
                  <option value="16">16층</option>
                  <option value="17">17층</option>
                  <option value="18">18층</option>
                  <option value="19">19층</option>
                  <option value="20">20층</option>
                  <option value="옥탑">옥탑</option>
                </select>
              </div>
              <div class="flex-basis-50">
                <div class="input-title">층수</div>
                <select class="form-select form-select-lg mb-4" v-model="roomFloor">
                  <option value="반지하">반지하</option>
                  <option value="1" selected>1층</option>
                  <option value="2">2층</option>
                  <option value="3">3층</option>
                  <option value="4">4층</option>
                  <option value="5">5층</option>
                  <option value="6">6층</option>
                  <option value="7">7층</option>
                  <option value="8">8층</option>
                  <option value="9">9층</option>
                  <option value="10">10층</option>
                  <option value="11">11층</option>
                  <option value="12">12층</option>
                  <option value="13">13층</option>
                  <option value="14">14층</option>
                  <option value="15">15층</option>
                  <option value="16">16층</option>
                  <option value="17">17층</option>
                  <option value="18">18층</option>
                  <option value="19">19층</option>
                  <option value="20">20층</option>
                  <option value="옥탑">옥탑</option>
                </select>
              </div>
            </div>

            <div class="d-flex gap-3">
              <div class="flex-basis-50">
                <div class="input-title">방향 (창문기준)</div>
                <select class="form-select form-select-lg mb-4" v-model="roomDirection">
                  <option value="남향" selected>남향</option>
                  <option value="남동향">남동향</option>
                  <option value="동향">동향</option>
                  <option value="북동향">북동향</option>
                  <option value="북향">북향</option>
                  <option value="북서향">북서향</option>
                  <option value="서향">서향</option>
                  <option value="남서향">남서향</option>
                </select>
              </div>

              <div class="w-50">
                <div class="input-title">방 평수</div>
                <div class="room-info-input-wrap">
                  <div class="input-group mb-3 border-1 border-light w-50">
                    <input type="text" class="form-control border-0" placeholder="" v-model="roomArea">
                    <span class="input-group-text" id="basic-addon2">평</span>
                  </div>
                  <div>{{ Math.round(roomArea * 3.3) }}㎡</div>
                </div>
              </div>
            </div>
          </div>
          <div class="bottom-btn-group-50 bottom-0 justify-content-end" role="group" aria-label="Basic example">
            <button type="button" class="btn btn-lg btn-outline-light" @click="step = 1">이전</button>
            <button type="button" class="btn btn-lg btn-outline-primary" @click="step = 3">다음</button>
          </div>
        </b-tab>
        <b-tab title="옵션" :active="step === 3">

          <div class="px-3">
            <div class="subtitle_wrap2 Subtitle1">
              기본 옵션 <span class="body1 light_txt_lgrey">(4개 이상 체크시 풀옵션 적용)</span>
            </div>

            <div class="grid3-checkbox-wrap px-0">
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox19" value="에어컨" v-model="roomBasicOptions">
                <label class="form-check-label" for="inlineCheckbox19">에어컨</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox20" value="냉장고" v-model="roomBasicOptions">
                <label class="form-check-label" for="inlineCheckbox20">냉장고</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox21" value="세탁기" v-model="roomBasicOptions">
                <label class="form-check-label" for="inlineCheckbox21">세탁기</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox22" value="가스렌지" v-model="roomBasicOptions">
                <label class="form-check-label" for="inlineCheckbox22">가스렌지</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox23" value="쿡탑" v-model="roomBasicOptions">
                <label class="form-check-label" for="inlineCheckbox23">쿡탑</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox24" value="침대" v-model="roomBasicOptions">
                <label class="form-check-label" for="inlineCheckbox24">침대</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox25" value="옷장" v-model="roomBasicOptions">
                <label class="form-check-label" for="inlineCheckbox25">옷장</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox26" value="신발장" v-model="roomBasicOptions">
                <label class="form-check-label" for="inlineCheckbox26">신발장</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox27" value="책상" v-model="roomBasicOptions">
                <label class="form-check-label" for="inlineCheckbox27">책상</label>
              </div>
            </div>
            <div class="py-30">
              <div class="">
                <div class="input-title">기타 사항</div>
                <div class="room-info-input-wrap">
                  <div class="input-group mb-3 border-1 border-light">
                    <input type="text" class="form-control border-0" placeholder="입력란" v-model="roomBasicOptionsMemo">
                  </div>
                </div>
              </div>

            </div>


            <div class="subtitle_wrap2 Subtitle1 pt-2">
              기타 시설
            </div>
            <div class="grid3-checkbox-wrap px-0">
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox30" value="true" v-model="roomExistEv">
                <label class="form-check-label" for="inlineCheckbox30">E / V</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox31" value="true" v-model="roomCanParking">
                <label class="form-check-label" for="inlineCheckbox31">주차</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox32" value="true" v-model="roomExistVeranda">
                <label class="form-check-label" for="inlineCheckbox32">베란다</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox33" value="true" v-model="roomExistStorage">
                <label class="form-check-label" for="inlineCheckbox33">창고</label>
              </div>
            </div>

            <div v-if="roomCanParking" id="parking-num" class="input-group mb-3 align-items-center pt-3">
              <span class="pe-3">주차 가능대수 : </span>
              <input type="text" class="form-control w-100 mt-2" placeholder="숫자로 적어주세요">
            </div>


            <div class="py-30">
              <div class="">
                <div class="input-title">기타 사항</div>
                <div class="room-info-input-wrap">
                  <div class="input-group mb-3 border-1 border-light">
                    <input type="text" class="form-control border-0" placeholder="입력란" v-model="roomFacilityMemo">
                  </div>
                </div>
              </div>

            </div>


            <div class="subtitle_wrap2 Subtitle1 pt-2">그 외</div>

            <div class="d-flex gap-3">
              <div class="flex-basis-50">
                <div class="input-title">도배</div>
                <select class="form-select form-select-lg" v-model="roomCanPapering">
                  <option value="true">가능</option>
                  <option value="false" selected>불가능</option>
                </select>
              </div>
              <div class="flex-basis-50">
                <div class="input-title">장판</div>
                <select class="form-select form-select-lg" v-model="roomCanFloor">
                  <option value="true">가능</option>
                  <option value="false" selected>불가능</option>
                </select>
              </div>
            </div>
          </div>
          <div class="bottom-btn-group-50 bottom-0 justify-content-end" role="group" aria-label="Basic example">
            <button type="button" class="btn btn-lg btn-outline-light" @click="step = 2">이전</button>
            <button type="button" class="btn btn-lg btn-outline-primary" @click="step = 4">다음</button>
          </div>

        </b-tab>
        <b-tab title="기타" :active="step === 4">
          <div class="px-3">
            <div class="subtitle_wrap2 Subtitle1">
              대출 관련
            </div>
            <div class="btn-group3">
              <input type="radio" class="btn-check" name="options" id="bank1" autocomplete="off" value="true" v-model="roomCanLoan">
              <label class="btn btn-shadow-outline shadow2 w-50" for="bank1">가능</label>
              <input type="radio" class="btn-check" name="options" id="bank2" autocomplete="off" value="false" v-model="roomCanLoan">
              <label class="btn btn-shadow-outline shadow2 w-50" for="bank2">불가능</label>
             </div>

            <div class="py-30">
              <div class="">
                <div class="input-title">대출 관련 입력 사항</div>
                <div class="room-info-input-wrap">
                  <div class="input-group mb-3 border-1 border-light">
                    <input type="text" class="form-control border-0" placeholder="입력란" v-model="roomLoanMemo">
                  </div>
                </div>
              </div>
            </div>

            <div class="subtitle_wrap2 Subtitle1 pt-2">
              반려동물
            </div>
            <div class="btn-group3">
              <input type="radio" class="btn-check" name="pet" id="pet1" autocomplete="off" value="true" v-model="roomCanPet">
              <label class="btn btn-shadow-outline shadow2 w-50" for="pet1">가능</label>
              <input type="radio" class="btn-check" name="pet" id="pet2" autocomplete="off" value="false" v-model="roomCanPet">
              <label class="btn btn-shadow-outline shadow2 w-50" for="pet2">불가능</label>
             </div>
            <div v-if="roomCanPet == 'true' " class="grid3-checkbox-wrap pt-4">
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox34" value="강아지" v-model="roomPetOptions">
                <label class="form-check-label" for="inlineCheckbox34">강아지</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox35" value="고양이" v-model="roomPetOptions">
                <label class="form-check-label" for="inlineCheckbox35">고양이</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox36" value="조류" v-model="roomPetOptions">
                <label class="form-check-label" for="inlineCheckbox36">조류</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox37" value="파충류" v-model="roomPetOptions">
                <label class="form-check-label" for="inlineCheckbox37">파충류</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox38" value="협의" v-model="roomPetOptions">
                <label class="form-check-label" for="inlineCheckbox38">협의</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input border-0" type="checkbox" id="inlineCheckbox39" value="option38" disabled>
                <label class="form-check-label" for="inlineCheckbox39"></label>
              </div>
            </div>
            <div class="py-30">
              <div class="">
                <div class="input-title">반려동물 관련 입력 사항</div>
                <div class="room-info-input-wrap">
                  <div class="input-group mb-2 border-1 border-light">
                    <input type="text" class="form-control border-0" placeholder="입력란" v-model="roomPetMemo">
                  </div>
                </div>
              </div>
            </div>
            <div class="input-title">메모</div>
            <textarea class="form-control" aria-label="With textarea" v-model="roomMemo"></textarea>
          </div>
          <div class="bottom-btn-group bottom-0" role="group" aria-label="Basic example">
            <button type="button" class="btn btn-full w-100 btn-primary" @click="submit">방 등록하기</button>
          </div>
        </b-tab>
      </b-tabs>
    </div>
    <!--content e-->
  </div>
</template>

<script>
import {forEach} from "lodash";

export default {
  head: {
    script: [
      { type: "text/javascript", src: "//dapi.kakao.com/v2/maps/sdk.js?appkey=b5935936ae15baa0443c34db10cca0d9&libraries=services" }
    ]
  },
  async asyncData({ app }) {
    const uid = app.$cookies.get('uid');

    return { uid };
  },
  data() {
    return {
      step: 0,
      isHostOk: false,
      roomImages: {},
      roomAddr1: '',
      roomAddr2: '',
      roomSiDo: '',
      roomSiGunGu: '',
      roomEupMyeonDong: '',
      roomLat: '',
      roomLng: '',
      roomHostMobile: '',
      roomLandArea: 1,
      roomGrossFloorArea: 1,
      roomJimok: '전',
      roomBuildingUsage: '단독주택',
      roomBuildingStructure: '철골(철골철근)콘트리트조',
      roomConfirmedAt: '',
      roomTotalLoan: 0,
      roomTotalDeposit: 0,
      roomThumbnailImg: '',
      roomImg: '',
      roomDoorImg: '',
      roomBathroomImg: '',
      roomOptionalImg1: '',
      roomOptionalImg2: '',
      roomOptionalImg3: '',
      roomOptionalImg4: '',
      roomContractType: '월세',
      roomDeposit: 1,
      roomMonthlyPrice: 0,
      roomManageFee: 0,
      roomManageOptions: [],
      roomAvailableAt: '',
      roomHouseType: '빌라형',
      roomType: '오픈형 원룸',
      roomTotalFloor: '1',
      roomFloor: '1',
      roomDirection: '남향',
      roomArea: 1,
      roomBasicOptions: [],
      roomIsFullOption: false,
      roomBasicOptionsMemo: '',
      roomCanParking: false,
      roomParkingCount: 0,
      roomExistEv: false,
      roomExistVeranda: false,
      roomExistStorage: false,
      roomFacilityMemo: '',
      roomCanPapering: false,
      roomCanFloor: false,
      roomCanLoan: false,
      roomLoanMemo: '',
      roomCanPet: false,
      roomPetOptions: [],
      roomPetMemo: '',
      roomMemo: ''
    }
  },
  methods: {
    searchAddress() {
      let lat = '';
      let lng = '';
      new daum.Postcode({
        oncomplete: (data) => {
          // 팝업에서 검색결과 항목을 클릭했을때 실행할 코드를 작성하는 부분.

          // 각 주소의 노출 규칙에 따라 주소를 조합한다.
          // 내려오는 변수가 값이 없는 경우엔 공백('')값을 가지므로, 이를 참고하여 분기 한다.
          let addr = ''; // 주소 변수
          let detailAddr = ''; // 참고항목 변수

          //사용자가 선택한 주소 타입에 따라 해당 주소 값을 가져온다.
          if (data.userSelectedType === 'R') { // 사용자가 도로명 주소를 선택했을 경우
            addr = data.roadAddress;
          } else { // 사용자가 지번 주소를 선택했을 경우(J)
            addr = data.jibunAddress;
          }

          // 사용자가 선택한 주소가 도로명 타입일때 참고항목을 조합한다.
          if(data.userSelectedType === 'R'){
            // 법정동명이 있을 경우 추가한다. (법정리는 제외)
            // 법정동의 경우 마지막 문자가 "동/로/가"로 끝난다.
            if(data.bname !== '' && /[동|로|가]$/g.test(data.bname)){
              detailAddr += data.bname;
            }
            // 건물명이 있고, 공동주택일 경우 추가한다.
            if(data.buildingName !== '' && data.apartment === 'Y'){
              detailAddr += (detailAddr !== '' ? ', ' + data.buildingName : data.buildingName);
            }
            // 표시할 참고항목이 있을 경우, 괄호까지 추가한 최종 문자열을 만든다.
            if(detailAddr !== ''){
              detailAddr = ' (' + detailAddr + ')';
            }
            // 조합된 참고항목을 해당 필드에 넣는다.
            // document.getElementById("sample6_extraAddress").value = detailAddr;

          } else {
            // document.getElementById("sample6_extraAddress").value = '';
          }

          // 지번 주소를 spilt 하여 구분 후 각 정보를 해당 필드에 넣는다.
          // 시,도 / 시,군,구 / 읍,면,동
          document.getElementById('roomSiDo').value = data.sido;
          this.roomSiDo = data.sido;
          document.getElementById('roomSiGunGu').value = data.sigungu;
          this.roomSiGunGu = data.sigungu;
          document.getElementById('roomEupMyeonDong').value = data.bname;
          this.roomEupMyeonDong = data.bname;

          // 주소 정보를 해당 필드에 넣는다.
          document.getElementById('roomAddr1').value = addr;
          this.roomAddr1 = addr;
          // document.getElementById('roomAddr2').focus();
          console.log(this.roomSiDo)
          console.log(this.roomSiGunGu)
          console.log(this.roomEupMyeonDong)
          console.log(this.roomAddr1);
        }
      }).open();
    },
    async preview(event) {
      try {
        let imgTarget = $('.preview-image .upload-hidden');

        imgTarget.on('change', function(){
          let parent = $(this).parent();
          parent.children('.upload-display').remove();

          if(window.FileReader){
            //image 파일만
            if (!$(this)[0].files[0].type.match(/image\//)) return;

            let reader = new FileReader();
            reader.onload = function(e){
              let src = e.target.result;
              parent.prepend('<div class="upload-display"><div class="upload-thumb-wrap"><img src="'+src+'" class="upload-thumb"></div></div>');
            }
            reader.readAsDataURL($(this)[0].files[0]);
          }
        });

        await this.upload(event);
      } catch (e) {
        if (e.response) console.log(e.response.data.message);
      }
    },
    async upload(event) {
      try {
        const { files } = event.target;
        this.roomImages[event.target.id] = files[0];
      } catch (e) {
        if (e.response) console.log(e.response.data.message);
      }
    },
    async submit() {
      try {
        // 이미지 s3 업로드
        for(const key of Object.keys(this.roomImages)) {
          if (key == 'roomThumbnailImg') {
            const form = new FormData();
            form.append('file', this.roomImages[key]);
            const { data: result } = await this.$axios.post('/user/upload', form);
            this.roomThumbnailImg = result.location;
          }

          if (key == 'roomImg') {
            const form = new FormData();
            form.append('file', this.roomImages[key]);
            const { data: result } = await this.$axios.post('/user/upload', form);
            this.roomImg = result.location;
          }

          if (key == 'roomDoorImg') {
            const form = new FormData();
            form.append('file', this.roomImages[key]);
            const { data: result } = await this.$axios.post('/user/upload', form);
            this.roomDoorImg = result.location;
          }

          if (key == 'roomBathroomImg') {
            const form = new FormData();
            form.append('file', this.roomImages[key]);
            const { data: result } = await this.$axios.post('/user/upload', form);
            this.roomBathroomImg = result.location;
          }

          if (key == 'roomOptionalImg1') {
            const form = new FormData();
            form.append('file', this.roomImages[key]);
            const { data: result } = await this.$axios.post('/user/upload', form);
            this.roomOptionalImg1 = result.location;
          }

          if (key == 'roomOptionalImg2') {
            const form = new FormData();
            form.append('file', this.roomImages[key]);
            const { data: result } = await this.$axios.post('/user/upload', form);
            this.roomOptionalImg2 = result.location;
          }

          if (key == 'roomOptionalImg3') {
            const form = new FormData();
            form.append('file', this.roomImages[key]);
            const { data: result } = await this.$axios.post('/user/upload', form);
            this.roomOptionalImg3 = result.location;
          }

          if (key == 'roomOptionalImg4') {
            const form = new FormData();
            form.append('file', this.roomImages[key]);
            const { data: result } = await this.$axios.post('/user/upload', form);
            this.roomOptionalImg4 = result.location;
          }

        }

        // 풀옵션 여부 확인
        if (this.roomBasicOptions.length >= 4) {
          this.roomIsFullOption = true;
        }

        if (this.roomManageFee == '0') {
          this.roomManageOptions = [];
        }

        if (this.roomCanPet == 'false') {
          this.roomPetOptions = [];
        }

        if (this.roomCanParking !== "true") {
          this.roomParkingCount = 0;
        }

        const format = {
          roomAddr1: this.roomAddr1,
          roomAddr2: this.roomAddr2,
          roomSiDo: this.roomSiDo,
          roomSiGunGu: this.roomSiGunGu,
          roomEupMyeonDong: this.roomEupMyeonDong,
          roomLat: this.roomLat,
          roomLng: this.roomLng,
          roomHostMobile: this.roomHostMobile,
          roomLandArea: this.roomLandArea,
          roomGrossFloorArea: this.roomGrossFloorArea,
          roomJimok: this.roomJimok,
          roomBuildingUsage: this.roomBuildingUsage,
          roomBuildingStructure: this.roomBuildingStructure,
          roomConfirmedAt: this.roomConfirmedAt,
          roomTotalLoan: this.roomTotalLoan,
          roomTotalDeposit: this.roomTotalDeposit,
          roomThumbnailImg: this.roomThumbnailImg,
          roomImg: this.roomImg,
          roomDoorImg: this.roomDoorImg,
          roomBathroomImg: this.roomBathroomImg,
          roomOptionalImg1: this.roomOptionalImg1,
          roomOptionalImg2: this.roomOptionalImg2,
          roomOptionalImg3: this.roomOptionalImg3,
          roomOptionalImg4: this.roomOptionalImg4,
          roomContractType: this.roomContractType,
          roomDeposit: this.roomDeposit,
          roomMonthlyPrice: this.roomMonthlyPrice,
          roomManageFee: this.roomManageFee,
          roomManageOptions: this.roomManageOptions,
          roomAvailableAt: this.roomAvailableAt,
          roomHouseType: this.roomHouseType,
          roomType: this.roomType,
          roomTotalFloor: this.roomTotalFloor,
          roomFloor: this.roomFloor,
          roomDirection: this.roomDirection,
          roomArea: this.roomArea,
          roomBasicOptions: this.roomBasicOptions,
          roomIsFullOption: this.roomIsFullOption,
          roomBasicOptionsMemo: this.roomBasicOptionsMemo,
          roomCanParking: this.roomCanParking,
          roomParkingCount: this.roomParkingCount,
          roomExistEv: this.roomExistEv,
          roomExistVeranda: this.roomExistVeranda,
          roomExistStorage: this.roomExistStorage,
          roomFacilityMemo: this.roomFacilityMemo,
          roomCanPapering: this.roomCanPapering,
          roomCanFloor: this.roomCanFloor,
          roomCanLoan: this.roomCanLoan,
          roomLoanMemo: this.roomLoanMemo,
          roomCanPet: this.roomCanPet,
          roomPetOptions: this.roomPetOptions,
          roomPetMemo: this.roomPetMemo,
          roomMemo: this.roomMemo,
          roomMember: this.uid
        }

        console.log(format);
        await this.$axios.post('/user/add/room', { ...format });
        this.$router.replace('/main/home')
      } catch (e) {
        if (e.response) console.log(e.response.data.message);
      }
    }
  }
}
</script>