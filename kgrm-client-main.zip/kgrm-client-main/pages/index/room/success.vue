<template>
    <div id="app">
 
<!--content s-->
<div class="container pb-8">

  <div class="center-wrap">
<div class="subtitle_wrap Subtitle1 text-center">
<img src="../../../assets/img/3d/paper2.png" class="w-13rem" data-aos="fade-up" data-aos-delay="200" data-aos-duration="1000">
<h3 class="pt-3">
매물 등록이<br>
완료되었습니다!
</h3>

<div class="body1 pt-2">
이제 마이페이지 > 나의 매물에서<br>
등록 현황을 확인하실 수 있어요.
</div>
</div>

   </div>
  </div>
  <div class="bottom-btn-group" role="group" aria-label="Basic example">
    <b-button type="button" class="btn btn-full btn-primary w-100" onclick="location.href='/main/my'">나의 매물 바로가기</b-button>

  </div>
</div>
<!--content e-->

</div>
</template>
 