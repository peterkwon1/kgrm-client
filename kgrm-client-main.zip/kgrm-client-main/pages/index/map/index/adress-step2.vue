<template>
    <div id="app">
  <!--header s-->
  <header class="d-flex bg-transparent flex-wrap align-items-center justify-content-between py-2">
    <div class="header_title Subtitle1">지역 검색</div>
    <ul class="nav nav-pills position-absolute end-1">
      <li class="nav-item">
        <b-button type="button" class="btn btn-sm btn-link">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M6.53033 5.46967C6.23744 5.17678 5.76256 5.17678 5.46967 5.46967C5.17678 5.76256 5.17678 6.23744 5.46967 6.53033L6.53033 5.46967ZM17.4697 18.5303C17.7626 18.8232 18.2374 18.8232 18.5303 18.5303C18.8232 18.2374 18.8232 17.7626 18.5303 17.4697L17.4697 18.5303ZM5.46967 6.53033L17.4697 18.5303L18.5303 17.4697L6.53033 5.46967L5.46967 6.53033Z" fill="#232C34"/>
<path d="M18.5303 6.53033C18.8232 6.23744 18.8232 5.76256 18.5303 5.46967C18.2374 5.17678 17.7626 5.17678 17.4697 5.46967L18.5303 6.53033ZM5.46967 17.4697C5.17678 17.7626 5.17678 18.2374 5.46967 18.5303C5.76256 18.8232 6.23744 18.8232 6.53033 18.5303L5.46967 17.4697ZM17.4697 5.46967L5.46967 17.4697L6.53033 18.5303L18.5303 6.53033L17.4697 5.46967Z" fill="#232C34"/>
</svg>

        </b-button>
      </li>
    </ul>
  </header>
  <!--header e-->

  <!--content s-->
  <div class="container">

    <div class="map_select_wrap border-bottom">
    <p>서울시</p>
    <span class="material-symbols-outlined body1">arrow_forward_ios</span>
    <p class="cl_primary">시/군/구</p>
    <span class="material-symbols-outlined body1">arrow_forward_ios</span>
    <p>읍/면/동</p>
  </div>

  <ul class="area_list--district" onclick="location.href='adress-step3'">
    <li class="area_item"><input type="radio" name="area" id="area0" class="radio_input" data-nclk="FAS.gu"><label for="area0" class="radio_label_district">강남구</label></li>
    <li class="area_item"><input type="radio" name="area" id="area1" class="radio_input" data-nclk="FAS.gu"><label for="area1" class="radio_label_district">강동구</label></li>
    <li class="area_item"><input type="radio" name="area" id="area2" class="radio_input" data-nclk="FAS.gu"><label for="area2" class="radio_label_district">강북구</label></li>
    <li class="area_item"><input type="radio" name="area" id="area3" class="radio_input" data-nclk="FAS.gu"><label for="area3" class="radio_label_district">강서구</label></li>
    <li class="area_item"><input type="radio" name="area" id="area4" class="radio_input" data-nclk="FAS.gu"><label for="area4" class="radio_label_district">관악구</label></li>
    <li class="area_item"><input type="radio" name="area" id="area5" class="radio_input" data-nclk="FAS.gu"><label for="area5" class="radio_label_district">광진구</label></li>
    <li class="area_item"><input type="radio" name="area" id="area6" class="radio_input" data-nclk="FAS.gu"><label for="area6" class="radio_label_district">구로구</label></li>
    <li class="area_item"><input type="radio" name="area" id="area7" class="radio_input" data-nclk="FAS.gu"><label for="area7" class="radio_label_district">금천구</label></li>
    <li class="area_item"><input type="radio" name="area" id="area8" class="radio_input" data-nclk="FAS.gu"><label for="area8" class="radio_label_district">노원구</label></li>
    <li class="area_item"><input type="radio" name="area" id="area9" class="radio_input" data-nclk="FAS.gu"><label for="area9" class="radio_label_district">도봉구</label></li>
    <li class="area_item"><input type="radio" name="area" id="area10" class="radio_input" data-nclk="FAS.gu"><label for="area10" class="radio_label_district">동대문구</label></li>
    <li class="area_item"><input type="radio" name="area" id="area11" class="radio_input" data-nclk="FAS.gu"><label for="area11" class="radio_label_district">동작구</label></li>
    <li class="area_item"><input type="radio" name="area" id="area12" class="radio_input" data-nclk="FAS.gu"><label for="area12" class="radio_label_district">마포구</label></li>
    <li class="area_item"><input type="radio" name="area" id="area13" class="radio_input" data-nclk="FAS.gu"><label for="area13" class="radio_label_district">서대문구</label></li>
    <li class="area_item"><input type="radio" name="area" id="area14" class="radio_input" data-nclk="FAS.gu"><label for="area14" class="radio_label_district">서초구</label></li>
    <li class="area_item"><input type="radio" name="area" id="area15" class="radio_input" data-nclk="FAS.gu"><label for="area15" class="radio_label_district">성동구</label></li>
    <li class="area_item"><input type="radio" name="area" id="area16" class="radio_input" data-nclk="FAS.gu"><label for="area16" class="radio_label_district">성북구</label></li>
    <li class="area_item"><input type="radio" name="area" id="area17" class="radio_input" data-nclk="FAS.gu"><label for="area17" class="radio_label_district">송파구</label></li>
    <li class="area_item"><input type="radio" name="area" id="area18" class="radio_input" data-nclk="FAS.gu"><label for="area18" class="radio_label_district">양천구</label></li>
    <li class="area_item"><input type="radio" name="area" id="area19" class="radio_input" data-nclk="FAS.gu"><label for="area19" class="radio_label_district">영등포구</label></li>
    <li class="area_item"><input type="radio" name="area" id="area20" class="radio_input" data-nclk="FAS.gu"><label for="area20" class="radio_label_district">용산구</label></li>
    <li class="area_item"><input type="radio" name="area" id="area21" class="radio_input" data-nclk="FAS.gu"><label for="area21" class="radio_label_district">은평구</label></li>
    <li class="area_item"><input type="radio" name="area" id="area22" class="radio_input" data-nclk="FAS.gu"><label for="area22" class="radio_label_district">종로구</label></li>
    <li class="area_item"><input type="radio" name="area" id="area23" class="radio_input" data-nclk="FAS.gu"><label for="area23" class="radio_label_district">중구</label></li>
    <li class="area_item"><input type="radio" name="area" id="area24" class="radio_input" data-nclk="FAS.gu"><label for="area24" class="radio_label_district">중랑구</label></li>
  </ul>
  
  </div>

  <!--content e-->

  
    </div>

</template>