<template>



  <div class="main-container">
    <div class="main-contents">
      <nuxt-child/>
    </div>


    <div class="main-footer-safearea">
      <div class="main-footer">
        <nuxt-link class="footer-link-box" to="/main/home">
          <div class="footer-link-img">
          <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                              <path d="M12.5 17.99V14.99M9.52 2.84001L4.13 7.04001C3.23 7.74001 2.5 9.23001 2.5 10.36V17.77C2.5 20.09 4.39 21.99 6.71 21.99H18.29C20.61 21.99 22.5 20.09 22.5 17.78V10.5C22.5 9.29001 21.69 7.74001 20.7 7.05001L14.52 2.72001C13.12 1.74001 10.87 1.79001 9.52 2.84001Z" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                          </svg>
                          </div>
          <div class="footer-label">홈</div>
        </nuxt-link>
        <nuxt-link class="footer-link-box" to="/main/map" >
          <div class="footer-link-img">
          <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                              <path d="M9.06001 4.00001V17M16.23 6.62001V20M2.79001 7.78001V17.51C2.79001 19.41 4.14001 20.19 5.78001 19.25L8.13001 17.91C8.64001 17.62 9.49001 17.59 10.02 17.86L15.27 20.49C15.8 20.75 16.65 20.73 17.16 20.44L21.49 17.96C22.04 17.64 22.5 16.86 22.5 16.22V6.49001C22.5 4.59001 21.15 3.81001 19.51 4.75001L17.16 6.09001C16.65 6.38001 15.8 6.41001 15.27 6.14001L10.02 3.52001C9.49001 3.26001 8.64001 3.28001 8.13001 3.57001L3.80001 6.05001C3.24001 6.37001 2.79001 7.15001 2.79001 7.78001V7.78001Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                          </svg>
                          </div>
          <div class="footer-label">지도</div>
        </nuxt-link>
        <nuxt-link class="footer-link-box" to="/my/favorite">
          <div class="footer-link-img">
          <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                              <g clip-path="url(#clip0_3393_16279)">
                                  <path d="M3.67001 7.44L12.5 12.55L21.27 7.47M12.5 21.61V12.54"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                  <path d="M22.11 12.83V9.17C22.11 7.79 21.12 6.11 19.91 5.44L14.57 2.48C13.43 1.84 11.57 1.84 10.43 2.48L5.09001 5.44C3.88001 6.11 2.89001 7.79 2.89001 9.17V14.83C2.89001 16.21 3.88001 17.89 5.09001 18.56L10.43 21.52C11 21.84 11.75 22 12.5 22C13.25 22 14 21.84 14.57 21.52" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                  <path d="M23.5 22L22.5 21M19.7 21.4C20.5487 21.4 21.3626 21.0629 21.9627 20.4627C22.5629 19.8626 22.9 19.0487 22.9 18.2C22.9 17.3513 22.5629 16.5374 21.9627 15.9373C21.3626 15.3371 20.5487 15 19.7 15C18.8513 15 18.0374 15.3371 17.4373 15.9373C16.8371 16.5374 16.5 17.3513 16.5 18.2C16.5 19.0487 16.8371 19.8626 17.4373 20.4627C18.0374 21.0629 18.8513 21.4 19.7 21.4V21.4Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                              </g>
                              <defs>
                                  <clipPath id="clip0_3393_16279">
                                      <rect width="24" height="24" fill="white" transform="translate(0.5)"/>
                                  </clipPath>
                              </defs>
                          </svg>
                          </div>
          <div class="footer-label">찜한 상품</div>
        </nuxt-link>
        <nuxt-link class="footer-link-box" to="/main/my">
          <div class="footer-link-img">
          <svg id="_레이어_2" data-name="레이어 2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1048.16 672.19" class=fill>
                               <g id="_레이어_1-2" data-name="레이어 1">
                                  <path  d="M205.96,185.84c-1.2-2.11-53.62-40.6-45.19-57.45s29.7-36,22.13-51.32-45.87-14.55-68.09,12.26-67.4,43.66-73.53,74.3S-26.13,221.07,12.94,229.5s91.15-21.45,110.3-13.79,69.7,59.74,115.66,73.53,52.85,45.19,49.02,65.11-2.3,75.06,53.62,65.87,9.96-20.68-9.19-49.02-29.87-54.38-5.36-68.94,103.4-58.98,134.81-15.32,19.91,62.81,94.98,97.28,113.36,45.96,113.36,98.81-9.19,133.28,3.06,160.85,49.02,46.72,43.66,0-33.7-81.19-8.43-138.64,52.09-79.66,5.36-113.36-102.64-92.68-96.51-111.83,50.55-49.02,55.91-58.98,89.62,169.28,160.09,230.55,105.7,81.19,147.06,86.55,76.6,2.3,65.87-6.89-101.11-9.96-166.98-127.15S731.4,96.98,660.94,45.67,493.96-8.72,431.15,11.96,222.04,214.18,205.96,185.84Z"/>
                              </g>
                          </svg>
                          </div>
          <div class="footer-label">내 캥거룸</div>
        </nuxt-link>
      </div>
    </div>
  </div>


</template>


