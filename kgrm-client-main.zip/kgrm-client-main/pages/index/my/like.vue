<template>
  <div id="app">
    <!--header s-->
    <header class="sticky-header d-flex bg-white flex-wrap justify-content-end align-items-center py-2 border-bottom">
      <div class="header_title Subtitle1">찜해둔 방</div>
      <b-button type="button" class="btn btn-sm position-absolute start-16 btn-link" onclick="location.href='/main/my'">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M20 12.75C20.4142 12.75 20.75 12.4142 20.75 12C20.75 11.5858 20.4142 11.25 20 11.25V12.75ZM4 11.25C3.58579 11.25 3.25 11.5858 3.25 12C3.25 12.4142 3.58579 12.75 4 12.75V11.25ZM20 11.25L4 11.25V12.75L20 12.75V11.25Z" fill="#232C34"/>
          <path d="M10.5303 6.53033C10.8232 6.23744 10.8232 5.76256 10.5303 5.46967C10.2374 5.17678 9.76256 5.17678 9.46967 5.46967L10.5303 6.53033ZM4 12L3.46967 11.4697C3.17678 11.7626 3.17678 12.2374 3.46967 12.5303L4 12ZM9.46967 18.5303C9.76256 18.8232 10.2374 18.8232 10.5303 18.5303C10.8232 18.2374 10.8232 17.7626 10.5303 17.4697L9.46967 18.5303ZM9.46967 5.46967L3.46967 11.4697L4.53033 12.5303L10.5303 6.53033L9.46967 5.46967ZM3.46967 12.5303L9.46967 18.5303L10.5303 17.4697L4.53033 11.4697L3.46967 12.5303Z" fill="#232C34"/>
        </svg>

      </b-button>
    </header>
    <!--header e-->

    <!--content s-->
    <div class="container pb-6">

      <div class="subtitle_wrap Subtitle1 pt-4">
        <h6>전체 <span>3</span>건</h6>
      </div>

      <!-- 찜해둔 방이 없는 경우 -->
      <div class="center-wrap" v-if="!isLogin || !existLike">
        <div class="subtitle_wrap Subtitle1 text-center">
          <img src="../../../assets/img/2x/illust_02.png" class="w-13rem" data-aos="fade-up" data-aos-delay="200" data-aos-duration="1000">
          <h3 class="pt-5">찜해둔 방이 없습니다.</h3>
          <div class="body1 pt-2">캥거룸에 올라온 방을 찜 해보세요!</div>
          <b-button type="button" class="btn btn-lg btn-primary mt-4 w-50" @click="goRoomList"">매물 보러가기</b-button>
        </div>
      </div>

      <!-- 찜해둔 방이 있는 경우 -->
      <div v-if="isLogin && existLike">
        <div class="sort-wrap px-3">
          <b-button type="button" @click="$router.go(0)" class="btn btn-sm position-absolute start-16 btn-link border" id="remove">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M16.899 17C15.6364 18.2372 13.9073 19 12 19C8.13401 19 5 15.866 5 12C5 8.13401 8.13401 5 12 5C13.9073 5 15.6364 5.76281 16.899 7" stroke="#A9B2B9" stroke-width="1.5" stroke-linecap="round"/>
              <path d="M14.9998 8.00001L18.4639 6L17.7318 8.73206L14.9998 8.00001Z" fill="#A9B2B9" stroke="#A9B2B9" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </b-button>
          <ul id="sort">
            <li class="sort-date">등록일<span class="material-icons">arrow_upward</span></li>
            <li class="sort-size">면적<span class="material-icons">arrow_upward</span></li>
            <li class="sort-amount">금액<span class="material-icons">arrow_upward</span></li>

          </ul>
        </div>

        <!-- list s-->


        <div class="d-flex align-items-start gap-3 py-3 pb-5" style=" flex-direction:column!important">
          <div class="list-lg favorite_on" v-for="l in likes" :key="l._id">
            <div class="relative col-12">
              <ul @click="$router.push(`/room/${l.room._id}`)">
                <li><img :src="l.room.roomThumbnailImg"></li>
                <li>
                  <p class="body2 light_txt_lgrey">{{ l.room.roomSiDo }} {{ l.room.roomSiGunGu }} {{ l.room.roomEupMyeonDong }}</p>
                  <p class="Subtitle2 light_txt_grey">{{ l.room.roomHouseType }} {{ l.room.roomType }}</p>
                  <div class="price"><span class="label-outline-circle-main">{{ l.room.roomContractType }}</span><h4 class="">{{ l.room.roomDeposit }} / {{ l.room.roomMonthlyPrice }}</h4></div>
                </li>
              </ul>
              <div class="w-100 mt-2" style="overflow:hidden">
                <p class="body1">{{l.room.roomArea}}/{{ Math.round(l.room.roomArea * 3.3) }}㎡<span class="line-grey"></span>{{ l.room.roomFloor }} / {{ l.room.roomTotalFloor }}층</p>
                <p class="body1">{{ l.room.roomMemo }}</p>
              </div>
              <div class="tag-list mt-2">
                <span class="label-outline-round-grey" v-if="l.room.roomIsFullOption">풀옵션</span>
                <span class="label-outline-round-grey" v-if="l.room.roomCanParking">주차</span>
                <span class="label-outline-round-grey" v-if="l.room.roomExistEv">엘리베이터</span>
                <span class="label-outline-round-grey" v-if="l.room.roomCanPet">반려동물</span>
                <span class="label-outline-round-grey" v-if="l.room.roomCanLoan">전세대출</span>
              </div>
              <div class="write-date mt-3 mb-3"><span class="label-outline-circle-green">New</span><p>최초 등록일 {{ l.room.createdAt | dateFilter }}</p></div>
              <div class="list-btn">
                <b-button type="button" class="btn btn-sm w-100 btn-outline-primary">
                  문의하기
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <g clip-path="url(#clip0_151_4749)">
                      <path d="M7.92289 17.6365L17.4408 17.6669C18.9793 17.6669 20.2306 16.4309 20.2306 14.9113V7.51555C20.2306 5.99588 18.9793 4.75989 17.4408 4.75989H6.55879C5.02033 4.75989 3.76904 5.99588 3.76904 7.51555V14.9214L3.82033 19.9667C3.82033 20.2098 4.09725 20.3314 4.29212 20.1794L7.70751 17.7176C7.76904 17.6669 7.85109 17.6365 7.93315 17.6365H7.92289Z"   stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"/>
                      <path d="M7.19487 9.01489H16.7641"  stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"/>
                      <path d="M7.19487 12.4088H16.7641"  stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"/>
                    </g>
                    <defs>
                      <clipPath id="clip0_151_4749">
                        <rect width="18" height="17" fill="white" transform="translate(3 4)"/>
                      </clipPath>
                    </defs>
                  </svg>
                </b-button>
                <b-button type="button" class="d-none btn btn-sm w-50 btn-primary">
                  채팅하기
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <g clip-path="url(#clip0_151_4749)">
                      <path d="M7.92289 17.6365L17.4408 17.6669C18.9793 17.6669 20.2306 16.4309 20.2306 14.9113V7.51555C20.2306 5.99588 18.9793 4.75989 17.4408 4.75989H6.55879C5.02033 4.75989 3.76904 5.99588 3.76904 7.51555V14.9214L3.82033 19.9667C3.82033 20.2098 4.09725 20.3314 4.29212 20.1794L7.70751 17.7176C7.76904 17.6669 7.85109 17.6365 7.93315 17.6365H7.92289Z" stroke="#fff" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"/>
                      <path d="M7.19487 9.01489H16.7641" stroke="#fff" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"/>
                      <path d="M7.19487 12.4088H16.7641" stroke="#fff" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"/>
                    </g>
                    <defs>
                      <clipPath id="clip0_151_4749">
                        <rect width="18" height="17" fill="white" transform="translate(3 4)"/>
                      </clipPath>
                    </defs>
                  </svg>
                </b-button>
              </div>
            </div>
            <div class="list-btn position-absolute top-0 end-0">
              <b-button type="button" id="btn-favorite2" class="btn btn-md btn-link">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#ff9324">
                  <path id="favorive-star2" d="M9.5054 7.93631L12 2.90354L14.4946 7.93631C14.6957 8.34211 15.0837 8.62187 15.5306 8.68653L21.102 9.4926L17.0727 13.4032C16.7479 13.7185 16.5989 14.1737 16.6759 14.6205L17.6278 20.1465L12.6392 17.5352C12.2389 17.3257 11.7611 17.3257 11.3608 17.5352L6.37222 20.1465L7.32411 14.6205C7.40109 14.1737 7.25208 13.7185 6.92727 13.4032L2.89797 9.4926L8.46937 8.68653C8.91633 8.62187 9.30425 8.34211 9.5054 7.93631ZM21.2879 9.31222L21.2877 9.31244L21.2879 9.31222Z" stroke="#ff9324" stroke-width="1.5"/>
                </svg>
              </b-button>
            </div>
          </div>

        </div>
      </div>

      <!-- list e-->

    </div>


    <!--content e-->
  </div>
</template>
<script>
import moment from "moment/moment";

export default {
  async asyncData({ app }) {
    const uid = app.$cookies.get('uid');
    let isLogin = false;
    let existLike = false;

    if (uid) {
      isLogin = true;

      const { data: likes } = await app.$axios.get('/user/my/likes', {
        params: {
          uid: uid,
        }
      });

      if (likes.length !== 0) {
        existLike = true;
      }

      return { uid, isLogin, existLike, likes };
    } else {
      return { uid, isLogin, existLike };
    }
  },
  filters: {
    dateFilter(val) {
      return moment(val).format('YYYY.MM.DD');
    }
  },
  methods: {
    goRoomList() {
      console.log(this.uid)
      // if (this.uid) {
      //   this.$router.push('/main/home');
      // } else {
      //   this.$router.push('/login');
      // }
    },
    showModal() {
      this.$refs['my-modal'].show()
    },
    hideModal() {
      this.$refs['my-modal'].hide()
    },
    toggleModal() {
      // We pass the ID of the button that we want to return focus to
      // when the modal has hidden
      this.$refs['my-modal'].toggle('#toggle-btn')
    }
  }
}
</script>
