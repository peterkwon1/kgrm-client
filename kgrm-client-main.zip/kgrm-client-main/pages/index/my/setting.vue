<template>
    <div id="app">
<!--header s-->
<header class="sticky-header d-flex bg-white flex-wrap justify-content-end align-items-center py-2 border-bottom">
    <div class="header_title Subtitle1">설정</div>
           <b-button type="button" class="btn btn-sm position-absolute start-16 btn-link" onclick="location.href='/main/my'">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M20 12.75C20.4142 12.75 20.75 12.4142 20.75 12C20.75 11.5858 20.4142 11.25 20 11.25V12.75ZM4 11.25C3.58579 11.25 3.25 11.5858 3.25 12C3.25 12.4142 3.58579 12.75 4 12.75V11.25ZM20 11.25L4 11.25V12.75L20 12.75V11.25Z" fill="#232C34"/>
<path d="M10.5303 6.53033C10.8232 6.23744 10.8232 5.76256 10.5303 5.46967C10.2374 5.17678 9.76256 5.17678 9.46967 5.46967L10.5303 6.53033ZM4 12L3.46967 11.4697C3.17678 11.7626 3.17678 12.2374 3.46967 12.5303L4 12ZM9.46967 18.5303C9.76256 18.8232 10.2374 18.8232 10.5303 18.5303C10.8232 18.2374 10.8232 17.7626 10.5303 17.4697L9.46967 18.5303ZM9.46967 5.46967L3.46967 11.4697L4.53033 12.5303L10.5303 6.53033L9.46967 5.46967ZM3.46967 12.5303L9.46967 18.5303L10.5303 17.4697L4.53033 11.4697L3.46967 12.5303Z" fill="#232C34"/>
</svg>

           </b-button>
       </header>
<!--header e-->

<!--content s-->
<div class="container  pb-8">


<section>

    <!--개인설정-->
  <div class="subtitle_wrap-button Subtitle1 pt-4">
    <h6>개인 설정</h6>
  </div>

  <div class="txt-icon-button-g0 px-0">
  <b-button type="button" class="btn-full btn w-100 btn-dark  " onclick="location.href='info_edit'">회원정보 수정
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M8.96967 17.4697C8.67678 17.7626 8.67678 18.2374 8.96967 18.5303C9.26256 18.8232 9.73744 18.8232 10.0303 18.5303L8.96967 17.4697ZM15.5 12L16.0303 12.5303C16.171 12.3897 16.25 12.1989 16.25 12C16.25 11.8011 16.171 11.6103 16.0303 11.4697L15.5 12ZM10.0303 5.46967C9.73744 5.17678 9.26256 5.17678 8.96967 5.46967C8.67678 5.76256 8.67678 6.23744 8.96967 6.53033L10.0303 5.46967ZM10.0303 18.5303L16.0303 12.5303L14.9697 11.4697L8.96967 17.4697L10.0303 18.5303ZM16.0303 11.4697L10.0303 5.46967L8.96967 6.53033L14.9697 12.5303L16.0303 11.4697Z" fill="var(--bs-gray-200)" >
      </path>
    </svg>
  </b-button>
    <b-button type="button" class="d-none btn-full btn w-100 btn-dark  " onclick="location.href=''">멤버십 구독
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M8.96967 17.4697C8.67678 17.7626 8.67678 18.2374 8.96967 18.5303C9.26256 18.8232 9.73744 18.8232 10.0303 18.5303L8.96967 17.4697ZM15.5 12L16.0303 12.5303C16.171 12.3897 16.25 12.1989 16.25 12C16.25 11.8011 16.171 11.6103 16.0303 11.4697L15.5 12ZM10.0303 5.46967C9.73744 5.17678 9.26256 5.17678 8.96967 5.46967C8.67678 5.76256 8.67678 6.23744 8.96967 6.53033L10.0303 5.46967ZM10.0303 18.5303L16.0303 12.5303L14.9697 11.4697L8.96967 17.4697L10.0303 18.5303ZM16.0303 11.4697L10.0303 5.46967L8.96967 6.53033L14.9697 12.5303L16.0303 11.4697Z" fill="var(--bs-gray-200)" >
        </path></svg>
    </b-button>
  </div>

  <div class="hr-0"></div>

<!--알림-->
  <div class="subtitle_wrap-button Subtitle1 pt-4">
    <h6>알림설정</h6>
  </div>

  <div class="txt-icon-button-g0 px-0">
    <div class="setting-list-title">야간알림 받기 (20 ~ 24시)
      <div class="form-check form-switch">
        <input class="form-check-input float-right" type="checkbox" role="switch" id="flexSwitchCheckChecked1">
      </div>
    </div>

    <div class="setting-list-title">앱푸쉬 알림 받기
      <div class="form-check form-switch">
        <input class="form-check-input float-right" type="checkbox" role="switch" id="flexSwitchCheckChecked2" checked>
      </div>
    </div>
  </div>

  <div class="hr-0"></div>

</section>

<div class="py-4 px-3">
<b-button type="button" class="btn btn-lg btn-outline-light w-100" @click="showModal">로그아웃</b-button>
</div>
</div>

<!--modal s-->
<b-modal id="modal-center" centered ref="my-modal" hide-footer title="로그아웃">
      <div class="d-block">
        <div class="modal-body body2 px-3">
로그아웃 하시겠습니까?
      </div>
      </div>
      <div class="btn-group4 py-3">
      <b-button class="mt-3" variant="md btn-outline-success" block @click="logout">로그아웃</b-button>
      <b-button class="mt-3" variant="md btn-outline-light" block @click="hideModal">취소</b-button>
    </div>
    </b-modal>
<!--modal e-->

<!--content e-->
    </div>
</template>
<script>
  export default {
    methods: {
      showModal() {
        this.$refs['my-modal'].show()
      },
      hideModal() {
        this.$refs['my-modal'].hide()
      },
      logout() {
        this.$cookies.remove('token');
        this.$cookies.remove('uid');
        this.$router.replace('/main/home');
        // window.location.href = '/login/member';
      }
    }
  }
</script>
