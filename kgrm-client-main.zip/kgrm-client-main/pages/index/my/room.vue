<template>
    <div id="app">
<!--header s-->
<header class="sticky-header d-flex bg-white flex-wrap justify-content-end align-items-center py-2 border-bottom">
    <div class="header_title Subtitle1">내 매물</div>
           <b-button type="button" class="btn btn-sm position-absolute start-16 btn-link" onclick="location.href='/main/my'">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M20 12.75C20.4142 12.75 20.75 12.4142 20.75 12C20.75 11.5858 20.4142 11.25 20 11.25V12.75ZM4 11.25C3.58579 11.25 3.25 11.5858 3.25 12C3.25 12.4142 3.58579 12.75 4 12.75V11.25ZM20 11.25L4 11.25V12.75L20 12.75V11.25Z" fill="#232C34"/>
<path d="M10.5303 6.53033C10.8232 6.23744 10.8232 5.76256 10.5303 5.46967C10.2374 5.17678 9.76256 5.17678 9.46967 5.46967L10.5303 6.53033ZM4 12L3.46967 11.4697C3.17678 11.7626 3.17678 12.2374 3.46967 12.5303L4 12ZM9.46967 18.5303C9.76256 18.8232 10.2374 18.8232 10.5303 18.5303C10.8232 18.2374 10.8232 17.7626 10.5303 17.4697L9.46967 18.5303ZM9.46967 5.46967L3.46967 11.4697L4.53033 12.5303L10.5303 6.53033L9.46967 5.46967ZM3.46967 12.5303L9.46967 18.5303L10.5303 17.4697L4.53033 11.4697L3.46967 12.5303Z" fill="#232C34"/>
</svg>

           </b-button>
       </header>
<!--header e-->

<!--content s-->
<div class="container pb-6">

 
<div class="radio-nav d-flex gap-2 py-3">
  <b-form-group label="" v-slot="{ ariaDescribedby }">
      <b-form-radio-group
        id="btn-radios-1"
        class="gap-2"
        v-model="selected"
        :options="options"
        :aria-describedby="ariaDescribedby"
        name="radios-btn-default"
        buttons
      ></b-form-radio-group>
    </b-form-group>
</div>

<div class="subtitle_wrap Subtitle1 pt-2">
  <h6>전체 <span>4</span>건</h6>
</div>

<div class="d-flex align-items-start gap-3 py-3" style=" flex-direction:column!important">


  <div class="list-thumnail">
    <label class="  btn-sm label-circle-yellow mb-3">등록 승인 대기중</label>
    <div class="relative col-12">
      <ul>
        <li><img src="https://cdn.pixabay.com/photo/2016/11/30/08/48/bedroom-1872196__340.jpg"></li>
        <li>
          <p class="body2 light_txt_lgrey">서울특별시 구로구 구로동</p>
          <p class="Subtitle2 light_txt_grey">빌라형 오픈형 원룸</p>
          <div class="price"><span class="label-outline-circle-main">월세</span><h4 class="">1000 / 68</h4></div>
          <p class="body1">85/58㎡<span class="line-grey"></span>7 / 11층</p>
        </li>
      </ul>
      <div class="list-btn mt-3">
          <b-button type="button" class="btn btn-outline-light btn-md w-100 ">
            등록정보 수정
        </b-button>

      </div>
    </div>
  </div>

  <div class="list-thumnail">
    <label class="  btn-sm label-circle-main-light mb-3">등록 완료</label>
    <div class="relative col-12">
      <ul>
        <li><img src="https://cdn.pixabay.com/photo/2016/11/30/08/48/bedroom-1872196__340.jpg"></li>
        <li>
          <p class="body2 light_txt_lgrey">서울특별시 구로구 구로동</p>
          <p class="Subtitle2 light_txt_grey">빌라형 오픈형 원룸</p>
          <div class="price"><span class="label-outline-circle-main">월세</span><h4 class="">1000 / 68</h4></div>
          <p class="body1">85/58㎡<span class="line-grey"></span>7 / 11층</p>
        </li>
      </ul>
      <div class="list-btn mt-3">
        <b-button type="button" class="btn btn-outline-light btn-md w-20 " v-b-modal.delete-modal>
          삭제
        </b-button>
        <b-button type="button" class="btn btn-outline-light btn-md w-20 ">
          수정
        </b-button>
        <button type="button" class="btn btn-primary btn-md w-60 " v-b-modal.success-modal>
          계약완료 처리
        </button>
      </div>
    </div>
    <div class="list-btn position-absolute top-0 end-0">
      <b-button type="button" id="btn-favorite2" class="btn btn-md btn-link">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path fill-rule="evenodd" clip-rule="evenodd" d="M21.8701 11.5C21.2301 10.39 17.7101 4.81999 11.7301 4.99999C6.20007 5.13999 3.00007 9.99999 2.13007 11.5C1.95144 11.8094 1.95144 12.1906 2.13007 12.5C2.76007 13.59 6.13007 19 12.0201 19H12.2701C17.8001 18.86 21.0101 14 21.8701 12.5C22.0487 12.1906 22.0487 11.8094 21.8701 11.5ZM12.0001 15.5C10.0671 15.5 8.50007 13.933 8.50007 12C8.50007 10.067 10.0671 8.49999 12.0001 8.49999C13.9331 8.49999 15.5001 10.067 15.5001 12C15.5001 13.933 13.9331 15.5 12.0001 15.5ZM12.0001 13.5C12.8285 13.5 13.5001 12.8284 13.5001 12C13.5001 11.1716 12.8285 10.5 12.0001 10.5C11.1716 10.5 10.5001 11.1716 10.5001 12C10.5001 12.8284 11.1716 13.5 12.0001 13.5Z" fill="#ffc107"/>
        </svg>

      </b-button>
    </div>

  </div>

  <div class="list-thumnail">
    <label class="  btn-sm label-circle-main mb-3">계약 완료</label>
    <div class="relative col-12">
      <ul>
        <li><img src="https://cdn.pixabay.com/photo/2016/11/30/08/48/bedroom-1872196__340.jpg"></li>
        <li>
          <p class="body2 light_txt_lgrey">서울특별시 구로구 구로동</p>
          <p class="Subtitle2 light_txt_grey">빌라형 오픈형 원룸</p>
          <div class="price"><span class="label-outline-circle-main">월세</span><h4 class="">1000 / 68</h4></div>
          <p class="body1">85/58㎡<span class="line-grey"></span>7 / 11층</p>
        </li>
      </ul>
      <div class="list-btn mt-3">
        <b-button type="button" class="btn btn-outline-light btn-md w-20 " v-b-modal.delete-modal>
          삭제
        </b-button>
        <b-button type="button" class="btn btn-outline-light btn-md w-20 ">
          수정
        </b-button>
        <b-button type="button" class="btn btn-primary btn-md w-60 " disabled>
          계약완료 처리
        </b-button>
      </div>
    </div>
    <div class="list-btn position-absolute top-0 end-0">
      <b-button type="button" id="btn-favorite2" class="btn btn-md btn-link">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path fill-rule="evenodd" clip-rule="evenodd" d="M21.8701 11.5C21.2301 10.39 17.7101 4.81999 11.7301 4.99999C6.20007 5.13999 3.00007 9.99999 2.13007 11.5C1.95144 11.8094 1.95144 12.1906 2.13007 12.5C2.76007 13.59 6.13007 19 12.0201 19H12.2701C17.8001 18.86 21.0101 14 21.8701 12.5C22.0487 12.1906 22.0487 11.8094 21.8701 11.5ZM12.0001 15.5C10.0671 15.5 8.50007 13.933 8.50007 12C8.50007 10.067 10.0671 8.49999 12.0001 8.49999C13.9331 8.49999 15.5001 10.067 15.5001 12C15.5001 13.933 13.9331 15.5 12.0001 15.5ZM12.0001 13.5C12.8285 13.5 13.5001 12.8284 13.5001 12C13.5001 11.1716 12.8285 10.5 12.0001 10.5C11.1716 10.5 10.5001 11.1716 10.5001 12C10.5001 12.8284 11.1716 13.5 12.0001 13.5Z" fill="#ffc107"/>
        </svg>

      </b-button>
    </div>

  </div>

  <div class="list-thumnail opacity-25">
    <label class="  btn-sm label-circle-main-light mb-3">등록 완료</label>
    <div class="relative col-12">
      <ul>
        <li><img src="https://cdn.pixabay.com/photo/2016/11/30/08/48/bedroom-1872196__340.jpg"></li>
        <li>
          <p class="body2 light_txt_lgrey">서울특별시 구로구 구로동</p>
          <p class="Subtitle2 light_txt_grey">빌라형 오픈형 원룸</p>
          <div class="price"><span class="label-outline-circle-main">월세</span><h4 class="">1000 / 68</h4></div>
          <p class="body1">85/58㎡<span class="line-grey"></span>7 / 11층</p>
        </li>
      </ul>
      <div class="list-btn mt-3">
        <b-button type="button" class="btn btn-outline-light btn-md w-20 " data-bs-toggle="modal" data-bs-target="#delete">
          삭제
        </b-button>
        <b-button type="button" class="btn btn-outline-light btn-md w-20 ">
          수정
        </b-button>
        <button type="button" class="btn btn-primary btn-md w-60 ">
          계약완료 처리
        </button>
      </div>
    </div>
    <div class="list-btn position-absolute top-0 end-0">
      <b-button type="button" id="btn-favorite2" class="btn btn-md btn-link">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path fill-rule="evenodd" clip-rule="evenodd" d="M21.8701 11.5C21.2301 10.39 17.7101 4.81999 11.7301 4.99999C6.20007 5.13999 3.00007 9.99999 2.13007 11.5C1.95144 11.8094 1.95144 12.1906 2.13007 12.5C2.76007 13.59 6.13007 19 12.0201 19H12.2701C17.8001 18.86 21.0101 14 21.8701 12.5C22.0487 12.1906 22.0487 11.8094 21.8701 11.5ZM12.0001 15.5C10.0671 15.5 8.50007 13.933 8.50007 12C8.50007 10.067 10.0671 8.49999 12.0001 8.49999C13.9331 8.49999 15.5001 10.067 15.5001 12C15.5001 13.933 13.9331 15.5 12.0001 15.5ZM12.0001 13.5C12.8285 13.5 13.5001 12.8284 13.5001 12C13.5001 11.1716 12.8285 10.5 12.0001 10.5C11.1716 10.5 10.5001 11.1716 10.5001 12C10.5001 12.8284 11.1716 13.5 12.0001 13.5Z" fill="#1A2128"/>
          <rect x="1.29289" y="20.6776" width="26" height="2.51865" transform="rotate(-45 1.29289 20.6776)" fill="#1A2128" stroke="white"/>
        </svg>

      </b-button>
    </div>

  </div>



</div>


</div>

<!--modal s-->
<b-modal id="success-modal" centered ref="success-modal" hide-footer title="계약완료 처리를 하시겠습니까?">
      <div class="d-block">
        <div class="modal-body body2 px-3">
            네 캥거룸을 통해 계약완료를 잘 하였습니다.
      </div>
      </div>
      <div class="btn-group4 py-3">
      <b-button class="mt-3" variant="md btn-outline-success" block @click="toggleModal">계약완료</b-button>
      <b-button class="mt-3" variant="md btn-outline-light" block @click="hideModal">취소</b-button>
    </div>
    </b-modal>
<!--modal e-->

<!--delete modal s-->
<b-modal id="delete-modal" centered ref="delete-modal" hide-footer title="등록된 매물 삭제">
      <div class="d-block">
        <div class="modal-body body2 px-3">
          해당 내용을 삭제 하시겠습니까?
삭제 후에는 복구가 불가하오니 이 점 유의해주시기 바랍니다.
      </div>
      </div>
      <div class="btn-group4 py-3">
      <b-button class="mt-3" variant="md btn-outline-success" block @click="toggleModal">삭제</b-button>
      <b-button class="mt-3" variant="md btn-outline-light" block @click="hideModal">취소</b-button>
    </div>
    </b-modal>
<!--delete modal e-->



<!--content e-->



    </div>
</template>
<script>
  export default {
    async asyncData({ app }) {
      const uid = app.$cookies.get('uid');

      if (uid) {
        const { data: rooms } = await app.$axios.get('/user/room/my', {
          params: {
            uid: uid,
          }
        });

        return { rooms };
      }

    },
    data() {
      return {
        selected: '전체',
        options: [
          { text: '전체', value: '전체' },
          { text: '승인대기', value: '승인대기' },
          { text: '등록 완료', value: '등록 완료' },
          { text: '계약 완료', value: '계약 완료' }
        ]
      }
    }
  }
</script>