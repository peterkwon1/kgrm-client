<template>
    <div id="app">
<!--header s-->
<header class="sticky-header d-flex bg-white flex-wrap justify-content-end align-items-center py-2 border-bottom">
    <div class="header_title Subtitle1">최근 본 방</div>
           <b-button type="button" class="btn btn-sm position-absolute start-16 btn-link" onclick="location.href='/main/my'">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M20 12.75C20.4142 12.75 20.75 12.4142 20.75 12C20.75 11.5858 20.4142 11.25 20 11.25V12.75ZM4 11.25C3.58579 11.25 3.25 11.5858 3.25 12C3.25 12.4142 3.58579 12.75 4 12.75V11.25ZM20 11.25L4 11.25V12.75L20 12.75V11.25Z" fill="#232C34"/>
<path d="M10.5303 6.53033C10.8232 6.23744 10.8232 5.76256 10.5303 5.46967C10.2374 5.17678 9.76256 5.17678 9.46967 5.46967L10.5303 6.53033ZM4 12L3.46967 11.4697C3.17678 11.7626 3.17678 12.2374 3.46967 12.5303L4 12ZM9.46967 18.5303C9.76256 18.8232 10.2374 18.8232 10.5303 18.5303C10.8232 18.2374 10.8232 17.7626 10.5303 17.4697L9.46967 18.5303ZM9.46967 5.46967L3.46967 11.4697L4.53033 12.5303L10.5303 6.53033L9.46967 5.46967ZM3.46967 12.5303L9.46967 18.5303L10.5303 17.4697L4.53033 11.4697L3.46967 12.5303Z" fill="#232C34"/>
</svg>

           </b-button>
       </header>
<!--header e-->

<!--content s-->
<div class="container pb-6">

    <div class="subtitle_wrap Subtitle1 pt-4">
    <h6>전체 <span>20</span>건</h6>
  </div>

  <div class="sort-wrap px-3">
    <b-button type="button" onclick="myFunction()" class="btn btn-sm position-absolute start-16 btn-link border" id="remove">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M16.899 17C15.6364 18.2372 13.9073 19 12 19C8.13401 19 5 15.866 5 12C5 8.13401 8.13401 5 12 5C13.9073 5 15.6364 5.76281 16.899 7" stroke="#A9B2B9" stroke-width="1.5" stroke-linecap="round"/>
        <path d="M14.9998 8.00001L18.4639 6L17.7318 8.73206L14.9998 8.00001Z" fill="#A9B2B9" stroke="#A9B2B9" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </b-button>
    <ul id="sort">
        <li class="sort-date">등록일<span class="material-icons">arrow_upward</span></li>
      <li class="sort-size">면적<span class="material-icons">arrow_upward</span></li>
      <li class="sort-amount">금액<span class="material-icons">arrow_upward</span></li>

    </ul>
  </div>

  <div class="d-flex align-items-start flex-wrap gap-3 py-3">
    <div class="list-thumnail-cl">

      <div class="relative col-12">
        <ul>
          <li><img src="https://cdn.pixabay.com/photo/2016/11/30/08/48/bedroom-1872196__340.jpg"></li>
          <li>
            <p class="body2 light_txt_lgrey">서울특별시 구로구 구로동</p>
            <p class="Subtitle2 light_txt_grey">오피스텔형 분리형 원룸</p>
            <div class="align-items-sm-start price fd-c">
              <span class="label-outline-circle-main">월세</span>
              <h4 class="">1000 / 60</h4>
            </div>
            <p class="body1">85/58㎡<span class="line-grey"></span>7 / 11층</p>
          </li>
        </ul>

      </div>



    </div>
    <div class="list-thumnail-cl">

      <div class="relative col-12">
        <ul>
          <li><img src="https://cdn.pixabay.com/photo/2016/11/30/08/48/bedroom-1872196__340.jpg"></li>
          <li>
            <p class="body2 light_txt_lgrey">서울특별시 구로구 구로동</p>
            <p class="Subtitle2 light_txt_grey">오피스텔형 분리형 원룸</p>
            <div class="align-items-sm-start price fd-c">
              <span class="label-outline-circle-main">월세</span>
              <h4 class="">1000 / 60</h4>
            </div>
            <p class="body1">85/58㎡<span class="line-grey"></span>7 / 11층</p>
          </li>
        </ul>

      </div>



    </div>
    <div class="list-thumnail-cl">

      <div class="relative col-12">
        <ul>
          <li><img src="https://cdn.pixabay.com/photo/2016/11/30/08/48/bedroom-1872196__340.jpg"></li>
          <li>
            <p class="body2 light_txt_lgrey">서울특별시 구로구 구로동</p>
            <p class="Subtitle2 light_txt_grey">오피스텔형 분리형 원룸</p>
            <div class="align-items-sm-start price fd-c">
              <span class="label-outline-circle-main">월세</span>
              <h4 class="">1000 / 60</h4>
            </div>
            <p class="body1">85/58㎡<span class="line-grey"></span>7 / 11층</p>
          </li>
        </ul>

      </div>



    </div>
    <div class="list-thumnail-cl">

      <div class="relative col-12">
        <ul>
          <li><img src="https://cdn.pixabay.com/photo/2016/11/30/08/48/bedroom-1872196__340.jpg"></li>
          <li>
            <p class="body2 light_txt_lgrey">서울특별시 구로구 구로동</p>
            <p class="Subtitle2 light_txt_grey">오피스텔형 분리형 원룸</p>
            <div class="align-items-sm-start price fd-c">
              <span class="label-outline-circle-main">월세</span>
              <h4 class="">1000 / 60</h4>
            </div>
            <p class="body1">85/58㎡<span class="line-grey"></span>7 / 11층</p>
          </li>
        </ul>

      </div>



    </div>
    <div class="list-thumnail-cl">

      <div class="relative col-12">
        <ul>
          <li><img src="https://cdn.pixabay.com/photo/2016/11/30/08/48/bedroom-1872196__340.jpg"></li>
          <li>
            <p class="body2 light_txt_lgrey">서울특별시 구로구 구로동</p>
            <p class="Subtitle2 light_txt_grey">오피스텔형 분리형 원룸</p>
            <div class="align-items-sm-start price fd-c">
              <span class="label-outline-circle-main">월세</span>
              <h4 class="">1000 / 60</h4>
            </div>
            <p class="body1">85/58㎡<span class="line-grey"></span>7 / 11층</p>
          </li>
        </ul>

      </div>



    </div>
    <div class="list-thumnail-cl">

      <div class="relative col-12">
        <ul>
          <li><img src="https://cdn.pixabay.com/photo/2016/11/30/08/48/bedroom-1872196__340.jpg"></li>
          <li>
            <p class="body2 light_txt_lgrey">서울특별시 구로구 구로동</p>
            <p class="Subtitle2 light_txt_grey">오피스텔형 분리형 원룸</p>
            <div class="align-items-sm-start price fd-c">
              <span class="label-outline-circle-main">월세</span>
              <h4 class="">1000 / 60</h4>
            </div>
            <p class="body1">85/58㎡<span class="line-grey"></span>7 / 11층</p>
          </li>
        </ul>

      </div>



    </div>

  </div>

</div>
 

<!--content e-->
    </div>
</template>
<script>
  export default {
    methods: {
      showModal() {
        this.$refs['my-modal'].show()
      },
      hideModal() {
        this.$refs['my-modal'].hide()
      },
      toggleModal() {
        // We pass the ID of the button that we want to return focus to
        // when the modal has hidden
        this.$refs['my-modal'].toggle('#toggle-btn')
      }
    }
  }
</script>
