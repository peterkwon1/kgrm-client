<template>
    <div id="app">
<!--header s-->
<header class="sticky-header d-flex bg-white flex-wrap justify-content-end align-items-center py-2 border-bottom">
    <div class="header_title Subtitle1">문의내역</div>
           <b-button type="button" class="btn btn-sm position-absolute start-16 btn-link" onclick="location.href='/main/my'">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M20 12.75C20.4142 12.75 20.75 12.4142 20.75 12C20.75 11.5858 20.4142 11.25 20 11.25V12.75ZM4 11.25C3.58579 11.25 3.25 11.5858 3.25 12C3.25 12.4142 3.58579 12.75 4 12.75V11.25ZM20 11.25L4 11.25V12.75L20 12.75V11.25Z" fill="#232C34"/>
<path d="M10.5303 6.53033C10.8232 6.23744 10.8232 5.76256 10.5303 5.46967C10.2374 5.17678 9.76256 5.17678 9.46967 5.46967L10.5303 6.53033ZM4 12L3.46967 11.4697C3.17678 11.7626 3.17678 12.2374 3.46967 12.5303L4 12ZM9.46967 18.5303C9.76256 18.8232 10.2374 18.8232 10.5303 18.5303C10.8232 18.2374 10.8232 17.7626 10.5303 17.4697L9.46967 18.5303ZM9.46967 5.46967L3.46967 11.4697L4.53033 12.5303L10.5303 6.53033L9.46967 5.46967ZM3.46967 12.5303L9.46967 18.5303L10.5303 17.4697L4.53033 11.4697L3.46967 12.5303Z" fill="#232C34"/>
</svg>

           </b-button>
       </header>
<!--header e-->

<!--content s-->
<div class="container pb-6">


<div class="py-3">
<b-button type="button" class="btn btn-md w-100 btn-outline-primary" onclick="location.href='qna_write'">문의하기
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M16.1038 4.66848C16.3158 4.45654 16.5674 4.28843 16.8443 4.17373C17.1212 4.05903 17.418 4 17.7177 4C18.0174 4 18.3142 4.05903 18.5911 4.17373C18.868 4.28843 19.1196 4.45654 19.3315 4.66848C19.5435 4.88041 19.7116 5.13201 19.8263 5.40891C19.941 5.68582 20 5.9826 20 6.28232C20 6.58204 19.941 6.87882 19.8263 7.15573C19.7116 7.43263 19.5435 7.68423 19.3315 7.89617L8.43807 18.7896L4 20L5.21038 15.5619L16.1038 4.66848Z"   stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
  </svg>

</b-button>
</div>

<div class="subtitle_wrap Subtitle1 pt-2">
  <h6>전체 <span>5</span>건</h6>
</div>

<!--qna s-->
<div class="accordion" role="tablist">
    <b-card no-body class="mb-1">
      <b-card-header header-tag="header" class="" role="tab" block v-b-toggle.accordion-1>
        <span class="label-outline-round-grey">답변대기</span>
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
        </button>
        <div class="mt-2 body1 px-3">
          입점 및 제휴/광고 문의는 어떻게 하나요?
          <div class="write-date">작성일 2022.09.19</div>
        </div>
      </b-card-header>
      <b-collapse id="accordion-1" visible accordion="my-accordion" role="tabpanel">
        <b-card-body>
          <b-card-text>입점 신청을 하고 싶습니다. 메뉴가 어디에 있나요?입점 신청을 하고 싶습니다. 메뉴가 어디에 있나요?입점 신청을 하고 싶습니다. 메뉴가 어디에 있나요?</b-card-text>
        </b-card-body>
      </b-collapse>
    </b-card>

    <b-card no-body class="mb-1">
      <b-card-header header-tag="header" class="" role="tab" block v-b-toggle.accordion-2 variant="info">
        <span class="label-outline-round-main">답변완료</span>
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
        </button>
        <div class="mt-2 body1 px-3">
          입점 및 제휴/광고 문의는 어떻게 하나요?
          <div class="write-date">작성일 2022.09.19</div>
        </div>
      </b-card-header>
      <b-collapse id="accordion-2" accordion="my-accordion" role="tabpanel">
        <b-card-body>
          <b-card-text>입점 신청을 하고 싶습니다. 메뉴가 어디에 있나요?입점 신청을 하고 싶습니다. 메뉴가 어디에 있나요?입점 신청을 하고 싶습니다. 메뉴가 어디에 있나요?</b-card-text>
          <b-card-text class="answer">{{ text }}</b-card-text>
        </b-card-body>
      </b-collapse>
    </b-card>

    <b-card no-body class="mb-1">
      <b-card-header header-tag="header" class="" role="tab" block v-b-toggle.accordion-3 variant="info">
        <span class="label-outline-round-main">답변완료</span>
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
        </button>
        <div class="mt-2 body1 px-3">
          입점 및 제휴/광고 문의는 어떻게 하나요?
          <div class="write-date">작성일 2022.09.19</div>
        </div>
      </b-card-header>
      <b-collapse id="accordion-3" accordion="my-accordion" role="tabpanel">
        <b-card-body>
          <b-card-text>입점 신청을 하고 싶습니다. 메뉴가 어디에 있나요?입점 신청을 하고 싶습니다. 메뉴가 어디에 있나요?입점 신청을 하고 싶습니다. 메뉴가 어디에 있나요?</b-card-text>
          <b-card-text class="answer">{{ text }}</b-card-text>
        </b-card-body>
      </b-collapse>
    </b-card>
  </div>

  <!--Page navigation-->
  <div class="overflow-auto d-flex align-items-center">
    <b-pagination-nav :link-gen="linkGen" :number-of-pages="10" use-router class="mx-auto py-5"></b-pagination-nav>
  </div>

</div>
 

<!--content e-->
    </div>
</template>
<script>
  export default {
    data() {
      return {
        text: `
        입점 신청은 https://partners.ohou.se/partner/applications/new 에서, 제휴/광고 문의는 https://ohou.se/contacts/new?type=request 페이지에서 신청 가능합니다.
        `
      }
    },
    methods: {
      linkGen(pageNum) {
        return pageNum === 1 ? '?' : `?page=${pageNum}`
      }
    }
  }
</script>
