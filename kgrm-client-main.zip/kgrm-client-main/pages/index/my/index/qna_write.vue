<template>
    <div id="app">
<!--header s-->
<header class="sticky-header d-flex bg-white flex-wrap justify-content-end align-items-center py-2 border-bottom">
    <div class="header_title Subtitle1">문의하기</div>
           <b-button type="button" class="btn btn-sm position-absolute start-16 btn-link" onclick="location.href='/my/qna'">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M20 12.75C20.4142 12.75 20.75 12.4142 20.75 12C20.75 11.5858 20.4142 11.25 20 11.25V12.75ZM4 11.25C3.58579 11.25 3.25 11.5858 3.25 12C3.25 12.4142 3.58579 12.75 4 12.75V11.25ZM20 11.25L4 11.25V12.75L20 12.75V11.25Z" fill="#232C34"/>
<path d="M10.5303 6.53033C10.8232 6.23744 10.8232 5.76256 10.5303 5.46967C10.2374 5.17678 9.76256 5.17678 9.46967 5.46967L10.5303 6.53033ZM4 12L3.46967 11.4697C3.17678 11.7626 3.17678 12.2374 3.46967 12.5303L4 12ZM9.46967 18.5303C9.76256 18.8232 10.2374 18.8232 10.5303 18.5303C10.8232 18.2374 10.8232 17.7626 10.5303 17.4697L9.46967 18.5303ZM9.46967 5.46967L3.46967 11.4697L4.53033 12.5303L10.5303 6.53033L9.46967 5.46967ZM3.46967 12.5303L9.46967 18.5303L10.5303 17.4697L4.53033 11.4697L3.46967 12.5303Z" fill="#232C34"/>
</svg>

           </b-button>
       </header>
<!--header e-->

<!--content s-->
<div class="container pb-6">

<div class="write-wrap px-3 pt-4">
  <div class="body1 mb-2" style="color:var(--bs-gray-800)">서비스 이용 중 궁금한 사항을 남겨주세요.</div>
  
  <b-form-textarea
      id="textarea"
      v-model="text"
      placeholder="문의사항을 입력해주세요."
      rows="3"
      max-rows="6"
    ></b-form-textarea>

</div>


<div class="py-3">
  <b-button type="button" class="btn btn-lg w-100 btn-primary" onclick="location.href='qna'">작성완료
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M16.1038 4.66848C16.3158 4.45654 16.5674 4.28843 16.8443 4.17373C17.1212 4.05903 17.418 4 17.7177 4C18.0174 4 18.3142 4.05903 18.5911 4.17373C18.868 4.28843 19.1196 4.45654 19.3315 4.66848C19.5435 4.88041 19.7116 5.13201 19.8263 5.40891C19.941 5.68582 20 5.9826 20 6.28232C20 6.58204 19.941 6.87882 19.8263 7.15573C19.7116 7.43263 19.5435 7.68423 19.3315 7.89617L8.43807 18.7896L4 20L5.21038 15.5619L16.1038 4.66848Z" stroke="#fff" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
    </svg>

  </b-button>
</div>
</div>

<!--content e-->
    </div>
</template>
 <script>
  export default {
    data() {
      return {
        text: ''
      }
    }
  }
</script>