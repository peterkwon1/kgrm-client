<template>
    <div id="app">
<!--header s-->
<header class="sticky-header d-flex bg-white flex-wrap justify-content-end align-items-center py-2 border-bottom">
    <div class="header_title Subtitle1">회원정보 수정</div>
           <b-button type="button" class="btn btn-sm position-absolute start-16 btn-link" onclick="location.href='setting'">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M20 12.75C20.4142 12.75 20.75 12.4142 20.75 12C20.75 11.5858 20.4142 11.25 20 11.25V12.75ZM4 11.25C3.58579 11.25 3.25 11.5858 3.25 12C3.25 12.4142 3.58579 12.75 4 12.75V11.25ZM20 11.25L4 11.25V12.75L20 12.75V11.25Z" fill="#232C34"/>
<path d="M10.5303 6.53033C10.8232 6.23744 10.8232 5.76256 10.5303 5.46967C10.2374 5.17678 9.76256 5.17678 9.46967 5.46967L10.5303 6.53033ZM4 12L3.46967 11.4697C3.17678 11.7626 3.17678 12.2374 3.46967 12.5303L4 12ZM9.46967 18.5303C9.76256 18.8232 10.2374 18.8232 10.5303 18.5303C10.8232 18.2374 10.8232 17.7626 10.5303 17.4697L9.46967 18.5303ZM9.46967 5.46967L3.46967 11.4697L4.53033 12.5303L10.5303 6.53033L9.46967 5.46967ZM3.46967 12.5303L9.46967 18.5303L10.5303 17.4697L4.53033 11.4697L3.46967 12.5303Z" fill="#232C34"/>
</svg>

           </b-button>
       </header>
<!--header e-->

<!--content s-->
<div class="container position-absolute pb-6">

<!--로그인정보-->
  <section class="d-none">

    <div class="subtitle_wrap Subtitle1 pt-4">
      <h6>로그인 정보</h6>
      <p class="body2 light_txt_lgrey pt-1">연결된 SNS 계정으로 로그인할 수 있습니다.</p>
    </div>

    <div class="d-flex gap-3 py-3 pt-0">
      <button type="button" class="btn btn-icon-sns btn-link-purple">
        <img src="../../../../assets/img/icon/sns/naver-green-circle.png">
      </button>
      <button type="button" class="btn btn-icon-sns btn-link-purple">
        <img src="../../../../assets/img/icon/sns/Google.png" style="width:1.5rem;">
      </button>
      <button type="button" class="btn btn-icon-sns btn-link-purple">
        <img src="../../../../assets/img/icon/sns/kakao.png">
      </button>
    </div>

     <div class="hr-0"></div>

  </section>

<!--회원 정보-->
  <section>

    <div class="subtitle_wrap Subtitle1 pt-4">
      <h6>회원 정보</h6>
     </div>

    <div class="user_info">

      <ul>
        <li style=" position:relative">
          <button class="btn btn-icon-edit" type="button">
            <img src="../../../../assets/img/icon/edit.png">
          </button>
          <img src="https://img.freepik.com/free-photo/two-confident-business-man-shaking-hands-during-meeting-office-success-dealing-greeting-partner-concept_1423-185.jpg?w=1380&t=st=1669877942~exp=1669878542~hmac=9029fb200c1ed5735ddddba597d9bd36c948a35d0887cde6af7c70e30b381329" class="avatar-64">
        </li>
        <li>
          <div class="name-edit-wrap">
            <input type="text" class="form-control" placeholder="이동욱" aria-label="Recipient's username with two button addons">
            <button class="btn btn-md btn-outline-dark w-70" type="button">닉네임 변경</button>
            <!--button class="btn btn-primary" type="button">변경완료</button-->
          </div>
        </li>
      </ul>
    </div>

    <div class="list_basic">
      <ul>
        <li>
          <div class="title">성명</div>이동욱
        </li>
        <li>
          <div class="title">생년월일</div>1977-07-07
        </li>
        <li>
          <div class="title">연락처</div>010-1234-5678
        </li>
        <li>
          <div class="title">이메일</div>kangaroo@naver.com
        </li>
      </ul>

    </div>

    <div class="px-3 pt-2">
    <b-button class="btn btn-primary w-100 btn-md" type="button">본인인증으로 정보 수정</b-button>
    </div>

 
    <div class="hr-1"></div>

  </section>

  <hr>
  <section>
  <div class="subtitle_wrap Subtitle1 pt-4">
    <h6>마케팅 정보 수신 및 활용 동의</h6>
  </div>

    <div class="d-flex gap-4 py-3 pt-0">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" value="" id="message">
      <label class="form-check-label" for="message">
        문자메시지
      </label>
    </div>
    <div class="form-check">
      <input class="form-check-input" type="checkbox" value="" id="E-Mail">
      <label class="form-check-label" for="E-Mail">
        E-Mail
      </label>
    </div>

    </div>
    <div class="body2 light_txt_lgrey py-3 pt-0">
      서비스의 중요 안내사항 및 주문/매칭에 대한 정보는 위 수신 여부와 관계없이 발송됩니다.
    </div>

  </section>




  <div class="py-4 px-3">
  <b-button type="button" class="btn btn-lg btn-outline-light w-100" @click="showModal">회원 탈퇴하기</b-button>
  </div>
</div>

<!--modal s-->
<b-modal id="modal-center" centered ref="my-modal" hide-footer title="회원 탈퇴를 진행하시겠습니까?">
      <div class="d-block">
        <div class="modal-body body2 px-3">
          캥거루의 모든정보가 삭제됩니다.
      </div>
      </div>
      <div class="btn-group4 py-3">
      <b-button class="mt-3" variant="md btn-outline-success" block @click="toggleModal">탈퇴하기</b-button>
      <b-button class="mt-3" variant="md btn-outline-light" block @click="hideModal">취소</b-button>
    </div>
    </b-modal>
<!--modal e-->

<!--content e-->
    </div>
</template>
<script>
  export default {
    methods: {
      showModal() {
        this.$refs['my-modal'].show()
      },
      hideModal() {
        this.$refs['my-modal'].hide()
      },
      toggleModal() {
        // We pass the ID of the button that we want to return focus to
        // when the modal has hidden
        this.$refs['my-modal'].toggle('#toggle-btn')
      }
    }
  }
</script>
