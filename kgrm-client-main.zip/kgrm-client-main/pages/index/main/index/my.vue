<template>
<div id="app">
   <!--header s-->
  <header class="sticky-header d-flex bg-transparent flex-wrap align-items-center justify-content-between py-2 sticky-top">
    <div class="header_title Subtitle1">마이페이지</div>
    <ul class="nav nav-pills position-absolute end-1">
      <li class="nav-item">
        <b-button type="button" class="d-none btn btn-sm btn-link" @click="$bvModal.show('modal-scoped')">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M18.2395 8.97519L17.4943 9.05977L18.2395 8.97519ZM18.6867 12.9153L19.4319 12.8307V12.8307L18.6867 12.9153ZM5.31328 12.9153L4.56806 12.8307L4.56806 12.8307L5.31328 12.9153ZM5.76046 8.97519L6.50568 9.05977L5.76046 8.97519ZM4.44779 14.8721L3.87668 14.386H3.87668L4.44779 14.8721ZM19.5522 14.8721L18.9811 15.3583L19.5522 14.8721ZM14.2699 4.37366H13.5199C13.5199 4.69424 13.7237 4.97938 14.027 5.08322L14.2699 4.37366ZM9.73005 4.37366L9.973 5.08322C10.2763 4.97938 10.4801 4.69424 10.4801 4.37366H9.73005ZM15.7023 20.2632C15.8477 19.8753 15.6511 19.4431 15.2632 19.2977C14.8753 19.1523 14.4431 19.3489 14.2977 19.7368L15.7023 20.2632ZM9.7023 19.7368C9.55694 19.3489 9.12467 19.1523 8.7368 19.2977C8.34893 19.4431 8.15234 19.8753 8.2977 20.2632L9.7023 19.7368ZM17.7772 17.25H6.22281V18.75H17.7772V17.25ZM17.4943 9.05977L17.9415 12.9998L19.4319 12.8307L18.9848 8.89061L17.4943 9.05977ZM6.05849 12.9998L6.50568 9.05977L5.01525 8.89061L4.56806 12.8307L6.05849 12.9998ZM5.01889 15.3583C5.59621 14.6801 5.96028 13.8652 6.05849 12.9998L4.56806 12.8307C4.50519 13.3846 4.27067 13.9231 3.87668 14.386L5.01889 15.3583ZM17.9415 12.9998C18.0397 13.8652 18.4038 14.6801 18.9811 15.3583L20.1233 14.386C19.7293 13.9231 19.4948 13.3846 19.4319 12.8307L17.9415 12.9998ZM6.22281 17.25C5.56777 17.25 5.10443 16.926 4.89056 16.5492C4.68409 16.1854 4.68714 15.748 5.01889 15.3583L3.87668 14.386C3.11141 15.285 3.08777 16.4116 3.58598 17.2895C4.07679 18.1544 5.04947 18.75 6.22281 18.75V17.25ZM17.7772 18.75C18.9505 18.75 19.9232 18.1544 20.414 17.2895C20.9122 16.4116 20.8886 15.285 20.1233 14.386L18.9811 15.3583C19.3129 15.748 19.3159 16.1854 19.1094 16.5492C18.8956 16.926 18.4322 17.25 17.7772 17.25V18.75ZM15.0199 4.37366V4.26995H13.5199V4.37366H15.0199ZM18.9848 8.89061C18.7055 6.43026 16.8806 4.47476 14.5129 3.6641L14.027 5.08322C15.9441 5.73962 17.2913 7.27101 17.4943 9.05977L18.9848 8.89061ZM10.4801 4.37366V4.26995H8.98005V4.37366H10.4801ZM6.50568 9.05977C6.7087 7.27101 8.05587 5.73962 9.973 5.08322L9.48711 3.6641C7.11944 4.47476 5.29449 6.43026 5.01525 8.89061L6.50568 9.05977ZM12 2.75C12.8394 2.75 13.5199 3.4305 13.5199 4.26995H15.0199C15.0199 2.60208 13.6679 1.25 12 1.25V2.75ZM12 1.25C10.3321 1.25 8.98005 2.60208 8.98005 4.26995H10.4801C10.4801 3.4305 11.1606 2.75 12 2.75V1.25ZM14.2977 19.7368C13.975 20.5979 13.0846 21.25 12 21.25V22.75C13.6855 22.75 15.1516 21.7325 15.7023 20.2632L14.2977 19.7368ZM12 21.25C10.9154 21.25 10.025 20.5979 9.7023 19.7368L8.2977 20.2632C8.84835 21.7325 10.3145 22.75 12 22.75V21.25Z" fill="#232C34"/>
          </svg>
        </b-button>
      </li>
      <li class="nav-item" v-if="isLogin">
        <b-button type="button" class="btn btn-sm btn-link">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" onclick="location.href='/my/setting'">
            <path d="M20.7439 15.7206L20.1043 15.3289V15.3289L20.7439 15.7206ZM19.7894 17.2794L20.429 17.6711V17.6711L19.7894 17.2794ZM3.25608 8.27942L2.61647 7.88775H2.61647L3.25608 8.27942ZM4.21063 6.72057L4.85024 7.11223L4.21063 6.72057ZM6.81851 6.06172L7.17709 5.403L7.17709 5.403L6.81851 6.06172ZM3.95486 10.7383L3.59628 11.397H3.59628L3.95486 10.7383ZM17.1815 17.9383L16.8229 18.597L16.8229 18.597L17.1815 17.9383ZM20.0451 13.2617L19.6865 13.9204V13.9205L20.0451 13.2617ZM4.21063 17.2794L3.57102 17.6711L3.57102 17.6711L4.21063 17.2794ZM3.25608 15.7206L3.89569 15.3289L3.89569 15.3289L3.25608 15.7206ZM19.7894 6.72058L20.429 6.32892V6.32892L19.7894 6.72058ZM20.7439 8.27943L20.1043 8.67109V8.67109L20.7439 8.27943ZM20.0451 10.7383L20.4037 11.397L20.0451 10.7383ZM17.1815 6.06174L17.5401 6.72046V6.72046L17.1815 6.06174ZM3.95486 13.2617L4.31344 13.9205H4.31344L3.95486 13.2617ZM6.81851 17.9383L6.45993 17.2795L6.45992 17.2795L6.81851 17.9383ZM17.08 6.11698L16.7214 5.45825L17.08 6.11698ZM6.91999 6.11697L6.56141 6.77569L6.56141 6.77569L6.91999 6.11697ZM17.08 17.883L17.4386 17.2243L17.4386 17.2243L17.08 17.883ZM6.91999 17.883L7.27857 18.5418L7.27857 18.5418L6.91999 17.883ZM11.0454 3.75H12.9545V2.25H11.0454V3.75ZM12.9545 20.25H11.0454V21.75H12.9545V20.25ZM11.0454 20.25C10.3631 20.25 9.88634 19.7389 9.88634 19.2H8.38634C8.38634 20.6493 9.61905 21.75 11.0454 21.75V20.25ZM14.1136 19.2C14.1136 19.7389 13.6369 20.25 12.9545 20.25V21.75C14.3809 21.75 15.6136 20.6493 15.6136 19.2H14.1136ZM12.9545 3.75C13.6369 3.75 14.1136 4.26107 14.1136 4.8H15.6136C15.6136 3.35071 14.3809 2.25 12.9545 2.25V3.75ZM11.0454 2.25C9.61905 2.25 8.38634 3.35071 8.38634 4.8H9.88634C9.88634 4.26107 10.3631 3.75 11.0454 3.75V2.25ZM20.1043 15.3289L19.1497 16.8878L20.429 17.6711L21.3835 16.1122L20.1043 15.3289ZM3.89569 8.67108L4.85024 7.11223L3.57102 6.32891L2.61647 7.88775L3.89569 8.67108ZM4.85024 7.11223C5.15888 6.6082 5.88054 6.40506 6.45993 6.72045L7.17709 5.403C5.93026 4.72428 4.31675 5.11109 3.57102 6.32891L4.85024 7.11223ZM4.31344 10.0795C3.75745 9.77688 3.60429 9.14696 3.89569 8.67108L2.61647 7.88775C1.85351 9.13373 2.32605 10.7055 3.59628 11.397L4.31344 10.0795ZM19.1497 16.8878C18.8411 17.3918 18.1194 17.5949 17.5401 17.2795L16.8229 18.597C18.0697 19.2757 19.6832 18.8889 20.429 17.6711L19.1497 16.8878ZM21.3835 16.1122C22.1465 14.8663 21.6739 13.2945 20.4037 12.603L19.6865 13.9205C20.2425 14.2231 20.3957 14.853 20.1043 15.3289L21.3835 16.1122ZM4.85024 16.8878L3.89569 15.3289L2.61647 16.1122L3.57102 17.6711L4.85024 16.8878ZM19.1497 7.11225L20.1043 8.67109L21.3835 7.88777L20.429 6.32892L19.1497 7.11225ZM20.1043 8.67109C20.3957 9.14697 20.2425 9.77689 19.6865 10.0795L20.4037 11.397C21.6739 10.7055 22.1465 9.13374 21.3835 7.88777L20.1043 8.67109ZM17.5401 6.72046C18.1194 6.40507 18.8411 6.60822 19.1497 7.11225L20.429 6.32892C19.6832 5.1111 18.0697 4.72429 16.8229 5.40301L17.5401 6.72046ZM3.89569 15.3289C3.60429 14.853 3.75745 14.2231 4.31344 13.9205L3.59628 12.603C2.32605 13.2945 1.85351 14.8663 2.61647 16.1122L3.89569 15.3289ZM3.57102 17.6711C4.31675 18.8889 5.93026 19.2757 7.17709 18.597L6.45992 17.2795C5.88054 17.5949 5.15888 17.3918 4.85024 16.8878L3.57102 17.6711ZM17.4386 6.7757L17.5401 6.72046L16.8229 5.40301L16.7214 5.45825L17.4386 6.7757ZM6.45993 6.72045L6.56141 6.77569L7.27858 5.45824L7.17709 5.403L6.45993 6.72045ZM17.5401 17.2795L17.4386 17.2243L16.7214 18.5417L16.8229 18.597L17.5401 17.2795ZM6.56141 17.2243L6.45993 17.2795L7.17708 18.597L7.27857 18.5418L6.56141 17.2243ZM3.59628 11.397C4.07403 11.6571 4.07403 12.3429 3.59628 12.603L4.31344 13.9205C5.83497 13.0922 5.83498 10.9078 4.31344 10.0795L3.59628 11.397ZM7.27857 18.5418C7.77797 18.2699 8.38634 18.6314 8.38634 19.2H9.88634C9.88634 17.4934 8.06034 16.4084 6.56141 17.2243L7.27857 18.5418ZM15.6136 19.2C15.6136 18.6314 16.222 18.2699 16.7214 18.5417L17.4386 17.2243C15.9396 16.4083 14.1136 17.4934 14.1136 19.2H15.6136ZM20.4037 12.603C19.926 12.3429 19.926 11.6571 20.4037 11.397L19.6865 10.0795C18.165 10.9078 18.165 13.0922 19.6865 13.9204L20.4037 12.603ZM6.56141 6.77569C8.06034 7.59165 9.88634 6.50663 9.88634 4.8H8.38634C8.38634 5.3686 7.77797 5.7301 7.27857 5.45824L6.56141 6.77569ZM16.7214 5.45825C16.222 5.73011 15.6136 5.36861 15.6136 4.8H14.1136C14.1136 6.50663 15.9396 7.59166 17.4386 6.7757L16.7214 5.45825ZM14.25 12C14.25 13.2426 13.2426 14.25 12 14.25V15.75C14.0711 15.75 15.75 14.0711 15.75 12H14.25ZM12 14.25C10.7574 14.25 9.75 13.2426 9.75 12H8.25C8.25 14.0711 9.92893 15.75 12 15.75V14.25ZM9.75 12C9.75 10.7574 10.7574 9.75 12 9.75V8.25C9.92893 8.25 8.25 9.92893 8.25 12H9.75ZM12 9.75C13.2426 9.75 14.25 10.7574 14.25 12H15.75C15.75 9.92893 14.0711 8.25 12 8.25V9.75Z" fill="#232C34"/>
          </svg>
        </b-button>
      </li>
    </ul>
  </header>
 <!--header e-->

  <!--content s-->
  <div class="container position-absolute pb-6">

  <section>
    <div class="user_info" v-if="isLogin">
      <ul>
        <li>
          <img src="https://img.freepik.com/free-photo/two-confident-business-man-shaking-hands-during-meeting-office-success-dealing-greeting-partner-concept_1423-185.jpg?w=1380&t=st=1669877942~exp=1669878542~hmac=9029fb200c1ed5735ddddba597d9bd36c948a35d0887cde6af7c70e30b381329" class="avatar-64">
        </li>
        <li>
          <span class="label-outline-round-main">일반회원</span>
          <p class="Subtitle1 mt-2">반갑습니다! {{ me.memName }}님 :)</p>
         </li>
      </ul>
    </div>
    <div class="user_info" v-if="!isLogin">
      <ul>
        <li>
          <img src="https://img.freepik.com/free-photo/two-confident-business-man-shaking-hands-during-meeting-office-success-dealing-greeting-partner-concept_1423-185.jpg?w=1380&t=st=1669877942~exp=1669878542~hmac=9029fb200c1ed5735ddddba597d9bd36c948a35d0887cde6af7c70e30b381329" class="avatar-64">
        </li>
        <li>
          <b-button type="button" block variant="btn btn-lg btn-primary" onclick="location.href='/login'">로그인을 해주세요</b-button>
        </li>
      </ul>
    </div>
  </section>

  <section>
       <div class="d-none btn-group3 mypage-menu">
         <ul>
           <li onclick="location.href='myorder.html'">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                 <path fill-rule="evenodd" clip-rule="evenodd" d="M14.4405 4H8.45143C6.59791 4 5.00005 5.45502 5.00005 7.25091V16.5904C5.00005 18.4874 6.49349 20 8.45143 20H15.6432C17.4976 20 19 18.3872 19 16.5904V8.59957L14.4405 4Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                 <path d="M14.1411 4V6.51305C14.1411 7.73978 15.1337 8.73498 16.3596 8.73757C17.4973 8.74016 18.661 8.74102 18.7396 8.73584"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                 <path d="M13.6625 12.4319H9.00005"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                 <path d="M13.6625 16.4319H9.00005"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                 <path d="M11.8993 8.43194H9.00005"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
               </svg>
               <br>내 주문서
           </li>
           <li onclick="location.href='mypage-forsale.html'">
                <svg  viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                 <path d="M2.75 8C2.75 6.20507 4.20507 4.75 6 4.75H18C19.7949 4.75 21.25 6.20507 21.25 8V16C21.25 17.7949 19.7949 19.25 18 19.25H6C4.20507 19.25 2.75 17.7949 2.75 16V8Z"  stroke-width="1.5"/>
                 <path d="M15.75 12C15.75 10.7574 16.7574 9.75 18 9.75H21.25V14.25H18C16.7574 14.25 15.75 13.2426 15.75 12Z"  stroke-width="1.5"/>
                 <path d="M6 8H10.5" stroke-width="1.5" stroke-linecap="round"/>
               </svg>

               <br>
               내 매물<span>2</span>
           </li>
           <li onclick="location.href='myorder.html'">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                 <circle cx="12" cy="12" r="9"  stroke-width="1.5"/>
                 <path d="M12 6V12L15 15"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
               </svg>
               <br>
               매칭 대기<span>23</span>
           </li>
           <li onclick="location.href='myorder.html#review-tab'">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                 <path d="M11.0512 4.89768H4.78915C4.31464 4.89768 3.85956 5.08618 3.52403 5.42171C3.1885 5.75724 3 6.21231 3 6.68682V19.2109C3 19.6854 3.1885 20.1404 3.52403 20.476C3.85956 20.8115 4.31464 21 4.78915 21H17.3132C17.7877 21 18.2428 20.8115 18.5783 20.476C18.9138 20.1404 19.1023 19.6854 19.1023 19.2109V12.9488M17.7605 3.55582C18.1163 3.19993 18.599 3 19.1023 3C19.6056 3 20.0883 3.19993 20.4442 3.55582C20.8001 3.9117 21 4.39438 21 4.89768C21 5.40097 20.8001 5.88365 20.4442 6.23954L11.9457 14.738L8.36744 15.6326L9.26201 12.0543L17.7605 3.55582Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
               </svg>
               <br>
               리뷰
           </li>
         </ul>
       </div>
    <div class="btn-group4 px-3 pt-3" role="group" v-if="me">
      <b-button class="btn btn-lg btn-outline-primary" @click="$router.push('/my/room')">내 매물보기</b-button>
      <b-button type="button" variant="btn btn-lg btn-primary" onclick="location.href='/room/add'">3분만에 방 등록</b-button>
    </div>
    </section>
 

    <section v-if="isLogin">
      <div class="center-banner-wrap">
        <img src="../../../../assets/img/banner.png">
      </div>
    </section>

    <section v-if="isLogin">
      <div class="subtitle_wrap-button Subtitle1">
        <h6>찜해둔 방</h6>
        <b-button type="button" class="btn btn-sm btn-link" @click="$router.push('/my/like')">더보기
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8.96967 17.4697C8.67678 17.7626 8.67678 18.2374 8.96967 18.5303C9.26256 18.8232 9.73744 18.8232 10.0303 18.5303L8.96967 17.4697ZM15.5 12L16.0303 12.5303C16.171 12.3897 16.25 12.1989 16.25 12C16.25 11.8011 16.171 11.6103 16.0303 11.4697L15.5 12ZM10.0303 5.46967C9.73744 5.17678 9.26256 5.17678 8.96967 5.46967C8.67678 5.76256 8.67678 6.23744 8.96967 6.53033L10.0303 5.46967ZM10.0303 18.5303L16.0303 12.5303L14.9697 11.4697L8.96967 17.4697L10.0303 18.5303ZM16.0303 11.4697L10.0303 5.46967L8.96967 6.53033L14.9697 12.5303L16.0303 11.4697Z"  >
            </path></svg>
        </b-button>
      </div>

      <!-- stlye 은 slick 영역 확인용 -->
      <div id="slider-div" class="multi-slide">
        <div>
          <div class="list-thumnail-cl multi-slide">

          <div class="relative col-3" v-for="l in likes" :key="l._id" @click="$router.push(`/room/${l.room._id}`)">
            <ul>
              <li><img :src="l.room.roomThumbnailImg"></li>
              <li>
                <p class="body2 light_txt_lgrey">{{ l.room.roomSiDo }} {{ l.room.roomSiGunGu }} {{ l.room.roomEupMyeonDong }}</p>
                <p class="Subtitle2 light_txt_grey">{{ l.room.roomHouseType }} {{ l.room.roomType }}</p>
                <div class="align-items-sm-start price fd-c">
                  <span class="label-outline-circle-main">{{ l.room.roomContractType }}</span>
                  <h4 class="">{{ l.room.roomDeposit }} / {{ l.room.roomMonthlyPrice }}</h4>
                </div>
                <p class="body1">{{l.room.roomArea}}/{{ Math.round(l.room.roomArea * 3.3) }}㎡<span class="line-grey"></span>{{ l.room.roomFloor }} / {{ l.room.roomTotalFloor }}층</p>
              </li>
            </ul>
          </div>
        </div>
        </div>
      </div>
       
    </section>


    <section v-if="isLogin">
      <div class="subtitle_wrap-button Subtitle1">
        <h6>최근 본 방</h6>
        <b-button type="button" class="btn btn-sm btn-link" onclick="location.href='/my/recent'">더보기
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8.96967 17.4697C8.67678 17.7626 8.67678 18.2374 8.96967 18.5303C9.26256 18.8232 9.73744 18.8232 10.0303 18.5303L8.96967 17.4697ZM15.5 12L16.0303 12.5303C16.171 12.3897 16.25 12.1989 16.25 12C16.25 11.8011 16.171 11.6103 16.0303 11.4697L15.5 12ZM10.0303 5.46967C9.73744 5.17678 9.26256 5.17678 8.96967 5.46967C8.67678 5.76256 8.67678 6.23744 8.96967 6.53033L10.0303 5.46967ZM10.0303 18.5303L16.0303 12.5303L14.9697 11.4697L8.96967 17.4697L10.0303 18.5303ZM16.0303 11.4697L10.0303 5.46967L8.96967 6.53033L14.9697 12.5303L16.0303 11.4697Z"  >
            </path></svg>
        </b-button>
      </div>

      <div class="d-flex px-3 fd-c gap-3">
        <div class="list-thumnail" onclick="location.href='/room/_id'">

          <div class="relative col-12" v-for="rv in recentViews" :key="rv._id" @click="$router.push(`/room/${rv.room._id}`)">
            <ul>
              <li><img :src="rv.room.roomThumbnailImg"></li>
              <li>
                <p class="body2 light_txt_lgrey">{{ rv.room.roomSiDo }} {{ rv.room.roomSiGunGu }} {{ rv.room.roomEupMyeonDong }}</p>
                <p class="Subtitle2 light_txt_grey">{{ rv.room.roomHouseType }} {{ rv.room.roomType }}</p>
                <div class="price"><span class="label-circle-main-light">{{ rv.room.roomContractType }}</span><h4 class="">{{ rv.room.roomDeposit }} / {{ rv.room.roomMonthlyPrice }}</h4></div>
                <p class="body1">{{rv.room.roomArea}}/{{ Math.round(rv.room.roomArea * 3.3) }}㎡<span class="line-grey"></span>{{ rv.room.roomFloor }} / {{ rv.room.roomTotalFloor }}층</p>
              </li>
            </ul>

          </div>
        </div>
      </div>

    </section>

    <section>
      <div class="center-banner-wrap">
        <img src="../../../../assets/img/banner2.png">
      </div>
    </section>


    <section>

      <div class="subtitle_wrap-button Subtitle1">
        <h6>고객센터</h6>
      </div>
      <div class="info_txt-sm">캥거룸 서비스 이용 중 불편한 점과 문의 하실 내용은 문의하기를 통해 자유롭게 남겨주세요. 24시간 내에 담당자가 최선을 다해 문제를 해결해드리겠습니다.
      </div>


      <div class="txt-icon-button">

      <b-button type="button" class="btn-lg btn w-100 btn-outline-info" onclick="location.href='/faq'">자주 묻는 질문
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M8.96967 17.4697C8.67678 17.7626 8.67678 18.2374 8.96967 18.5303C9.26256 18.8232 9.73744 18.8232 10.0303 18.5303L8.96967 17.4697ZM15.5 12L16.0303 12.5303C16.171 12.3897 16.25 12.1989 16.25 12C16.25 11.8011 16.171 11.6103 16.0303 11.4697L15.5 12ZM10.0303 5.46967C9.73744 5.17678 9.26256 5.17678 8.96967 5.46967C8.67678 5.76256 8.67678 6.23744 8.96967 6.53033L10.0303 5.46967ZM10.0303 18.5303L16.0303 12.5303L14.9697 11.4697L8.96967 17.4697L10.0303 18.5303ZM16.0303 11.4697L10.0303 5.46967L8.96967 6.53033L14.9697 12.5303L16.0303 11.4697Z" fill="var(--bs-gray-dark)" >
          </path></svg>
      </b-button>
        <b-button type="button" class="btn-lg btn w-100 btn-outline-info" onclick="location.href='/my/qna'">문의하기
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8.96967 17.4697C8.67678 17.7626 8.67678 18.2374 8.96967 18.5303C9.26256 18.8232 9.73744 18.8232 10.0303 18.5303L8.96967 17.4697ZM15.5 12L16.0303 12.5303C16.171 12.3897 16.25 12.1989 16.25 12C16.25 11.8011 16.171 11.6103 16.0303 11.4697L15.5 12ZM10.0303 5.46967C9.73744 5.17678 9.26256 5.17678 8.96967 5.46967C8.67678 5.76256 8.67678 6.23744 8.96967 6.53033L10.0303 5.46967ZM10.0303 18.5303L16.0303 12.5303L14.9697 11.4697L8.96967 17.4697L10.0303 18.5303ZM16.0303 11.4697L10.0303 5.46967L8.96967 6.53033L14.9697 12.5303L16.0303 11.4697Z" fill="var(--bs-gray-dark)" >
            </path></svg>
        </b-button>
        <b-button type="button" class="btn-lg btn w-100 btn-outline-info" onclick="location.href='/notice'">공지사항
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8.96967 17.4697C8.67678 17.7626 8.67678 18.2374 8.96967 18.5303C9.26256 18.8232 9.73744 18.8232 10.0303 18.5303L8.96967 17.4697ZM15.5 12L16.0303 12.5303C16.171 12.3897 16.25 12.1989 16.25 12C16.25 11.8011 16.171 11.6103 16.0303 11.4697L15.5 12ZM10.0303 5.46967C9.73744 5.17678 9.26256 5.17678 8.96967 5.46967C8.67678 5.76256 8.67678 6.23744 8.96967 6.53033L10.0303 5.46967ZM10.0303 18.5303L16.0303 12.5303L14.9697 11.4697L8.96967 17.4697L10.0303 18.5303ZM16.0303 11.4697L10.0303 5.46967L8.96967 6.53033L14.9697 12.5303L16.0303 11.4697Z" fill="var(--bs-gray-dark)" >
            </path></svg>
        </b-button>

      </div>

    </section>



  </div>
 <!--content e-->
  </div>

</template>
<script>
  export default {
    async asyncData({ app }) {
      const uid = app.$cookies.get('uid');
      let isLogin = false;
      let existLike = false;
      let existRecentView = false

      if (uid) {
        isLogin = true;

        const { data: me } = await app.$axios.get(`/user/me/${uid}`);
        const { data: likes } = await app.$axios.get('/user/my/likes', {
          params: {
            uid: uid,
          }
        });

        const { data: recentViews } = await app.$axios.get('/user/my/recent-views', {
          params: {
            uid: uid,
          }
        });

        if (likes.length !== 0) {
          existLike = true;
        }

        if (recentViews.length !== 0) {
          existRecentView = true;
        }
        return { uid, me, isLogin, existLike, existRecentView, likes, recentViews };
      } else {
        return { uid, isLogin };
      }
    }
  }
</script>
