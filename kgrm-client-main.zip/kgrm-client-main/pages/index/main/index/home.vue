<template>

  <div id="app">
<!--header s-->
    <header class="sticky-header d-flex bg-white flex-wrap align-items-center justify-content-between py-3 border-bottom">
           <a href="home" class="d-flex align-items-center mb-md-0 me-md-auto text-dark text-decoration-none">
               <h3 class="cl_primary font-montserrat lh-17">KANGAROOM</h3>
           </a>
           <b-button type="button" class="d-none btn btn-sm position-absolute end-16 btn-link" data-bs-toggle="modal" data-bs-target="#alarm">
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#A9B2B9">
                   <path d="M18.2395 8.97519L17.4943 9.05977L18.2395 8.97519ZM18.6867 12.9153L19.4319 12.8307V12.8307L18.6867 12.9153ZM5.31328 12.9153L4.56806 12.8307L4.56806 12.8307L5.31328 12.9153ZM5.76046 8.97519L6.50568 9.05977L5.76046 8.97519ZM4.44779 14.8721L3.87668 14.386H3.87668L4.44779 14.8721ZM19.5522 14.8721L18.9811 15.3583L19.5522 14.8721ZM14.2699 4.37366H13.5199C13.5199 4.69424 13.7237 4.97938 14.027 5.08322L14.2699 4.37366ZM9.73005 4.37366L9.973 5.08322C10.2763 4.97938 10.4801 4.69424 10.4801 4.37366H9.73005ZM15.7023 20.2632C15.8477 19.8753 15.6511 19.4431 15.2632 19.2977C14.8753 19.1523 14.4431 19.3489 14.2977 19.7368L15.7023 20.2632ZM9.7023 19.7368C9.55694 19.3489 9.12467 19.1523 8.7368 19.2977C8.34893 19.4431 8.15234 19.8753 8.2977 20.2632L9.7023 19.7368ZM17.7772 17.25H6.22281V18.75H17.7772V17.25ZM17.4943 9.05977L17.9415 12.9998L19.4319 12.8307L18.9848 8.89061L17.4943 9.05977ZM6.05849 12.9998L6.50568 9.05977L5.01525 8.89061L4.56806 12.8307L6.05849 12.9998ZM5.01889 15.3583C5.59621 14.6801 5.96028 13.8652 6.05849 12.9998L4.56806 12.8307C4.50519 13.3846 4.27067 13.9231 3.87668 14.386L5.01889 15.3583ZM17.9415 12.9998C18.0397 13.8652 18.4038 14.6801 18.9811 15.3583L20.1233 14.386C19.7293 13.9231 19.4948 13.3846 19.4319 12.8307L17.9415 12.9998ZM6.22281 17.25C5.56777 17.25 5.10443 16.926 4.89056 16.5492C4.68409 16.1854 4.68714 15.748 5.01889 15.3583L3.87668 14.386C3.11141 15.285 3.08777 16.4116 3.58598 17.2895C4.07679 18.1544 5.04947 18.75 6.22281 18.75V17.25ZM17.7772 18.75C18.9505 18.75 19.9232 18.1544 20.414 17.2895C20.9122 16.4116 20.8886 15.285 20.1233 14.386L18.9811 15.3583C19.3129 15.748 19.3159 16.1854 19.1094 16.5492C18.8956 16.926 18.4322 17.25 17.7772 17.25V18.75ZM15.0199 4.37366V4.26995H13.5199V4.37366H15.0199ZM18.9848 8.89061C18.7055 6.43026 16.8806 4.47476 14.5129 3.6641L14.027 5.08322C15.9441 5.73962 17.2913 7.27101 17.4943 9.05977L18.9848 8.89061ZM10.4801 4.37366V4.26995H8.98005V4.37366H10.4801ZM6.50568 9.05977C6.7087 7.27101 8.05587 5.73962 9.973 5.08322L9.48711 3.6641C7.11944 4.47476 5.29449 6.43026 5.01525 8.89061L6.50568 9.05977ZM12 2.75C12.8394 2.75 13.5199 3.4305 13.5199 4.26995H15.0199C15.0199 2.60208 13.6679 1.25 12 1.25V2.75ZM12 1.25C10.3321 1.25 8.98005 2.60208 8.98005 4.26995H10.4801C10.4801 3.4305 11.1606 2.75 12 2.75V1.25ZM14.2977 19.7368C13.975 20.5979 13.0846 21.25 12 21.25V22.75C13.6855 22.75 15.1516 21.7325 15.7023 20.2632L14.2977 19.7368ZM12 21.25C10.9154 21.25 10.025 20.5979 9.7023 19.7368L8.2977 20.2632C8.84835 21.7325 10.3145 22.75 12 22.75V21.25Z" fill="#A9B2B9"/>
               </svg>
           </b-button>
       </header>
<!--header e-->
 <!--main top s-->

<div class="main-banner">
    <h1>내가 살고싶은 곳의<br>내 집 찾기</h1>
    <img src="../../../../assets/img/2x/illust_05.png" data-aos="fade-up" data-aos-delay="200" data-aos-duration="1000" class="py-5">
    <div class="input-group mb-3">
        <input type="text" class="form-control" placeholder="지번, 시/군/구/동, 대학교, 지하철역" aria-label="지번, 시/군/구/동, 대학교, 지하철역" aria-describedby="button-addon2">
        <b-button class="btn btn-md btn-white" type="button" id="button-addon2">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M15 15L19 19" stroke="#232C34" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                <circle cx="10" cy="10" r="6.25" stroke="#232C34" stroke-width="1.5"/>
            </svg>
        </b-button>
    </div>
</div>
<!--main top e-->

    <!--새로 내놓은 방 morebutton s-->

<div class="subtitle_wrap-button Subtitle1 pt-5">
    <h3>새로 내놓은 방</h3>
    <div class="room-count">
        <span>금일건수</span><span class="line-grey"></span><span class="light_txt_grey">총 건수</span>
    </div>
</div>

<div class="d-flex align-items-start gap-3 py-3" style=" flex-direction:column!important">
  <div class="list-lg" v-for="r in rooms" :key="r._id">
    <div class="relative col-12">
        <ul data-animation="1" @click="goToDetails(r._id)">
            <li><img :src="r.roomThumbnailImg"></li>
            <li>
                <p class="body2 light_txt_lgrey">{{ r.roomSiDo }} {{ r.roomSiGunGu }} {{ r.roomEupMyeonDong }}</p>
                <p class="Subtitle2 light_txt_grey">{{ r.roomHouseType }} {{ r.roomType }}</p>
                <div class="price"><span class="label-outline-circle-main">{{ r.roomContractType }}</span><h4 class="">
                  {{ r.roomDeposit }} / {{ r.roomMonthlyPrice }}</h4></div>
            </li>
        </ul>
        <div class="w-100 mt-2" style="overflow:hidden">
            <p class="body1">{{r.roomArea}}/{{ Math.round(r.roomArea * 3.3) }}㎡<span class="line-grey"></span>{{ r.roomFloor }} / {{ r.roomTotalFloor }}층</p>
            <p class="body1">{{ r.roomMemo }}</p>
        </div>
        <div class="tag-list mt-2">
            <span class="label-outline-round-grey" v-if="r.roomIsFullOption">풀옵션</span>
            <span class="label-outline-round-grey" v-if="r.roomCanParking">주차</span>
            <span class="label-outline-round-grey" v-if="r.roomExistEv">엘리베이터</span>
            <span class="label-outline-round-grey" v-if="r.roomCanPet">반려동물</span>
            <span class="label-outline-round-grey" v-if="r.roomCanLoan">전세대출</span>
        </div>
        <div class="write-date mt-3 mb-3"><span class="label-outline-circle-green">New</span><p>최초 등록일 {{ r.createdAt | dateFilter }}</p></div>
        <div class="list-btn">
            <b-button type="button" class="btn btn-sm w-100 btn-outline-primary" onclick="location.href='tel:010-3034-8912'">
                전화문의
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M4.10382 5.89027L5.52851 4.46557C6.3121 3.68199 7.58271 3.67038 8.3521 4.43978L9.08652 5.17419C9.89089 5.97856 10.0347 7.23364 9.43985 8.22019L8.71599 9.41967C8.47237 9.81717 8.58008 10.2753 8.85307 10.6395C10.6173 12.9935 11.3167 13.6929 13.3575 15.144C13.7285 15.4078 14.1799 15.5247 14.5774 15.2811L15.7769 14.5572C16.7634 13.9623 18.0185 14.1062 18.8228 14.9105L19.5573 15.6449C20.3267 16.4143 20.3151 17.6849 19.5315 18.4685L18.5 19.5L18.0928 19.8792C17.2308 20.7412 15.9438 21.007 14.8256 20.5585L14.2771 20.3376C9.66559 18.2763 5.74804 14.43 3.64545 9.70599L3.42459 9.15745C2.97601 8.03927 3.24188 6.75221 4.10382 5.89027Z"  stroke-width="1.5" stroke-miterlimit="10"/>
                    <path d="M20 11C20 7.13401 16.866 4 13 4"   stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M17 11C17 8.79086 15.2091 7 13 7"  stroke-width="1.5" stroke-linecap="round"/>
                    </svg>

            </b-button>
            <b-button type="button" class="d-none btn btn-sm w-50 btn-primary">
                채팅하기
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <g clip-path="url(#clip0_151_4749)">
                        <path d="M7.92289 17.6365L17.4408 17.6669C18.9793 17.6669 20.2306 16.4309 20.2306 14.9113V7.51555C20.2306 5.99588 18.9793 4.75989 17.4408 4.75989H6.55879C5.02033 4.75989 3.76904 5.99588 3.76904 7.51555V14.9214L3.82033 19.9667C3.82033 20.2098 4.09725 20.3314 4.29212 20.1794L7.70751 17.7176C7.76904 17.6669 7.85109 17.6365 7.93315 17.6365H7.92289Z" stroke="#fff" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"/>
                        <path d="M7.19487 9.01489H16.7641" stroke="#fff" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"/>
                        <path d="M7.19487 12.4088H16.7641" stroke="#fff" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"/>
                    </g>
                    <defs>
                        <clipPath id="clip0_151_4749">
                            <rect width="18" height="17" fill="white" transform="translate(3 4)"/>
                        </clipPath>
                    </defs>
                </svg>
            </b-button>
        </div>
    </div>
    <div class="list-btn position-absolute top-0 end-0">
        <b-button type="button" id="btn-favorite" class="btn btn-md btn-link" >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path id="favorive-star" d="M9.5054 7.93631L12 2.90354L14.4946 7.93631C14.6957 8.34211 15.0837 8.62187 15.5306 8.68653L21.102 9.4926L17.0727 13.4032C16.7479 13.7185 16.5989 14.1737 16.6759 14.6205L17.6278 20.1465L12.6392 17.5352C12.2389 17.3257 11.7611 17.3257 11.3608 17.5352L6.37222 20.1465L7.32411 14.6205C7.40109 14.1737 7.25208 13.7185 6.92727 13.4032L2.89797 9.4926L8.46937 8.68653C8.91633 8.62187 9.30425 8.34211 9.5054 7.93631ZM21.2879 9.31222L21.2877 9.31244L21.2879 9.31222Z" stroke="#D9DEE2" stroke-width="1.5"/>
            </svg>
        </b-button>
    </div>
  </div>
    <b-button type="button" class="btn btn-lg btn-outline-secondary w-100">더보기</b-button>
</div>





<!-- Banner s -->
    <div class="center-banner-wrap">
      <img src="../../../../assets/img/banner.png">
      <font-awesome-icon icon="hat-wizard" />
    </div>
 <!-- Banner e -->
    <div class="py-5"></div>
<!--content-->
  </div>
</template>

<script>
import moment from 'moment';

export default {
  async asyncData({ app }) {
    const uid = app.$cookies.get('uid');
    const { data: rooms } = await app.$axios.get('/user/list/room');

    return { uid, rooms };
  },
  data() {
    return {
      price: 0
    }
  },
  filters: {
    dateFilter(val) {
      return moment(val).format('YYYY.MM.DD');
    },
  },
  methods: {
    async goToDetails(id) {
      const format = {
        uid: this.uid,
        rid: id
      };

      await this.$axios.post('/user/psot/recent-view', { ...format });

      this.$router.push(`/room/${id}`)
    }
  }
}
</script>
