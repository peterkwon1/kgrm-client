<template>
    <div class="wrap">
      <nuxt-child/>
    </div>
    
  </template>
  
 
  