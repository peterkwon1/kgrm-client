<template>
       <div id="app">

        <div class="container vh-100">

<!-- Outer Row -->
<div class="row justify-content-center align-items-center h-100">

    <div class="col-xl-5 col-lg-12 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-2">비밀번호 찾기</h1>
                                <p class="mb-4">이메일 주소로 비밀번호를 재설정할 수 있는 링크를 보내드립니다</p>
                            </div>
                            <form class="user">
                                <div class="form-group">
                                    <b-form-input v-model="email" placeholder="이메일 주소 입력" class="form-control form-control-user w-100"
                                        id="exampleInputEmail" aria-describedby="emailHelp"></b-form-input>
 
                                </div>
                                <a href="login" class="btn btn-primary btn-user btn-block">
                                    비밀번호 재설정
                                </a>
                            </form>
                            <hr>
                            <div class="text-center">
                                <a class="small" href="register">계정 생성하기</a>
                            </div>
                            <div class="text-center">
                                <a class="small" href="login">로그인하기</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

</div>

</div>

    </div>
    
  </template>
  
 
  