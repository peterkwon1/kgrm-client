<template>
       <div id="app">

        <div class="container vh-100">
        
        <div class="card o-hidden border-0  my-5 align-items-center h-100">
            <div class="col-xl-5 col-lg-12 col-md-9">
                <div class="card o-hidden border-0 shadow-lg my-5">
                <!-- Nested Row within Card Body -->
                <div class="row">
                     <div class="col-lg-12">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">계정 생성</h1>
                            </div>
                            <form class="user">
                                <div class="form-group">
                                        <input type="text" class="form-control form-control-user mb-3 w-100" id="exampleFirstName"
                                            placeholder="이름">
                                 
                                    <input type="email" class="form-control form-control-user mb-3 w-100" id="exampleInputEmail"
                                        placeholder="Email">
                                
                                        <input type="password" class="form-control form-control-user mb-3 w-100"
                                            id="exampleInputPassword" placeholder="비밀번호">
                                        <input type="password" class="form-control form-control-user w-100"
                                            id="exampleRepeatPassword" placeholder="비밀번호 확인">
                                        </div>
                                <a href="login" class="btn btn-primary btn-user btn-block">
                                    계정 생성하기
                                </a>
                            </form>
                            <hr>
                            <div class="text-center">
                                <a class="small" href="forgot-password">비밀번호를 잊으셨나요?</a>
                            </div>
                            <div class="text-center">
                                <a class="small" href="login">로그인</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    
  </template>
  
 
  