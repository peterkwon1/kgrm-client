<template>
       <div id="app">
        <div class="container vh-100">

<!-- Outer Row -->
<div class="card o-hidden border-0 my-5 align-items-center h-100">

    <div class="col-xl-5 col-lg-12 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                     <div class="col-lg-12">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">관리자 로그인</h1>
                            </div>
                            <form class="user  mx-auto">
                                <div class="form-group ">
                                    <b-form-input v-model="email" placeholder="이메일 주소 입력" class="form-control form-control-user w-100"
                                        id="exampleInputEmail" aria-describedby="emailHelp"></b-form-input>

                                         
                                </div>
                                <div class="form-group ">
                                    <b-form-input v-model="password" placeholder="비밀번호 입력" class="form-control form-control-user w-100"
                                        id="exampleInputEmail" aria-describedby="emailHelp"></b-form-input>
 
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox small">
                                        <input type="checkbox" class="custom-control-input" id="customCheck">
                                        <label class="custom-control-label" for="customCheck">로그인 정보 저장</label>
                                    </div>
                                </div>
                                <a href="index" class="btn btn-primary btn-user btn-block">
                                    로그인
                                </a>
                                 
                            </form>
                            <hr>
                            <div class="text-center">
                                <a class="small" href="forgot-password">비밀번호를 잊으셨나요?</a>
                            </div>
                            <div class="text-center">
                                <a class="small" href="register">계정 생성하기</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

</div>

</div>
    </div>
    
  </template>
  
 
  