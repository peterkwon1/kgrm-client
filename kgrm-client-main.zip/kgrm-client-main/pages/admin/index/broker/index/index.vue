<template>

    <div id="app">
   
    
  <!-- Content Wrapper -->
  <div id="content-wrapper" class="d-flex flex-column">
  
  <!-- Main Content -->
  <div id="content">
    
  
      <!-- Begin Page Content -->
      <div class="container-fluid">

<!-- Page Heading -->
<h1 class="h4   text-gray-800">중개업체 관리 - 중개사회원 목록</h1>

<!-- Tab wrap-->
<div class="d-flex flex-wrap">
    <!-- Tab -->
    <div class="panel-body w-100" >

                <!-- Search + Filter-->
                <div class="bg-white py-4 px-4 rounded mb-4 mt-4">
                    <!--가입일-->
                    <div class="d-flex gap-5 align-items-center pb-3">
                        <div class="admin-menu-title"><h6 class="mb-0">가입일</h6></div>
                        <b-form-group  v-slot="{ ariaDescribedby }">
                        <b-form-radio-group
                            id="btn-radios-1"
                            v-model="selected4"
                            :options="options4"
                            :aria-describedby="ariaDescribedby"
                            button-variant="outline-gray"
                            class="h-48"
                            name="radios-btn-default"
                            buttons
                        ></b-form-radio-group>
                        </b-form-group> 
                        <div class="d-flex align-items-center gap-3">
                            <b-form-datepicker v-model="value" :min="min" :max="max" locale="kr"></b-form-datepicker>
                        <span>~</span>
                            <b-form-datepicker v-model="value" :min="min" :max="max" locale="kr"></b-form-datepicker>
                        </div>


                    </div>

                    <div class="d-flex gap-4 pb-4">
                        <!--회원정보-->
                        <div class="d-flex gap-5 flex-basis-50 align-items-center">
                            <div class="admin-menu-title"><h6 class="mb-0">회원정보</h6></div>
                            <b-form-select v-model="selected2" :options="options2" class="w-20"></b-form-select>
                            <div class="input-group ">
                                <b-form-input v-model="text" placeholder="검색 입력"></b-form-input>
                             </div>
                        </div>

                        <!--등록상태-->
                        <div class="d-flex gap-5 flex-basis-50 align-items-center">
                            <div class="admin-menu-title"><h6 class="mb-0">등록상태</h6></div>
                            <b-form-select v-model="selected3" :options="options3" class="w-20"></b-form-select>
 
                        </div>
                    </div>
                    <!--업체이름-->
                    <div class="d-flex gap-5 align-items-center">
                        <div class="admin-menu-title"><h6 class="mb-0">업체이름</h6></div>
                        <div class="input-group w-20">
                            <b-form-input v-model="text" placeholder="검색 입력"></b-form-input>
                        </div>
                    </div>

                    <!-- button-->

                    <div class="d-flex justify-content-center gap-4">
                        <a href="#" class="btn btn-primary w-10">
                            <span class="text">조회</span>
                        </a>
                        <a href="#" class="btn btn-light w-10">
                            <span class="text">초기화</span>
                        </a>

                    </div>
                </div>
                <!-- search+filter end-->

                 <!-- Table -->
        <div class="table_wrap">
            <div class="mb-3 d-flex justify-content-end align-items-center gap-3">
                <span>보여질 개수</span><b-form-select v-model="selected" :options="options" size="sm" class="w-10"></b-form-select>
            </div>
            <b-table striped hover :items="items" :fields="fields"></b-table>
            <div class="mx-auto overflow-auto">
            <b-pagination-nav :link-gen="linkGen" :number-of-pages="10" use-router class="mt-3"></b-pagination-nav>
        </div>
         </div>


    </div>


</div>

</div>
      <!-- /.container-fluid -->
  
  </div>
  <!-- End of Main Content -->
   
  
  </div>
  <!-- End of Content Wrapper -->
  
  
  
    </div>
  </template>
  
  <script>
    export default {
        methods: {
      linkGen(pageNum) {
        return pageNum === 1 ? '?' : `?page=${pageNum}`
      }
    },
      data() {
        const now = new Date()
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())
      // 15th two months prior
      const minDate = new Date(today)
      minDate.setMonth(minDate.getMonth() - 2)
      minDate.setDate(15)
      // 15th in two months
      const maxDate = new Date(today)
      maxDate.setMonth(maxDate.getMonth() + 2)
      maxDate.setDate(15)

        return {
          // Note 'isActive' is left out and will not appear in the rendered table
          value: '',
        min: minDate,
        max: maxDate,

          fields: [
            {
              key: 'No',
              sortable: true
            },
            {
              key: '이름',
              sortable: true
            },
            {
              key: '업체이름',
              sortable: true,
              // Variant applies to the whole column, including the header and footer
            },
            {
              key: '회원유형',
              sortable: true
            },
            {
              key: '로그인방식',
              sortable: false
            },
            {
              key: '연락처',
              sortable: true
            },
            {
              key: '회원Email',
              sortable: true
            },
            {
              key: '가입일',
              sortable: true
            },
            {
              key: '상태',
              sortable: true
            }
          ],
          items: [
            { isActive: true, 상태:'등록', 가입일:'2022-12-20', 회원Email:'testerkwon@gmail.com', 연락처:'010-2468-1234', 로그인방식: '카카오', 회원유형: '중개사회원', 업체이름: '연남동 명성 공인중개사사무소', 이름: '권오희', No: '1' },
            { isActive: true, 상태:'등록', 가입일:'2022-12-20', 회원Email:'testerkwon@gmail.com', 연락처:'010-2468-1234', 로그인방식: '네이버', 회원유형: '중개사회원', 업체이름: '연남동 명성 공인중개사사무소', 이름: '권오희', No: '2' },
            { isActive: true, 상태:'등록', 가입일:'2022-12-20', 회원Email:'testerkwon@gmail.com', 연락처:'010-2468-1234', 로그인방식: '카카오', 회원유형: '중개사회원', 업체이름: '연남동 명성 공인중개사사무소', 이름: '권오희', No: '3' },
            { isActive: true, 상태:'등록', 가입일:'2022-12-20', 회원Email:'testerkwon@gmail.com', 연락처:'010-2468-1234', 로그인방식: '네이버', 회원유형: '중개사회원', 업체이름: '연남동 명성 공인중개사사무소', 이름: '권오희', No: '4' },
            { isActive: true, 상태:'등록', 가입일:'2022-12-20', 회원Email:'testerkwon@gmail.com', 연락처:'010-2468-1234', 로그인방식: '카카오', 회원유형: '중개사회원', 업체이름: '연남동 명성 공인중개사사무소', 이름: '권오희', No: '5' },
            { isActive: true, 상태:'확인중', 가입일:'2022-12-20', 회원Email:'testerkwon@gmail.com', 연락처:'010-2468-1234', 로그인방식: '네이버', 회원유형: '중개사회원', 업체이름: '연남동 명성 공인중개사사무소', 이름: '권오희', No: '6' },
            { isActive: true, 상태:'등록대기', 가입일:'2022-12-20', 회원Email:'testerkwon@gmail.com', 연락처:'010-2468-1234', 로그인방식: '카카오', 회원유형: '중개사회원', 업체이름: '연남동 명성 공인중개사사무소', 이름: '권오희', No: '7' }  
          ],
          selected: 10,
          options: [
            { value: '10', text: '10' },
            { value: '25', text: '25' },
            { value: '50', text: '50' },
            { value: '100', text: '100' }
          ],
          selected2: 'a',
        options2: [
          { value: 'a', text: '전체' },
          { value: 'b', text: '회원이메일' },
          { value: 'c', text: '회원이름 '}
        ],
        selected3: 'e',
        options3: [
          { value: 'e', text: '전체' },
          { value: 'f', text: '등록대기' },
          { value: 'g', text: '확인중'},
          { value: 'g', text: '등록'},
          { value: 'g', text: '반려'}
        ],
        selected4: '전체',
        options4: [
          { text: '전체', value: '전체' },
          { text: '오늘', value: '오늘' },
          { text: '3일', value: '3일' },
          { text: '1주일', value: '1주일' },
          { text: '1개월', value: '1개월' },
          { text: '3개월', value: '3개월' }
        ]
        }
      }
    }
  </script>
    
 