<template>

  <div id="app">
 
  
<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

<!-- Main Content -->
<div id="content">
  

    <!-- Begin Page Content -->
    <div class="container-fluid">

<!-- Page Heading -->
<h1 class="h4 mb-4">중개사회원 상세정보</h1>
<a href="../broker" class="btn btn-light btn-icon-split mb-4">
    <span class="material-symbols-outlined text-gray-600">keyboard_backspace</span>
    <span class="text">리스트로 돌아가기</span>
</a>


<div class="row">

    <div class="col-lg-12">
        <div class="card lg mb-4">

<!-- 중개사 업체 주요정보 -->

<div class="card-header px-3 pt-4 pb-0 d-flex flex-row align-items-center justify-content-between  ">
    <h6 class="mb-0 font-weight-bold">중개사 업체 주요정보</h6>
    <b-button variant="sm btn-primary btn-icon-split" onclick="location.href='_id2'"><span class="material-symbols-outlined mr-2" >edit</span>정보수정완료</b-button>
 
</div>
<div class="card-body">
     <div class="divTable2">
        <div class="divTableBody2">
            <div class="divTableRow2">
                <div class="divTableCell2 divTableHead2">업체 프로필이미지</div>
                <div class="divTableCell2">
                    <div class="profile_thumnail">
                        <img src="../../../../../assets/img/icon/user.svg"> 
                    </div>
                </div>
            </div>
            <div class="divTableRow2">
                <div class="divTableCell2 divTableHead2">업체명<span class="text-primary">*</span></div>
                <div class="divTableCell2"><b-form-input v-model="text" placeholder="연남동 명성 공인중개사사무소"></b-form-input></div>
            </div>
            <div class="divTableRow2">
                <div class=" divTableCell2 divTableHead2">대표자명<span class="text-primary">*</span></div>
                <div class="divTableCell2"><b-form-input v-model="text" placeholder="19990909"></b-form-input></div>
            </div>
            <div class="divTableRow2">
                <div class=" divTableCell2 divTableHead2">대표번호<span class="text-primary">*</span></div>
                <div class="divTableCell2"><b-form-input v-model="text" placeholder="19990909"></b-form-input></div>
            </div>

            <div class="divTableRow2">
                <div class=" divTableCell2 divTableHead2">주소<span class="text-primary">*</span></div>
                <div class="divTableCell2">
                    <div class="d-flex align-items-center gap-3">
                        <div class="input-group w-50">
                    <b-form-input v-model="text" placeholder="19990909"></b-form-input>
                    <b-button variant="sm btn-primary btn-icon-split w-20" >주소검색</b-button>
                </div>
                    <span class="ml-4">(주소검색시, 자동완성)</span>
                </div>
                </div>
            </div>
            <div class="divTableRow2">
                <div class=" divTableCell2 divTableHead2">사업자 등록번호<span class="text-primary">*</span></div>
                <div class="divTableCell2"><b-form-input v-model="text" placeholder="19990909"></b-form-input></div>
            </div>
            <div class="divTableRow2">
                <div class=" divTableCell2 divTableHead2">중개사 등록번호<span class="text-primary">*</span></div>
                <div class="divTableCell2"><b-form-input v-model="text" placeholder="19990909"></b-form-input></div>
            </div>
        </div>
    </div>
</div>




<!-- 등록한 매물 -->
<div class="card-header px-3 pt-4 pb-0 d-flex flex-row align-items-center justify-content-between  ">
    <h6 class="  mb-0 font-weight-bold">등록매물 정보 총 <span class="text-primary">2</span>건</h6>

</div>
<div class="card-body">
    <div class="divTable2">
        <table class="table table-bordered" id="dataTable2" width="100%" cellspacing="0">
            <thead>
            <tr>

                <th class="center">매물번호</th>
                <th class="center">매물정보</th>
                 <th class="center">주소지</th>
                <th class="center">등록일</th>
                <th class="center">매물상태</th>
                <th class="center">조회</th>
                <th class="center">찜</th>
                <th class="center">문의</th>
                <th class="center w-10"></th>
            </tr>
            </thead>
            <tbody>

            <tr>

                <td class="center"><a href="sale/_id">room_idx</a></td>
                <td>
                    <div class="sale_info_group gap-3">
                    <span class="label-round-secondary" >월세</span>
                    <p>빌라형<br>분리형 원룸<br>
                        보증금 1000 / 월세 50</p>
                    </div>
                </td>
                <td class="center">
                    서울특별시<br>
                    중구<br>
                    을지로동
                </td>
                <td class="center">
                    2022-12-27<br>
                    21:09:09
                </td>
                <td class="center">등록완료</td>
                <td class="center">101</td>
                <td class="center">22</td>
                <td class="center">7</td>
                <td class="center">
                    <a href="" class="btn btn-sm btn-outline-primary w-100 mb-2" >
                        <span class="text" >매물 이동</span>
                    </a>

                </td>
            </tr>
            <tr>

                <td class="center"><a href="sale/_id">room_idx</a></td>
                <td>
                    <div class="sale_info_group gap-3">
                    <span class="label-round-secondary" >월세</span>
                    <p>빌라형<br>분리형 원룸<br>
                        보증금 1000 / 월세 50</p>
                    </div>
                </td>
                <td class="center">
                    서울특별시<br>
                    중구<br>
                    을지로동
                </td>
                <td class="center">
                    2022-12-27<br>
                    21:09:09
                </td>
                <td class="center">등록완료</td>
                <td class="center">101</td>
                <td class="center">22</td>
                <td class="center">7</td>
                <td class="center">
                    <a href="" class="btn btn-sm btn-outline-primary w-100 mb-2" >
                        <span class="text" >매물 이동</span>
                    </a>

                </td>
            </tr>

            </tbody>
        </table>
    </div>
</div>

<!-- 매칭 정보 -->
<div class="card-header px-3 pt-4 pb-0 d-flex flex-row align-items-center justify-content-between  ">
    <h6 class="  mb-0 font-weight-bold">매칭활동 정보 총 <span class="text-primary">2</span>건</h6>

</div>
<div class="card-body">
    <div class="divTable2">
        <table class="table table-bordered" id="dataTable2" width="100%" cellspacing="0">
            <thead>
            <tr>
                <th class="center">주문번호</th>
                <th class="center">주문정보요약</th>
                <th class="center">등록자정보</th>
                <th class="center">주문자위치</th>
                <th class="center">등록일</th>
                <th class="center">주문상태</th>
                <th class="center">매칭상태</th>
                <th class="center w-10"></th>
            </tr>
            </thead>
            <tbody>

            <tr>
                <td class="center"><a href="sale/_id">order_idx</a></td>
                <td>
                    <div class="sale_info_group gap-3">
                    <span class="label-round-secondary" >월세</span>
                    <p>빌라형<br>분리형 원룸<br>
                        보증금 1000 / 월세 50</p>
                    </div>
                </td>
                <td class="center">
                    <a href="sale/_id">mem_idx</a><br>
                    <a href="sale/_id">mem_id</a><br>
                    <a href="sale/_id">mem_name</a>
                </td>
                <td class="center">
                    서울특별시<br>
                    중구<br>
                    을지로동
                </td>
                <td class="center">
                    2022-12-27<br>
                    21:09:09
                </td>
                <td class="center">매칭중</td>
                <td class="center">매칭요청</td>
                <td class="center">
                    <a href="" class="btn btn-sm btn-outline-primary w-100 mb-2" >
                        <span class="text" >주문 이동</span>
                    </a>

                </td>
            </tr>
            <tr>
                <td class="center"><a href="sale/_id">order_idx</a></td>
                <td>
                    <div class="sale_info_group gap-3">
                    <span class="label-round-secondary" >월세</span>
                    <p>빌라형<br>분리형 원룸<br>
                        보증금 1000 / 월세 50</p>
                    </div>
                </td>
                <td class="center">
                    <a href="sale/_id">mem_idx</a><br>
                    <a href="sale/_id">mem_id</a><br>
                    <a href="sale/_id">mem_name</a>
                </td>
                <td class="center">
                    서울특별시<br>
                    중구<br>
                    을지로동
                </td>
                <td class="center">
                    2022-12-27<br>
                    21:09:09
                </td>
                <td class="center">매칭중</td>
                <td class="center">매칭확인</td>
                <td class="center">
                    <a href="" class="btn btn-sm btn-outline-primary w-100 mb-2" >
                        <span class="text" >주문 이동</span>
                    </a>

                </td>
            </tr>
            <tr>
                <td class="center"><a href="sale/_id">order_idx</a></td>
                <td>
                    <div class="sale_info_group gap-3">
                    <span class="label-round-secondary" >월세</span>
                    <p>빌라형<br>분리형 원룸<br>
                        보증금 1000 / 월세 50</p>
                    </div>
                </td>
                <td class="center">
                    <a href="sale/_id">mem_idx</a><br>
                    <a href="sale/_id">mem_id</a><br>
                    <a href="sale/_id">mem_name</a>
                </td>
                <td class="center">
                    서울특별시<br>
                    중구<br>
                    을지로동
                </td>
                <td class="center">
                    2022-12-27<br>
                    21:09:09
                </td>
                <td class="center">취소</td>
                <td class="center">매칭취소</td>
                <td class="center">
                    <a href="" class="btn btn-sm btn-outline-primary w-100 mb-2" >
                        <span class="text" >주문 이동</span>
                    </a>

                </td>
            </tr>

            </tbody>
        </table>
    </div>
</div>
 
 
    <!-- 회원 주요정보 -->
    <div class="card-header px-3 pt-4 pb-0 d-flex flex-row align-items-center justify-content-between  ">
        <h6 class="  mb-0 font-weight-bold">회원 주요정보</h6>
        <b-button v-b-modal.modal-multi-1 variant="sm btn-primary btn-icon-split"><span class="material-symbols-outlined mr-2" >edit</span>회원정보수정</b-button>
 
    </div>
    <div class="card-body">
        <div class="divTable2">
            <table class="table table-bordered" id="dataTable2" width="100%" cellspacing="0">
                <thead>
                <tr>
                    <th class="center">회원번호</th>
                    <th class="center">이름</th>
                    <th class="center">닉네임</th>
                    <th class="center">회원 유형</th>
                    <th class="center">로그인 방식</th>
                    <th class="center">회원 ID</th>
                    <th class="center">휴대폰 번호</th>
                    <th class="center w-10">생년월일</th>
                </tr>
                </thead>
                <tbody>

                <tr>
                    <td class="center"><a href="#">mem_idx</a></td>
                    <td class="center">
                        권오희
                    </td>
                    <td class="center">
                        PETER
                    </td>
                    <td class="center">
                        중개사회원
                    </td>
                    <td class="center">
                        <img src="../../../../../assets/img/sns/naver-green-circle.png" class="w-20" alt="네이버"><p class="d-none">네이버</p>
                    </td>
                    <td class="center">tester04@gmail.com</td>
                    <td class="center">010-1234-5678</td>
                    <td class="center">
                        1980-08-08
                    </td>
                </tr>


                </tbody>
            </table>
        </div>
    </div>

    <div class="row px-4">
        <!-- 활동 정보 -->
        <div class="col-lg-4">
            <div class="card lg mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold">활동 정보</h6>

                </div>
                <div class="card-body">
                    <div class="divTable">
                        <div class="divTableBody">
                            <div class="divTableRow">
                                <div class="divTableCell divTableHead">회원가입일</div>
                                <div class="divTableCell">2022-12-20</div>
                            </div>
                            <div class="divTableRow">
                                <div class="divTableCell divTableHead">회원정보수정일</div>
                                <div class="divTableCell">2022-12-20</div>
                            </div>
                            <div class="divTableRow">
                                <div class=" divTableCell divTableHead">마지막 로그인일</div>
                                <div class="divTableCell">2022-12-20 HH:MM:SS</div>
                            </div>
                            <div class="divTableRow">
                                <div class=" divTableCell divTableHead">비밀번호 변경일</div>
                                <div class="divTableCell">2022-12-20 HH:MM:SS</div>
                            </div>
                            <div class="divTableRow">
                                <div class=" divTableCell divTableHead">회원 상태 (휴면여부)</div>
                                <div class="divTableCell">
                                    <b-form-select v-model="selected" :options="options"></b-form-select>
                                </div>
                            </div>
                            <div class="divTableRow">
                                <div class=" divTableCell divTableHead">회원 탈퇴가능여부</div>
                                <div class="divTableCell">
                                    <b-form-select v-model="selected2" :options="options2"></b-form-select>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- 동의 내역 -->
        <div class="col-lg-4">
            <div class="card lg mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold">동의 내역</h6>
                </div>
                <div class="card-body">
                    <div class="divTable">
                        <div class="divTableBody">
                            <div class="divTableRow">
                                <div class="divTableCell divTableHead">푸시 알림 동의</div>
                                <div class="divTableCell">
                                    <!-- switch -->
                                    <b-form-checkbox v-model="checked" name="check-button" switch>동의</b-form-checkbox>
                                </div>
                            </div>
                            <div class="divTableRow">
                                <div class="divTableCell divTableHead">야간(20시~24시)<br>알림 동의</div>
                                <div class="divTableCell">
                                    <!-- switch -->
                                    <b-form-checkbox v-model="checked" name="check-button" switch>동의</b-form-checkbox>
                                </div>
                            </div>
                            <div class="divTableRow">
                                <div class=" divTableCell divTableHead">마케팅(SMS)<br>알림 동의</div>
                                <div class="divTableCell">
                                    <!-- switch -->
                                    <b-form-checkbox v-model="checked" name="check-button" switch>동의</b-form-checkbox>
                                </div>
                            </div>
                            <div class="divTableRow">
                                <div class=" divTableCell divTableHead">마케팅(Email)<br>알림 동의</div>
                                <div class="divTableCell">
                                    <!-- switch -->
                                    <b-form-checkbox v-model="nonchecked" name="check-button" switch>비동의</b-form-checkbox>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- 캥거룸 이용내역 -->
        <div class="col-lg-4">


            <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold">캥거룸 이용내역</h6>
                </div>
                <div class="card-body">
                    <div class="divTable">
                        <div class="divTableBody">
                            <div class="divTableRow">
                                <div class="divTableCell divTableHead">등록한 매물 수</div>
                                <div class="divTableCell">0건</div>
                            </div>
                            <div class="divTableRow">
                                <div class="divTableCell divTableHead">방 주문 수</div>
                                <div class="divTableCell">1건</div>
                            </div>
                            <div class="divTableRow">
                                <div class=" divTableCell divTableHead">작성한 리뷰 수</div>
                                <div class="divTableCell">1건</div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- 관리자 메모 -->

    <div class="card-header px-3 pt-4 pb-0 d-flex flex-row align-items-center justify-content-between  ">
        <h6 class="  mb-0 font-weight-bold">관리자 메모</h6>
    </div>
    <div class="card-body" >
        <div class="input-group justify-content-between gap-3 col" >
            <span class="input-group-text" >비공개 메모</span>
                <div style="flex-grow:2">
                    <b-form-textarea
                    id="textarea"
                    v-model="text"
                    class="w-100"
                     placeholder="강거루 중개사가 담당하여 매물 관리하는 중"
                    rows="3"
                    max-rows="6"
                    ></b-form-textarea> 
                 </div>

            <b-button class="btn btn-lg btn-outline-secondary" type="button" id="button-addon2" >
                <span class="material-symbols-outlined" >edit</span>
            </b-button>
        </div>


        <p class="text-primary mt-3" >※관리자만 확인 가능한 메모입니다.</p>
    </div>


</div>
    </div>
</div>
</div>
    <!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
 

</div>
<!-- End of Content Wrapper -->

<!--정보수정 팝업-->
   <b-modal id="modal-multi-1"  title="회원 정보 수정" ok-only no-stackin
                             :header-bg-variant="headerBgVariant"
                            :header-text-variant="headerTextVariant"
                            :body-bg-variant="bodyBgVariant"
                            :body-text-variant="bodyTextVariant"
                            :footer-bg-variant="footerBgVariant"
                            :footer-text-variant="footerTextVariant">
                            <div class="card-body px-0 py-0">
                            <div class="divTable2 border-0">
                                <div class="divTableBody2">
                                     
                                    <div class="divTableRow2">
                                        <div class="divTableCell2 divTableHead2 w-30">프로필 이미지</div>
                                        <div class="divTableCell2">
                                                <b-form-group>
                                                    <b-form-file id="file-default"></b-form-file>
                                                </b-form-group>
                                        </div>
                                    </div>
                                    <div class="divTableRow2">
                                        <div class="divTableCell2 divTableHead2 w-30">회원 이름</div>
                                        <div class="divTableCell2">
                                                <span class="body1 mr-3">손흥민</span>
                                                <b-button variant="sm btn-outline-dark btn-icon-split">본인인증</b-button>
                                        </div>
                                    </div>
                                    <div class="divTableRow2">
                                        <div class=" divTableCell2 divTableHead2 w-30">휴대전화번호</div>
                                        <div class="divTableCell2">
                                                <p class="body1">010-2852-8248</p>
                                        </div>
                                    </div>
                                    <div class="divTableRow2">
                                        <div class=" divTableCell2 divTableHead2 w-30">생년월일</div>
                                        <div class="divTableCell2">
                                                <p class="body1">1992-07-08</p>
                                        </div>
                                    </div>
                                    <div class="divTableRow2">
                                        <div class=" divTableCell2 divTableHead2 w-30">닉네임</div>
                                        <div class="divTableCell2">
                                                <p class="body1">SON7 </p>
                                        </div>
                                    </div>
                                  
                                    <div class="divTableRow2">
                                        <div class=" divTableCell2 divTableHead2 w-30">비밀번호 변경</div>
                                        <div class="divTableCell2">
                                          <b-button v-b-modal.modal-multi-2 variant="sm btn-outline-dark btn-icon-split">변경하기</b-button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                             
                            </div>
                            <template #modal-footer>
                                <div class="w-100 align-items-center d-flex">
                                <b-button
                                    variant="primary btn-icon-split"
                                    size="lg"
                                    v-b-modal.modal-multi-4
                                >
                                <span class="material-symbols-outlined mr-3">edit</span>수정완료
                                </b-button>
                                </div>
                            </template>
    </b-modal>
                            <!--정보수정 팝업-->
                            
                            <!--비밀번호 변경 팝업-->
                            <b-modal id="modal-multi-2" title="비밀번호 변경" ok-only
                            :footer-bg-variant="footerBgVariant"
                            :footer-text-variant="footerTextVariant">
                            <div role="group" class="mb-4">
                                <label for="input-live">비밀번호 재설정</label>
                                <b-form-input
                                id="input-live"
                                v-model="name"
                                :state="nameState"
                                class="w-100"
                                aria-describedby="input-live-help input-live-feedback"
                                placeholder=""
                                trim
                                ></b-form-input>

                                <!-- This will only be shown if the preceding input has an invalid state -->
                                <b-form-invalid-feedback id="input-live-feedback">
                                Enter at least 3 letters
                                </b-form-invalid-feedback>

                            </div>
                            <div role="group" class="mb-4">
                                <label for="input-live">비밀번호 재설정 확인</label>
                                <b-form-input
                                id="input-live"
                                v-model="name"
                                :state="nameState"
                                class="w-100"
                                aria-describedby="input-live-help input-live-feedback"
                                placeholder=""
                                trim
                                ></b-form-input>

                                <!-- This will only be shown if the preceding input has an invalid state -->
                                <b-form-invalid-feedback id="input-live-feedback">
                                    비밀번호가 일치하지 않습니다.
                                </b-form-invalid-feedback>

                            </div>
                                 <template #modal-footer>
                                <div class="w-100 align-items-center d-flex gap-3">
                                    <b-button   
                                    variant="primary btn-icon-split"
                                    size="lg"
                                    v-b-modal.modal-multi-3                                    
                                >
                                변경완료
                                </b-button>
                                <b-button
                                    variant="light btn-icon-split mt-0"
                                    size="lg"
                                    block @click="$bvModal.hide('modal-multi-2')"
                                >
                                취소
                                </b-button>
                                </div>
                            </template>
                            </b-modal>

                            <!--비밀번호 변경 팝업-->
                            <!--비밀번호 변경 완료 팝업-->
                            <b-modal id="modal-multi-3" size="sm" title="변경 완료" ok-only>
                            <p class="my-1">비밀번호 변경이 완료되었습니다.</p>
                        </b-modal>
                            <!--비밀번호 변경 완료 팝업-->
                            <!--회원정보 수정 완료 팝업-->
                            <b-modal id="modal-multi-4" size="sm" title="수정 완료" ok-only>
                            <p class="my-1">회원정보가 수정되었습니다.</p>
                        </b-modal>
                            <!--회원정보 수정 완료 팝업-->


  </div>
</template>

<script>
export default {
    computed: {
      nameState() {
        return this.name.length > 2 ? true : false
      }
    },
  data() {
    return {
      nonchecked:false,
      checked: true,
      name: '',
      text: '',
      show: false,
      selected: 'a',
        options: [
          { value: 'a', text: '활성' },
          { value: 'b', text: '비활성' }
        ],
        selected2: 'c',
        options2: [
          { value: 'c', text: '탈퇴불가능' },
          { value: 'd', text: '탈퇴가능' }
        ]
    }
  }
}
</script>