<template>

  <div id="app">
 
  
<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

<!-- Main Content -->
<div id="content">
  

    <!-- Begin Page Content -->
    <div class="container-fluid">

<!-- Page Heading -->
<h1 class="h4 mb-4">매물 상세정보</h1>
<a href="../sale" class="btn btn-light btn-icon-split mb-4">
    <span class="material-symbols-outlined text-gray-600">keyboard_backspace</span>
    <span class="text">리스트로 돌아가기</span>
</a>


<div class="row">

    <div class="col-lg-12">

        <div class="card lg mb-4">
    <!-- 회원 주요정보 -->
    <div class="card-header px-3 pt-4 pb-0 d-flex flex-row align-items-center justify-content-between  ">
        <h6 class="  mb-0 font-weight-bold">매물 주요정보</h6>
        <b-button v-b-modal.modal-multi-1 variant="sm btn-primary btn-icon-split"><span class="material-symbols-outlined mr-2" >edit</span>매물정보확인</b-button>
 
    </div>
    <div class="card-body">
        <div class="divTable2">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                      <thead>
                        <tr>
                           
                          <th class="center">매물번호</th>
                          <th class="center">매물정보</th>
                           <th class="center">주소지</th>
                          <th class="center">등록일</th>
                          <th class="center">매물상태</th>
                          <th class="center">조회</th>
                          <th class="center">찜</th>
                          <th class="center">문의</th>
                          <th class="center" width="10%">상태변경</th>
                        </tr>
                      </thead>

                      <tbody>

                        <tr>
                           
                          <td class="center"><a href="sale/_id">room_idx</a></td>
                          <td>
                            <div class="sale_info_group gap-3">
                              <span class="label-round-secondary">월세</span>
                              <p>빌라형<br>분리형 원룸<br>보증금 1000 / 월세 50</p>
                            </div>
                          </td> 
                          <td class="center">
                            서울특별시<br>
                            중구<br>
                            을지로동
                          </td>
                          <td class="center">
                            <p>2022-12-27</p>
                            
                          </td>
                          <td class="center">등록완료</td>
                          <td class="center">101</td>
                          <td class="center">22</td>
                          <td class="center">7</td>
                          <td class="center">
                            <a href="" class="btn btn-sm btn-outline-primary w-100 mb-2">
                              <span class="text">수정</span>
                            </a>
                            <a href="" class="btn btn-sm btn-outline-secondary w-100 mb-2">
                              <span class="text">거래완료</span>
                            </a>
                            <a href="" class="btn btn-sm btn-outline-secondary w-100">
                              <span class="text">숨김처리</span>
                            </a>
                          </td>
                        </tr> 
                      </tbody>
                    </table>
        </div>
    </div>
 <!-- 등록자 상세정보 -->
 <div class="card-header px-3 pt-4 pb-0 d-flex flex-row align-items-center justify-content-between  ">
        <h6 class="  mb-0 font-weight-bold">등록자 상세정보</h6>
        
    </div>
    <div class="card-body">
        <div class="divTable2">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                      <thead>
                        <tr>
                           
                          <th class="center">이름</th>
                          <th class="center">닉네임</th>
                           <th class="center">회원 유형</th>
                          <th class="center">로그인방식</th>
                          <th class="center">회원 Email</th>
                          <th class="center">가입일</th>
                          <th></th>
                        </tr>
                      </thead>

                      <tbody>

                        <tr>
                           
                          <td class="center"><a href="sale/_id">이동욱</a></td>
                          <td class="center">
                            <p>황금</p>
                          </td> 
                          <td class="center">
                            <p>일반회원</p>
                          </td>
                          <td class="center">
                            <p>카카오</p>                            
                          </td>
                          <td class="center"><p>tester10@gmail.com</p></td>
                          <td class="center"><p>2022-12-20</p></td>
                          <td class="center">
                            <b-button v-b-modal.modal-multi-1 variant="sm btn-primary btn-icon-split"><span class="material-symbols-outlined mr-2" >edit</span>등록자정보확인</b-button>
                          </td>
                        </tr> 
                      </tbody>
                    </table>
        </div>
    </div>
 
     <!-- 매물 검수 (상태값 변경) 내역  -->
 <div class="card-header px-3 pt-4 pb-0 d-flex flex-row align-items-center justify-content-between  ">
        <h6 class="  mb-0 font-weight-bold">매물 검수 (상태값 변경) 내역</h6>
        
    </div>
    <div class="card-body">
        <div class="divTable2">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                      <thead>
                        <tr>
                           
                          <th class="center">번호</th>
                          <th class="center">매물상태</th>
                           <th class="center">처리일 시</th>
                          <th class="center">메모</th>  
                        </tr>
                      </thead>

                      <tbody>

                        <tr>                           
                          <td class="center">1</td>
                          <td class="center">
                            <p>승인대기</p>
                          </td> 
                          <td class="center">
                            <p>2022-12-27 10:19:50 </p>
                          </td>
                          <td class="center">
                            <p> <b-form-input v-model="text1" placeholder="" class="w-100"></b-form-input></p>                            
                          </td>                           
                        </tr> 
                        <tr>                           
                          <td class="center">2</td>
                          <td class="center">
                            <p>등록완료</p>
                          </td> 
                          <td class="center">
                            <p>2022-12-27 10:19:50 </p>
                          </td>
                          <td class="center">
                            <p> <b-form-input v-model="text2" placeholder="" class="w-100"></b-form-input></p>                            
                          </td>                           
                        </tr> 
                        <tr>                           
                          <td class="center">3</td>
                          <td class="center">
                            <p>거래완료</p>
                          </td> 
                          <td class="center">
                            <p>2022-12-27 10:19:50 </p>
                          </td>
                          <td class="center">
                            <p> <b-form-input v-model="text3" placeholder="" class="w-100"></b-form-input></p>                            
                          </td>                           
                        </tr> 
                        <tr>                           
                          <td class="center">4</td>
                          <td class="center">
                            <p>등록완료 </p>
                          </td> 
                          <td class="center">
                            <p>2022-12-27 10:19:50 </p>
                          </td>
                          <td class="center">
                            <p> <b-form-input v-model="text4" placeholder="" class="w-100"></b-form-input></p>                            
                          </td>                           
                        </tr> 
                      </tbody>
                    </table>
        </div>
    </div>



    <!-- 관리자 메모 -->

    <div class="card-header px-3 pt-4 pb-0 d-flex flex-row align-items-center justify-content-between  ">
        <h6 class="  mb-0 font-weight-bold">관리자 메모</h6>
    </div>
    <div class="card-body" >
        <div class="input-group justify-content-between gap-3 col" >
            <span class="input-group-text" >비공개 메모</span>
                <div style="flex-grow:2">
                    <b-form-textarea
                    id="textarea"
                    v-model="text5"
                    class="w-100"
                     placeholder=""
                    rows="3"
                    max-rows="6"
                    ></b-form-textarea> 
                 </div>

            <b-button class="btn btn-lg btn-outline-secondary" type="button" id="button-addon2" >
                <span class="material-symbols-outlined" >edit</span>
            </b-button>
        </div>


        <p class="text-primary mt-3" >※관리자만 확인 가능한 메모입니다.</p>
    </div>


</div>
    </div>
</div>
</div>
    <!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
 

</div>
<!-- End of Content Wrapper -->

<!--정보수정 팝업-->
   <b-modal id="modal-multi-1"  title="회원 정보 수정" ok-only no-stackin
                             :header-bg-variant="headerBgVariant"
                            :header-text-variant="headerTextVariant"
                            :body-bg-variant="bodyBgVariant"
                            :body-text-variant="bodyTextVariant"
                            :footer-bg-variant="footerBgVariant"
                            :footer-text-variant="footerTextVariant">
                            <div class="card-body px-0 py-0">
                            <div class="divTable2 border-0">
                                <div class="divTableBody2">
                                     
                                    <div class="divTableRow2">
                                        <div class="divTableCell2 divTableHead2 w-30">프로필 이미지</div>
                                        <div class="divTableCell2">
                                                <b-form-group>
                                                    <b-form-file id="file-default"></b-form-file>
                                                </b-form-group>
                                        </div>
                                    </div>
                                    <div class="divTableRow2">
                                        <div class="divTableCell2 divTableHead2 w-30">회원 이름</div>
                                        <div class="divTableCell2">
                                                <span class="body1 mr-3">손흥민</span>
                                                <b-button variant="sm btn-outline-dark btn-icon-split">본인인증</b-button>
                                        </div>
                                    </div>
                                    <div class="divTableRow2">
                                        <div class=" divTableCell2 divTableHead2">휴대전화번호</div>
                                        <div class="divTableCell2">
                                                <p class="body1">010-2852-8248</p>
                                        </div>
                                    </div>
                                    <div class="divTableRow2">
                                        <div class=" divTableCell2 divTableHead2 w-30">생년월일</div>
                                        <div class="divTableCell2">
                                                <p class="body1">1992-07-08</p>
                                        </div>
                                    </div>
                                    <div class="divTableRow2">
                                        <div class=" divTableCell2 divTableHead2 w-30">닉네임</div>
                                        <div class="divTableCell2">
                                                <p class="body1">SON7 </p>
                                        </div>
                                    </div>
                                  
                                    <div class="divTableRow2">
                                        <div class=" divTableCell2 divTableHead2 w-30">비밀번호 변경</div>
                                        <div class="divTableCell2">
                                          <b-button v-b-modal.modal-multi-2 variant="sm btn-outline-dark btn-icon-split">변경하기</b-button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                             
                            </div>
                            <template #modal-footer>
                                <div class="w-100 align-items-center d-flex">
                                <b-button
                                    variant="primary btn-icon-split"
                                    size="lg"
                                    v-b-modal.modal-multi-4
                                >
                                <span class="material-symbols-outlined mr-3">edit</span>수정완료
                                </b-button>
                                </div>
                            </template>
    </b-modal>
                            <!--정보수정 팝업-->
                            
                            <!--비밀번호 변경 팝업-->
                            <b-modal id="modal-multi-2" title="비밀번호 변경" ok-only
                            :footer-bg-variant="footerBgVariant"
                            :footer-text-variant="footerTextVariant">
                            <div role="group" class="mb-4">
                                <label for="input-live">비밀번호 재설정</label>
                                <b-form-input
                                id="input-live"
                                v-model="name"
                                :state="nameState"
                                class="w-100"
                                aria-describedby="input-live-help input-live-feedback"
                                placeholder=""
                                trim
                                ></b-form-input>

                                <!-- This will only be shown if the preceding input has an invalid state -->
                                <b-form-invalid-feedback id="input-live-feedback">
                                Enter at least 3 letters
                                </b-form-invalid-feedback>

                            </div>
                            <div role="group" class="mb-4">
                                <label for="input-live">비밀번호 재설정 확인</label>
                                <b-form-input
                                id="input-live"
                                v-model="name"
                                :state="nameState"
                                class="w-100"
                                aria-describedby="input-live-help input-live-feedback"
                                placeholder=""
                                trim
                                ></b-form-input>

                                <!-- This will only be shown if the preceding input has an invalid state -->
                                <b-form-invalid-feedback id="input-live-feedback">
                                    비밀번호가 일치하지 않습니다.
                                </b-form-invalid-feedback>

                            </div>
                                 <template #modal-footer>
                                <div class="w-100 align-items-center d-flex gap-3">
                                    <b-button   
                                    variant="primary btn-icon-split"
                                    size="lg"
                                    v-b-modal.modal-multi-3                                    
                                >
                                변경완료
                                </b-button>
                                <b-button
                                    variant="light btn-icon-split mt-0"
                                    size="lg"
                                    block @click="$bvModal.hide('modal-multi-2')"
                                >
                                취소
                                </b-button>
                                </div>
                            </template>
                            </b-modal>

                            <!--비밀번호 변경 팝업-->
                            <!--비밀번호 변경 완료 팝업-->
                            <b-modal id="modal-multi-3" size="sm" title="변경 완료" ok-only>
                            <p class="my-1">비밀번호 변경이 완료되었습니다.</p>
                        </b-modal>
                            <!--비밀번호 변경 완료 팝업-->
                            <!--회원정보 수정 완료 팝업-->
                            <b-modal id="modal-multi-4" size="sm" title="수정 완료" ok-only>
                            <p class="my-1">회원정보가 수정되었습니다.</p>
                        </b-modal>
                            <!--회원정보 수정 완료 팝업-->


  </div>
</template>

<script>
export default {
    computed: {
      nameState() {
        return this.name.length > 2 ? true : false
      }
    },
  data() {
    return {
      nonchecked:false,
      checked: true,
      name: '',
      text: '',
      text2: '강거루 중개사가 승인 처리',
      text3: '강거루 중개사가 중개',
      text4: '강거루 중개사가 재등록처리',
      text5: '강거루 중개사가 담당하여 매물 관리하는 중 ',
      show: false,
      selected: 'a',
        options: [
          { value: 'a', text: '활성' },
          { value: 'b', text: '비활성' }
        ],
        selected2: 'c',
        options2: [
          { value: 'c', text: '탈퇴불가능' },
          { value: 'd', text: '탈퇴가능' }
        ]
    }
  }
}
</script>