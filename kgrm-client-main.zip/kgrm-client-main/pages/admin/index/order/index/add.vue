<template>

  <div id="app">


    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">


        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h4 mb-4">매물 등록</h1>

          <div class="row">

            <div class="col-lg-12">
              <div class="card lg mb-4">
                <!-- 집 정보 -->
                <div class="card-header px-3 pt-4 pb-0 d-flex flex-row align-items-center justify-content-between  ">
                  <h6 class="  mb-0 font-weight-bold">집 정보</h6>

                </div>
                <div class="card-body">
                  <div class="divTable2">
                    <table class="table " id="dataTable2" width="100%" cellspacing="0">
                      <tbody>
                        <tr>
                          <th scope="row" class="w-10">집주소</th>
                          <td colspan="3">
                            <div class="input-group w-50">
                              <b-form-input v-model="text" placeholder=""></b-form-input>
                              <b-button variant="primary ml-2" type="button" id="button-addon2">주소 검색</b-button>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <th scope="row">주소지</th>
                          <td colspan="3">
                            <div class="input-group w-75 align-items-center">
                              <b-form-input v-model="text" placeholder="room_si_do" class="mr-3"></b-form-input>
                              <b-form-input v-model="text" placeholder="room_si_gun_gu" class="mr-3"></b-form-input>
                              <b-form-input v-model="text" placeholder="room_eup_myeon_dong"></b-form-input>
                              <span class="ml-4">(주소검색시, 자동완성) </span>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <th scope="row">상세주소</th>
                          <td colspan="3">
                            <div class="input-group w-50 ">
                              <b-form-input v-model="text" placeholder="상세주소입력"></b-form-input>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <th scope="row">준공년도</th>
                          <td>
                            <div class="input-group w-50 ">
                              <b-form-input v-model="text" placeholder="연도월일입력"></b-form-input>
                            </div>
                          </td>
                          <th scope="row">승인일자</th>
                          <td>
                            <div class="input-group w-50 ">
                              <b-form-input v-model="text" placeholder="연도월일입력"></b-form-input>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <th scope="row">대지면적</th>
                          <td>
                            <div class="input-group w-75 align-items-center">
                              <b-form-input v-model="text" placeholder="평수 입력"></b-form-input>
                              <span class="input-group-text fix-txt" id="basic-addon22">평</span>
                              <span class="material-symbols-outlined mr-3">sync</span>

                              <b-form-input v-model="text" placeholder=""></b-form-input>
                              <span class="input-group-text fix-txt" id="basic-addon23">㎡</span>
                            </div>
                          </td>
                          <th scope="row">연면적</th>
                          <td>
                            <div class="input-group  w-75 align-items-center">
                              <b-form-input v-model="text" placeholder="평수 입력"></b-form-input>
                              <span class="input-group-text fix-txt" id="basic-addon22">평</span>
                              <span class="material-symbols-outlined mr-3">sync</span>

                              <b-form-input v-model="text" placeholder=""></b-form-input>
                              <span class="input-group-text fix-txt" id="basic-addon23">㎡</span>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <th scope="row">건물 유형</th>
                          <td>
                            <b-form-select v-model="selected" :options="options"></b-form-select>
                          </td>
                          <th scope="row">집 형태</th>
                          <td>
                            <b-form-select v-model="selected2" :options="options2"></b-form-select>
                          </td>
                        </tr>
                        <tr>
                          <th scope="row">방 형태</th>
                          <td>
                            <b-form-select v-model="selected3" :options="options3"></b-form-select>
                          </td>
                          <th scope="row">방 평수</th>
                          <td>
                            <div class="input-group  w-75 align-items-center">
                              <b-form-input v-model="text" placeholder="평수 입력"></b-form-input>
                              <span class="input-group-text fix-txt" id="basic-addon22">평</span>
                              <span class="material-symbols-outlined mr-3">sync</span>

                              <input type="text" class="form-control " placeholder="" aria-label="Recipient's username"
                                aria-describedby="button-addon2">
                              <span class="input-group-text fix-txt" id="basic-addon23">㎡</span>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <th scope="row">대출 총액</th>
                          <td>
                            <div class="input-group  w-75 align-items-center">
                              <input type="text" class="form-control " placeholder="금액 입력"
                                aria-label="Recipient's username" aria-describedby="button-addon2">
                              <span class="input-group-text fix-txt" id="basic-addon22">원</span>
                            </div>
                          </td>
                          <th scope="row">보증금 총액</th>
                          <td>
                            <div class="input-group  w-75 align-items-center">
                              <input type="text" class="form-control " placeholder="금액 입력"
                                aria-label="Recipient's username" aria-describedby="button-addon2">
                              <span class="input-group-text fix-txt" id="basic-addon22">원</span>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <th scope="row">해당층 수</th>
                          <td>
                            <div class="d-flex w-75 align-items-center">
                              <b-form-select v-model="selected4" :options="options4"></b-form-select>
                              <span class="input-group-text fix-txt" id="basic-addon22">층</span>
                              <b-form-group  v-slot="{ ariaDescribedby }">
      <b-form-radio-group
        v-model="selected8"
        :options="options8"
        :aria-describedby="ariaDescribedby"
        name="radio-inline"
      ></b-form-radio-group>
    </b-form-group>
                            </div>
                          </td>
                          <th scope="row">전체층 수 </th>
                          <td>
                            <div class="d-flex w-75 align-items-center">
                              <b-form-select v-model="selected5" :options="options5"></b-form-select>
                              <span class="input-group-text fix-txt" id="basic-addon22">층</span>
                            </div>

                          </td>
                        </tr>
                        <tr>
                          <th scope="row">방 방향</th>
                          <td>
                            <div class="d-flex  w-75 align-items-center">
                              <b-form-select v-model="selected6" :options="options6"></b-form-select>
                              <span class="input-group-text fix-txt" id="basic-addon22">(창문기준)</span>
                            </div>
                          </td>
                          <th scope="row"> </th>
                          <td>

                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

                <!-- 임대 정보  -->
                <div class="card-header px-3 pt-4 pb-0 d-flex flex-row align-items-center justify-content-between  ">
                  <h6 class="  mb-0 font-weight-bold">임대 정보</h6>

                </div>
                <div class="card-body">
                  <div class="divTable2">
                    <table class="table " id="dataTable2" width="100%" cellspacing="0">
                      <tbody>
                        <tr>
                          <th scope="row" class="w-10">임대종류</th>
                          <td colspan="3">
                            <b-form-group  v-slot="{ ariaDescribedby }">
      <b-form-radio-group
        v-model="selected7"
        :options="options7"
        :aria-describedby="ariaDescribedby"
        name="radio-inline2"
      ></b-form-radio-group>
    </b-form-group>
                          </td>
                        </tr>

                        <tr>
                          <th scope="row">보증금</th>
                          <td width="42%">
                            <div class="input-group  w-50">
                              <b-form-input v-model="text" placeholder="보증금 입력" class="mr-1"></b-form-input>
                              <span class="input-group-text fix-txt" id="basic-addon22">만원</span>
                            </div>
                          </td>
                          <th scope="row">월차임</th>
                          <td>
                            <div class="input-group w-50 ">
                              <b-form-input v-model="text" placeholder="월차임 입력" class="mr-1"></b-form-input>
                              <span class="input-group-text fix-txt" id="basic-addon22">만원</span>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <th scope="row">관리비</th>
                          <td>
                            <div class="input-group ">
                              <b-form-input v-model="text" placeholder="관리비 입력" class="mr-1"></b-form-input>
                              <span class="input-group-text fix-txt" id="basic-addon22">만원</span>
                              <div class="form-check form-check-inline ml-2">
                                <b-form-checkbox
      id="checkbox-1"
      v-model="status"
      name="checkbox-1"
      value="accepted"
      unchecked-value="not_accepted"
    >
    관리비 없음
    </b-form-checkbox>
                              </div>
                            </div>
                          </td>
                          <th></th>
                          <td></td>
                        </tr>

                        <tr>
                          <th scope="row">관리비포함내역</th>
                          <td colspan="3">

                            <b-form-group
       v-slot="{ ariaDescribedby }"
    >
      <b-form-checkbox-group
        v-model="selected9"
        :options="options9"
        :aria-describedby="ariaDescribedby"
        buttons
        button-variant="outline-gray"
        name="buttons-2"
        class="gap-2"
      ></b-form-checkbox-group>
    </b-form-group>
 

                          </td>

                        </tr>
                        <tr>
                          <th scope="row">입주가능일</th>
                          <td>
                            <div class="input-group w-75">
                              <b-form-input v-model="text" placeholder="입주가능일 입력" class="mr-1"></b-form-input>
                              <div class="form-check form-check-inline ml-2">
                                <b-form-checkbox
      id="checkbox-2"
      v-model="status"
      name="checkbox-2"
      value="accepted"
      unchecked-value="not_accepted"
    >
    협의 가능
    </b-form-checkbox>
                              </div>
 
                            </div>
                          </td>
                          <th scope="row"></th>
                          <td>

                          </td>
                        </tr>


                      </tbody>
                    </table>
                  </div>
                </div>

                <!-- 옵션 정보  -->
                <div class="card-header px-3 pt-4 pb-0 d-flex flex-row align-items-center justify-content-between  ">
                  <h6 class="  mb-0 font-weight-bold">옵션 정보</h6>

                </div>
                <div class="card-body">
                  <div class="divTable2">
                    <table class="table " id="dataTable2" width="100%" cellspacing="0">
                      <tbody>
                        <tr>
                          <th scope="row" class="w-10">기본옵션</th>
                          <td colspan="3">
                            <div class="form-check form-check-inline">
                            <b-form-group
       v-slot="{ ariaDescribedby }"
    >
      <b-form-checkbox-group
        v-model="selected10"
        :options="options10"
        :aria-describedby="ariaDescribedby"
        name="flavour-1a"
      ></b-form-checkbox-group>
    </b-form-group>
 

                            <span>(4개 이상 체크시 풀옵션 적용)</span>
                            </div>

                          </td>
                        </tr>
                        <tr>
                          <th scope="row" class="w-10">기타시설</th>
                          <td width="42%">
                            <b-form-group
       v-slot="{ ariaDescribedby }"
    >
      <b-form-checkbox-group
        v-model="selected11"
        :options="options11"
        :aria-describedby="ariaDescribedby"
        name="flavour-1a"
      ></b-form-checkbox-group>
    </b-form-group>
 
                          </td>
                          <th scope="row" class="w-10">주차가능 대수</th>
                          <td>
                            <div class="input-group  w-50" style="user-select: auto;">
                              <b-form-input v-model="text" placeholder="0" class="mr-1"></b-form-input>
                              <span class="input-group-text fix-txt" id="basic-addon22"
                                style="user-select: auto;">대</span>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <th scope="row" class="w-10">도배</th>
                          <td colspan="3">
                            <b-form-radio-group
      v-model="selected12"
      :options="options12"
      class=""
      value-field="item"
      text-field="name"
      disabled-field="notEnabled"
    ></b-form-radio-group>
                          </td>
                        </tr>
                        <tr>
                          <th scope="row" class="w-10">장판</th>
                          <td colspan="3">
                            <b-form-radio-group
      v-model="selected13"
      :options="options13"
      class=""
      value-field="item"
      text-field="name"
      disabled-field="notEnabled"
    ></b-form-radio-group>
                          </td>
                        </tr>
                        <tr>
                          <th scope="row" class="w-10">반려동물</th>
                          <td>
                            <div>

                            <b-form-radio-group
      v-model="selected14"
      :options="options14"
      class=""
      value-field="item"
      text-field="name"
      disabled-field="notEnabled"
    ></b-form-radio-group>
  </div>              
    
    <b-form-group
       v-slot="{ ariaDescribedby }"
    >
      <b-form-checkbox-group
        v-model="selected16"
        :options="selected16"
        :aria-describedby="ariaDescribedby"
        buttons
        button-variant="outline-gray"
        name="buttons-2"
        class="gap-2"
      ></b-form-checkbox-group>
    </b-form-group> 
                          </td>
                          <th scope="row" class="w-10">반려동물관련 입력사항</th>
                          <td>
                            <div class="input-group w-75" style="user-select: auto;">
                              <b-form-input v-model="text" placeholder="0" class="mr-1"></b-form-input>

                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>


                <!-- 기타 정보 -->

                <div class="card-header px-3 pt-4 pb-0 d-flex flex-row align-items-center justify-content-between  ">
                  <h6 class="  mb-0 font-weight-bold">기타 정보</h6>
                </div>
                <div class="card-body">
                  <div class="divTable2">
                    <table class="table " id="dataTable2" width="100%" cellspacing="0">
                      <tbody>

                        <tr>
                          <th scope="row" class="w-10">대출</th>
                          <td colspan="3">
                            <b-form-radio-group
      v-model="selected15"
      :options="options15"
      class=""
      value-field="item"
      text-field="name"
      disabled-field="notEnabled"
    ></b-form-radio-group>
                          </td>
                        </tr>
                        <tr>
                          <th scope="row" class="w-10">대출관련 입력사항</th>
                          <td colspan="3">
                            <b-form-textarea
      id="textarea"
      v-model="text"
      placeholder="ex) 카카오 전세대출만 가능합니다"
      rows="3"
      max-rows="6"
      class="w-100"
    ></b-form-textarea>
 
                          </td>
                        </tr>
                         
                      </tbody>
                    </table>
                  </div>
                </div>

                <!-- 방 사진 -->

                <div class="card-header px-3 pt-4 pb-0 d-flex flex-row align-items-center justify-content-between  ">
                  <h6 class="  mb-0 font-weight-bold">방 사진</h6>
                </div>
                <div class="card-body">
                  <div class="divTable2">
                    <h6 class="mt-4">내놓을 집 사진을 등록해주세요.</h6>
                    <ul class="list-circle">
                      <li>최소 각 필수 이미지 4장을 등록하여야 등록이 가능합니다. (한 장당 10MB이내 필수)</li>
                      <li>필수 사진을 포함하여 최대 10장까지 등록이 가능합니다. (한 장당 10MB이내 필수)</li>
                      <li>첫번째 사진이 대표 이미지로 보여집니다.</li>
                      <li>매물과 관련없는 이미지, 홍보성 이미지, 워터마크 이미지는 등록하실 수 없습니다.</li>
                    </ul>


                    <div class="d-flex gap-3 ">
                      <div class="file-upload-wrap">
                        <div class="filebox preview-image">
                          <input class="upload-name" value="파일선택" disabled="disabled">
                          <label for="input-file1">
                            <span class="btn-upload import">
                              <img src="../../../../../assets/img/icon/upload.svg">
                              <span class="Subtitle1 upload-txt text-gray-600"><span>*</span>대표 사진 업로드</span>
                            </span>
                          </label>
                          <label for="input-file1"><input type="file" id="input-file1" class="upload-hidden"></label>
                        </div>
                        <div class="filebox preview-image">
                          <input class="upload-name" value="파일선택" disabled="disabled">
                          <label for="input-file2">
                            <span class="btn-upload import">
                              <img src="../../../../../assets/img/icon/upload.svg">
                              <span class="Subtitle1 upload-txt text-gray-600"><span>*</span>방 사진 업로드</span>
                            </span>
                          </label>
                          <label for="input-file2"><input type="file" id="input-file2" class="upload-hidden"></label>
                        </div>
                        <div class="filebox preview-image">
                          <input class="upload-name" value="파일선택" disabled="disabled">
                          <label for="input-file3">
                            <span class="btn-upload import">
                              <img src="../../../../../assets/img/icon/upload.svg">
                              <span class="Subtitle1 upload-txt text-gray-600"><span>*</span>현관 사진 업로드</span>
                            </span>
                          </label>
                          <label for="input-file3"><input type="file" id="input-file3" class="upload-hidden"></label>
                        </div>
                        <div class="filebox preview-image">
                          <input class="upload-name" value="파일선택" disabled="disabled">
                          <label for="input-file4">
                            <span class="btn-upload import">
                              <img src="../../../../../assets/img/icon/upload.svg">
                              <span class="Subtitle1 upload-txt text-gray-600"><span>*</span>화장실 사진 업로드</span>
                            </span>
                          </label>
                          <label for="input-file4"><input type="file" id="input-file4" class="upload-hidden"></label>
                        </div>

                        <div class="filebox preview-image">
                          <input class="upload-name" value="파일선택" disabled="disabled">
                          <label for="input-file5">
                            <span class="btn-upload">
                              <img src="../../../../../assets/img/icon/upload.svg">
                              <span class="Subtitle1 upload-txt text-gray-600">거실 사진 업로드</span>
                            </span>
                          </label>
                          <label for="input-file5"><input type="file" id="input-file5" class="upload-hidden"></label>
                        </div>
                        <div class="filebox preview-image">
                          <input class="upload-name" value="파일선택" disabled="disabled">
                          <label for="input-file6">
                            <span class="btn-upload">
                              <img src="../../../../../assets/img/icon/upload.svg">
                              <span class="Subtitle1 upload-txt text-gray-600">사진 업로드</span>
                            </span>
                          </label>
                          <label for="input-file6"><input type="file" id="input-file6" class="upload-hidden"></label>
                        </div>
                        <div class="filebox preview-image">
                          <input class="upload-name" value="파일선택" disabled="disabled">
                          <label for="input-file7">
                            <span class="btn-upload">
                              <img src="../../../../../assets/img/icon/upload.svg">
                              <span class="Subtitle1 upload-txt text-gray-600">사진 업로드</span>
                            </span>
                          </label>
                          <label for="input-file7"><input type="file" id="input-file7" class="upload-hidden"></label>
                        </div>
                        <div class="filebox preview-image">
                          <input class="upload-name" value="파일선택" disabled="disabled">
                          <label for="input-file8">
                            <span class="btn-upload">
                              <img src="../../../../../assets/img/icon/upload.svg">
                              <span class="Subtitle1 upload-txt text-gray-600">사진 업로드</span>
                            </span>
                          </label>
                          <label for="input-file8"><input type="file" id="input-file8" class="upload-hidden"></label>
                        </div>

                      </div>
                    </div>

                  </div>
                </div>

                <!-- 상세설명 -->

                <div class="card-header px-3 pt-4 pb-0 d-flex flex-row align-items-center justify-content-between  ">
                  <h6 class="  mb-0 font-weight-bold">상세설명</h6>
                </div>
                <div class="card-body">
                  <div class="divTable2">


                    <a href="#" class="btn btn-primary btn-icon-split btn-lg w-100 my-4">
                      <span class="material-symbols-outlined">edit</span>
                      <span class="text" style="user-select: auto;">매물등록완료</span>
                    </a>

                  </div>




                </div>

              </div>


            </div>
          </div>
          <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->


      </div>
      <!-- End of Content Wrapper -->

      <!--정보수정 팝업-->
      <b-modal id="modal-multi-1" title="회원 정보 수정" ok-only no-stackin :header-bg-variant="headerBgVariant"
        :header-text-variant="headerTextVariant" :body-bg-variant="bodyBgVariant" :body-text-variant="bodyTextVariant"
        :footer-bg-variant="footerBgVariant" :footer-text-variant="footerTextVariant">
        <div class="card-body px-0 py-0">
          <div class="divTable2 border-0">
            <div class="divTableBody2">

              <div class="divTableRow2">
                <div class="divTableCell2 divTableHead2 w-30">프로필 이미지</div>
                <div class="divTableCell2">
                  <b-form-group>
                    <b-form-file id="file-default"></b-form-file>
                  </b-form-group>
                </div>
              </div>
              <div class="divTableRow2">
                <div class="divTableCell2 divTableHead2 w-30">회원 이름</div>
                <div class="divTableCell2">
                  <span class="body1 mr-3">손흥민</span>
                  <b-button variant="sm btn-outline-dark btn-icon-split">본인인증</b-button>
                </div>
              </div>
              <div class="divTableRow2">
                <div class=" divTableCell2 divTableHead2">휴대전화번호</div>
                <div class="divTableCell2">
                  <p class="body1">010-2852-8248</p>
                </div>
              </div>
              <div class="divTableRow2">
                <div class=" divTableCell2 divTableHead2 w-30">생년월일</div>
                <div class="divTableCell2">
                  <p class="body1">1992-07-08</p>
                </div>
              </div>
              <div class="divTableRow2">
                <div class=" divTableCell2 divTableHead2 w-30">닉네임</div>
                <div class="divTableCell2">
                  <p class="body1">SON7 </p>
                </div>
              </div>

              <div class="divTableRow2">
                <div class=" divTableCell2 divTableHead2 w-30">비밀번호 변경</div>
                <div class="divTableCell2">
                  <b-button v-b-modal.modal-multi-2 variant="sm btn-outline-dark btn-icon-split">변경하기</b-button>
                </div>
              </div>

            </div>
          </div>

        </div>
        <template #modal-footer>
          <div class="w-100 align-items-center d-flex">
            <b-button variant="primary btn-icon-split" size="lg" v-b-modal.modal-multi-4>
              <span class="material-symbols-outlined mr-3">edit</span>수정완료
            </b-button>
          </div>
        </template>
      </b-modal>
      <!--정보수정 팝업-->

      <!--비밀번호 변경 팝업-->
      <b-modal id="modal-multi-2" title="비밀번호 변경" ok-only :footer-bg-variant="footerBgVariant"
        :footer-text-variant="footerTextVariant">
        <div role="group" class="mb-4">
          <label for="input-live">비밀번호 재설정</label>
          <b-form-input id="input-live" v-model="name" :state="nameState" class="w-100"
            aria-describedby="input-live-help input-live-feedback" placeholder="" trim></b-form-input>

          <!-- This will only be shown if the preceding input has an invalid state -->
          <b-form-invalid-feedback id="input-live-feedback">
            Enter at least 3 letters
          </b-form-invalid-feedback>

        </div>
        <div role="group" class="mb-4">
          <label for="input-live">비밀번호 재설정 확인</label>
          <b-form-input id="input-live" v-model="name" :state="nameState" class="w-100"
            aria-describedby="input-live-help input-live-feedback" placeholder="" trim></b-form-input>

          <!-- This will only be shown if the preceding input has an invalid state -->
          <b-form-invalid-feedback id="input-live-feedback">
            비밀번호가 일치하지 않습니다.
          </b-form-invalid-feedback>

        </div>
        <template #modal-footer>
          <div class="w-100 align-items-center d-flex gap-3">
            <b-button variant="primary btn-icon-split" size="lg" v-b-modal.modal-multi-3>
              변경완료
            </b-button>
            <b-button variant="light btn-icon-split mt-0" size="lg" block @click="$bvModal.hide('modal-multi-2')">
              취소
            </b-button>
          </div>
        </template>
      </b-modal>

      <!--비밀번호 변경 팝업-->
      <!--비밀번호 변경 완료 팝업-->
      <b-modal id="modal-multi-3" size="sm" title="변경 완료" ok-only>
        <p class="my-1">비밀번호 변경이 완료되었습니다.</p>
      </b-modal>
      <!--비밀번호 변경 완료 팝업-->
      <!--회원정보 수정 완료 팝업-->
      <b-modal id="modal-multi-4" size="sm" title="수정 완료" ok-only>
        <p class="my-1">회원정보가 수정되었습니다.</p>
      </b-modal>
      <!--회원정보 수정 완료 팝업-->


    </div>
  </div>
</template>

<script>
export default {
  computed: {
    nameState() {
      return this.name.length > 2 ? true : false
    }
  },
  data() {
    return {
      nonchecked: false,
      checked: true,
      name: '',
      text: '',
      text2: '강거루 중개사가 승인 처리',
      text3: '강거루 중개사가 중개',
      text4: '강거루 중개사가 재등록처리',
      text5: '강거루 중개사가 담당하여 매물 관리하는 중 ',
      show: false,
      selected: '선택',
      options: [
        { value: '선택', text: '선택' },
        { value: '단독주택', text: '단독주택' },
        { value: '공동주택', text: '공동주택' },
        { value: '제1종 근린생활 시설', text: '제1종 근린생활 시설' },
        { value: '제2종 근린생활 시설', text: '제2종 근린생활 시설' },
        { value: '문화 및 집회 시설', text: '문화 및 집회 시설' },
        { value: '종교 시설', text: '종교 시설' },
        { value: '판매 시설', text: '판매 시설' },
        { value: '운수 시설', text: '운수 시설' },
        { value: '의료 시설', text: '의료 시설' },
        { value: '교육연구 시설', text: '교육연구 시설' },
        { value: '노유자(노인 및 어린이) 시설', text: '노유자(노인 및 어린이) 시설' },
        { value: '수련 시설', text: '수련 시설' },
        { value: '운동 시설', text: '운동 시설' },
        { value: '업무 시설', text: '업무 시설' },
        { value: '숙박 시설', text: '숙박 시설' },
        { value: '위락 시설', text: '위락 시설' },
        { value: '공장', text: '공장' },
        { value: '창고 시설', text: '창고 시설' },
        { value: '위험물 저장 및 처리 시설', text: '위험물 저장 및 처리 시설' },
        { value: '자동자 관련 시설', text: '자동자 관련 시설' },
        { value: '동물 및 식물 관련 시설', text: '동물 및 식물 관련 시설' },
        { value: '자원순환 관련 시설', text: '자원순환 관련 시설' },
        { value: '교정 및 군사 시설', text: '교정 및 군사 시설' },
        { value: '방송통신 시설', text: '방송통신 시설' },
        { value: '발전 시설', text: '발전 시설' },
        { value: '묘지 관련 시설', text: '묘지 관련 시설' },
        { value: '관광 휴게 시설', text: '관광 휴게 시설' },
        { value: '장례 시설', text: '장례 시설' },
        { value: '야영장 시설', text: '야영장 시설' },
        { value: '미등기 건물', text: '미등기 건물' },
        { value: '그 밖에 토지의 정착물', text: '그 밖에 토지의 정착물' }
      ],
      selected2: '선택',
      options2: [
        { value: '선택', text: '선택' },
        { value: '빌라형', text: '빌라형' },
        { value: '오피스텔형', text: '오피스텔형' },
        { value: '단독형', text: '단독형' }
      ],
      selected3: '선택',
      options3: [
        { value: '선택', text: '선택' },
        { value: '오픈형 원룸', text: '오픈형 원룸' },
        { value: '분리형 원룸', text: '분리형 원룸' },
        { value: '복층형 원룸', text: '복층형 원룸' }
      ],
      selected4: '해당 층 선택',
      options4: [
        { value: '해당 층 선택', text: '해당 층 선택' },
        { value: '1층', text: '1층' },
        { value: '2층', text: '2층' },
        { value: '3층', text: '3층' },
        { value: '4층', text: '4층' },
        { value: '5층', text: '5층' },
        { value: '6층', text: '6층' },
        { value: '7층', text: '7층' },
        { value: '8층', text: '8층' },
        { value: '9층', text: '9층' },
        { value: '10층', text: '10층' },
        { value: '11층', text: '11층' },
        { value: '12층', text: '12층' },
        { value: '13층', text: '13층' },
        { value: '14층', text: '14층' },
        { value: '15층', text: '15층' },
        { value: '16층', text: '16층' },
        { value: '17층', text: '17층' },
        { value: '18층', text: '18층' },
        { value: '19층', text: '19층' },
        { value: '20층 이상', text: '20층 이상' } 
      ],
      selected5: '해당 층 선택',
      options5: [
      { value: '해당 층 선택', text: '해당 층 선택' },
        { value: '1층', text: '1층' },
        { value: '2층', text: '2층' },
        { value: '3층', text: '3층' },
        { value: '4층', text: '4층' },
        { value: '5층', text: '5층' },
        { value: '6층', text: '6층' },
        { value: '7층', text: '7층' },
        { value: '8층', text: '8층' },
        { value: '9층', text: '9층' },
        { value: '10층', text: '10층' },
        { value: '11층', text: '11층' },
        { value: '12층', text: '12층' },
        { value: '13층', text: '13층' },
        { value: '14층', text: '14층' },
        { value: '15층', text: '15층' },
        { value: '16층', text: '16층' },
        { value: '17층', text: '17층' },
        { value: '18층', text: '18층' },
        { value: '19층', text: '19층' },
        { value: '20층 이상', text: '20층 이상' } 
      ],
      selected6: '방향 선택',
      options6: [
        { value: '방향 선택', text: '방향 선택' },
        { value: '남향', text: '남향' },
        { value: '남동향', text: '남동향' },
        { value: '동향', text: '동향' },
        { value: '북동향', text: '북동향' },
        { value: '북향', text: '북향' },
        { value: '북서향', text: '북서향' },
        { value: '서향', text: '서향' },
        { value: '남서향', text: '남서향' }
      ],
      selected7: '월세',
        options7: [
          { text: '월세', value: '월세' },
          { text: '전세', value: '전세' }
        ],
        selected8: '',
        options8: [
          { text: '반지하', value: '반지하' },
          { text: '옥탑', value: '옥탑' }
        ],
        selected9: [], // Must be an array reference!
        options9: [
          { text: '수도', value: '수도' },
          { text: '전기', value: '전기' },
          { text: '가스', value: '가스' },
          { text: '공동비용', value: '공동비용' },
          { text: '주차비', value: '주차비' },
          { text: '정화조', value: '정화조' },
          { text: '계단청소', value: '계단청소' },
          { text: '인터넷', value: '인터넷' },
          { text: '유선티비', value: '유선티비' }
        ],
        selected10: [], // Must be an array reference!
        options10: [
          { text: '에어컨', value: '에어컨' },
          { text: '냉장고', value: '냉장고' },
          { text: '세탁기', value: '세탁기' },
          { text: '옷장', value: '옷장' },
          { text: '책상', value: '책상' },
          { text: '가스렌지', value: '가스렌지' },
          { text: '쿡탑', value: '쿡탑' },
          { text: '침대', value: '침대' },
          { text: '신발장', value: '신발장' }
        ],
        selected11: [], // Must be an array reference!
        options11: [
          { text: 'E / V', value: 'E / V' },
          { text: '베란다', value: '베란다' },
          { text: '창고', value: '창고' },
          { text: '주차', value: '주차' }
        ],
        selected12: '불가능',
        options12: [
          { item: '불가능', name: '불가능' },
          { item: '가능', name: '가능' }
        ],
        selected13: '불가능',
        options13: [
          { item: '불가능', name: '불가능' },
          { item: '가능', name: '가능' }
        ],
        selected14: '불가능',
        options14: [
          { item: '불가능', name: '불가능' },
          { item: '가능', name: '가능' }
        ],
        selected15: '불가능',
        options15: [
          { item: '불가능', name: '불가능' },
          { item: '가능', name: '가능' }
        ],
        selected16: [], // Must be an array reference!
        options16: [
          { text: '강아지', value: '강아지' },
          { text: '고양이', value: '고양이' },
          { text: '조류', value: '조류' },
          { text: '파충류', value: '파충류' },
          { text: '기타 협의', value: '기타 협의' }
        ]
    }
  }
}
</script>