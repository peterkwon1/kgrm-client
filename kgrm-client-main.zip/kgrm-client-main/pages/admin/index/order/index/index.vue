<template>

  <div id="app">


    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">


        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h4 mb-4 text-gray-800">방찾기 관리 - 주문 목록</h1>


          <!--Tab-->
          <b-tabs>
            <b-tab active>
              <template #title>
                <p class="text-md font-weight-bold text-gray-500 text-uppercase mb-1">
                  전체 주문</p>
                <h5 class="h5 mb-0 font-weight-bold text-gray-800">30 건</h5>
              </template>
              <!--tab content1 s-->
              <div>
              <!-- Search + Filter-->
              <div class="bg-white py-4 px-4 rounded mb-4 mt-4">
                <!--문의일-->
                <div class="d-flex gap-5 align-items-center pb-3">
                  <div class="admin-menu-title">
                    <h6 class="mb-0">문의일</h6>
                  </div>
                  <b-form-group v-slot="{ ariaDescribedby }">
                    <b-form-radio-group id="btn-radios-1" v-model="selected4" :options="options4"
                      :aria-describedby="ariaDescribedby" button-variant="outline-gray" class="h-48"
                      name="radios-btn-default" buttons></b-form-radio-group>
                  </b-form-group>
                  <div class="d-flex align-items-center gap-3">
                    <b-form-datepicker v-model="value" :min="min" :max="max" locale="kr"></b-form-datepicker>
                    <span>~</span>
                    <b-form-datepicker v-model="value" :min="min" :max="max" locale="kr"></b-form-datepicker>
                  </div>


                </div>

                <div class="d-flex gap-4 pb-4">
                  <!--등록자정보-->
                  <div class="d-flex gap-5 flex-basis-50 align-items-center">
                    <div class="admin-menu-title">
                      <h6 class="mb-0">등록자정보</h6>
                    </div>
                    <b-form-select v-model="selected2" :options="options2" class="w-20"></b-form-select>
                    <div class="input-group ">
                      <b-form-input v-model="text" placeholder="검색 입력"></b-form-input>
                    </div>
                  </div>

                  <!--거래유형-->
                  <div class="d-flex gap-5 flex-basis-50 align-items-center">
                    <div class="admin-menu-title">
                      <h6 class="mb-0">거래유형</h6>
                    </div>
                    <b-form-select v-model="selected3" :options="options3" class="w-20"></b-form-select>

                  </div>
                </div>
                <!--주문번호-->
                <div class="d-flex gap-5 align-items-center">
                  <div class="admin-menu-title">
                    <h6 class="mb-0">주문번호</h6>
                  </div>
                  <div class="input-group w-20">
                    <b-form-input v-model="text" placeholder="검색 입력"></b-form-input>
                  </div>
                </div>

                <!-- button-->

                <div class="d-flex justify-content-center gap-4">
                  <a href="#" class="btn btn-primary w-10">
                    <span class="text">조회</span>
                  </a>
                  <a href="#" class="btn btn-light w-10">
                    <span class="text">초기화</span>
                  </a>

                </div>
              </div>
              <!-- search+filter end--> 
              <!-- table -->
              <div class="card shadow mb-4">

                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                      <thead>
                        <tr>
                           
                          <th class="center">주문번호</th>
                          <th class="center">주문정보요약</th>
                          <th class="center">등록자정보</th>
                          <th class="center">주문자위치</th>
                          <th class="center">등록일</th>
                          <th class="center">주문상태</th>
                          <th class="center">중개사 조회 수</th>
                          <th class="center">상태변경</th>
                        </tr>
                      </thead>

                      <tbody>

                        <tr>
                          
                          <td class="center"><a href="sale/_id">order_idx</a></td>
                          <td>
                            <div class="sale_info_group gap-3">
                              <span class="label-round-secondary">월세</span>
                              <p>보증금 1000<br>월세 50</p>
                            </div>
                          </td>
                          <td class="center">
                            <a href="sale/_id">mem_idx</a><br>
                            <a href="sale/_id">mem_id</a><br>
                            <a href="sale/_id">mem_name</a>
                          </td>
                          <td class="center">
                            서울특별시<br>
                            중구<br>
                            을지로동
                          </td>
                          <td class="center">
                            <p>2022-12-27</p><p>21:09:09</p>
                            
                          </td>
                          <td class="center">등록대기</td>
                          <td class="center">-</td>
                          <td class="center">
                            <a href="" class="btn btn-sm btn-outline-primary">
                              <span class="text">승인처리</span>
                            </a>
                            <a href="" class="btn btn-sm btn-outline-secondary">
                              <span class="text">주문취소</span>
                            </a>
                          </td>
                        </tr>
                        <tr>
                           
                          <td class="center"><a href="sale/_id">order_idx</a></td>
                          <td>
                            <div class="sale_info_group gap-3">
                              <span class="label-round-secondary">월세</span>
                              <p>보증금 1000<br>월세 50</p>
                            </div>
                          </td>
                          <td class="center">
                            <a href="sale/_id">mem_idx</a><br>
                            <a href="sale/_id">mem_id</a><br>
                            <a href="sale/_id">mem_name</a>
                          </td>
                          <td class="center">
                            서울특별시<br>
                            중구<br>
                            을지로동
                          </td>
                          <td class="center">
                            <p>2022-12-27</p><p>21:09:09</p>
                            
                          </td>
                          <td class="center">매칭중</td>
                          <td class="center">10</td>
                          <td class="center">
                            <a href="" class="btn btn-sm btn-outline-primary">
                              <span class="text">매칭현황</span>
                            </a>
                            <a href="" class="btn btn-sm btn-outline-secondary">
                              <span class="text">매칭취소</span>
                            </a>
                          </td>
                        </tr>
                        <tr>
                           
                          <td class="center"><a href="sale/_id">order_idx</a></td>
                          <td>
                            <div class="sale_info_group gap-3">
                              <span class="label-round-secondary">월세</span>
                              <p>보증금 1000<br>월세 50</p>
                            </div>
                          </td>
                          <td class="center">
                            <a href="sale/_id">mem_idx</a><br>
                            <a href="sale/_id">mem_id</a><br>
                            <a href="sale/_id">mem_name</a>
                          </td>
                          <td class="center">
                            서울특별시<br>
                            중구<br>
                            을지로동
                          </td>
                          <td class="center">
                            <p>2022-12-27</p><p>21:09:09</p>
                            
                          </td>
                          <td class="center">매칭확인</td>
                          <td class="center">10</td>
                          <td class="center">
                            <a href="" class="btn btn-sm btn-outline-primary">
                              <span class="text">매칭현황</span>
                            </a>
                            <a href="" class="btn btn-sm btn-outline-secondary">
                              <span class="text">리뷰현황</span>
                            </a>
                          </td>
                        </tr>
                        <tr>
                           
                          <td class="center"><a href="sale/_id">order_idx</a></td>
                          <td>
                            <div class="sale_info_group gap-3">
                              <span class="label-round-secondary">월세</span>
                              <p>보증금 1000<br>월세 50</p>
                            </div>
                          </td>
                          <td class="center">
                            <a href="sale/_id">mem_idx</a><br>
                            <a href="sale/_id">mem_id</a><br>
                            <a href="sale/_id">mem_name</a>
                          </td>
                          <td class="center">
                            서울특별시<br>
                            중구<br>
                            을지로동
                          </td>
                          <td class="center">
                            <p>2022-12-27</p><p>21:09:09</p>
                            
                          </td>
                          <td class="center">취소</td>
                          <td class="center">-</td>
                          <td class="center">
                            <a href="" class="btn btn-sm btn-outline-success">
                              <span class="text">재등록</span>
                            </a> 
                          </td>
                        </tr>
                        <tr>
                           
                          <td class="center"><a href="sale/_id">order_idx</a></td>
                          <td>
                            <div class="sale_info_group gap-3">
                              <span class="label-round-secondary">월세</span>
                              <p>보증금 1000<br>월세 50</p>
                            </div>
                          </td>
                          <td class="center">
                            <a href="sale/_id">mem_idx</a><br>
                            <a href="sale/_id">mem_id</a><br>
                            <a href="sale/_id">mem_name</a>
                          </td>
                          <td class="center">
                            서울특별시<br>
                            중구<br>
                            을지로동
                          </td>
                          <td class="center">
                            <p>2022-12-27</p><p>21:09:09</p>
                            
                          </td>
                          <td class="center">신고접수</td>
                          <td class="center">10</td>
                          <td class="center">
                            <a href="" class="btn btn-sm btn-outline-danger">
                              <span class="text">신고확인</span>
                            </a> 
                          </td>
                        </tr>

                      </tbody>
                    </table>
                  </div>
                </div>
                <div class="mx-auto overflow-auto">
                  <b-pagination-nav :link-gen="linkGen" :number-of-pages="10" use-router
                    class="my-4"></b-pagination-nav>
                </div>
              </div>
            </div>
            <!--tab content1 e-->
            </b-tab>
            <b-tab>
              <template #title>
                <p class="text-md font-weight-bold text-gray-500 text-uppercase mb-1">
                  작성주문 승인대기</p>
                <h5 class="h5 mb-0 font-weight-bold text-gray-800">10 건</h5>
              </template>
              <!--tab content2 s-->
              <div>
              <!-- Search + Filter-->
              <div class="bg-white py-4 px-4 rounded mb-4 mt-4">
                <!--문의일-->
                <div class="d-flex gap-5 align-items-center pb-3">
                  <div class="admin-menu-title">
                    <h6 class="mb-0">문의일</h6>
                  </div>
                  <b-form-group v-slot="{ ariaDescribedby }">
                    <b-form-radio-group id="btn-radios-1" v-model="selected4" :options="options4"
                      :aria-describedby="ariaDescribedby" button-variant="outline-gray" class="h-48"
                      name="radios-btn-default" buttons></b-form-radio-group>
                  </b-form-group>
                  <div class="d-flex align-items-center gap-3">
                    <b-form-datepicker v-model="value" :min="min" :max="max" locale="kr"></b-form-datepicker>
                    <span>~</span>
                    <b-form-datepicker v-model="value" :min="min" :max="max" locale="kr"></b-form-datepicker>
                  </div>


                </div>

                <div class="d-flex gap-4 pb-4">
                  <!--등록자정보-->
                  <div class="d-flex gap-5 flex-basis-50 align-items-center">
                    <div class="admin-menu-title">
                      <h6 class="mb-0">등록자정보</h6>
                    </div>
                    <b-form-select v-model="selected2" :options="options2" class="w-20"></b-form-select>
                    <div class="input-group ">
                      <b-form-input v-model="text" placeholder="검색 입력"></b-form-input>
                    </div>
                  </div>

                  <!--거래유형-->
                  <div class="d-flex gap-5 flex-basis-50 align-items-center">
                    <div class="admin-menu-title">
                      <h6 class="mb-0">거래유형</h6>
                    </div>
                    <b-form-select v-model="selected3" :options="options3" class="w-20"></b-form-select>

                  </div>
                </div>
                <!--주문번호-->
                <div class="d-flex gap-5 align-items-center">
                  <div class="admin-menu-title">
                    <h6 class="mb-0">주문번호</h6>
                  </div>
                  <div class="input-group w-20">
                    <b-form-input v-model="text" placeholder="검색 입력"></b-form-input>
                  </div>
                </div>

                <!-- button-->

                <div class="d-flex justify-content-center gap-4">
                  <a href="#" class="btn btn-primary w-10">
                    <span class="text">조회</span>
                  </a>
                  <a href="#" class="btn btn-light w-10">
                    <span class="text">초기화</span>
                  </a>

                </div>
              </div>
              <!-- search+filter end-->
              <div class="mb-4 gap-4 d-flex justify-content-start">
                <a href="#" class="btn btn-primary">
                  <span class="text">체크된 주문 등록승인처리</span>
                </a>
                <a href="" class="btn btn-outline-secondary">
                  <span class="text">체크된 주문 등록취소처리</span>
                </a>
              </div>
              <!-- table -->
              <div class="card shadow mb-4">

                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                      <thead>
                        <tr>
                          <th class="center">
                            <b-form-checkbox id="checkbox-1" v-model="status" name="checkbox-1" value="accepted"
                              unchecked-value="not_accepted">
                            </b-form-checkbox>
                          </th>
                          <th class="center">주문번호</th>
                          <th class="center">주문정보요약</th>
                          <th class="center">등록자정보</th>
                          <th class="center">주문자위치</th>
                          <th class="center">등록일</th>
                          <th class="center">주문상태</th>
                          <th class="center">중개사 조회 수</th>
                          <th class="center">상태변경</th>
                        </tr>
                      </thead>

                      <tbody>

                        <tr>
                          <td class="center">
                            <b-form-checkbox id="checkbox-1" v-model="status" name="checkbox-1" value="accepted"
                              unchecked-value="not_accepted">
                            </b-form-checkbox>
                          </td>
                          <td class="center"><a href="sale/_id">order_idx</a></td>
                          <td>
                            <div class="sale_info_group gap-3">
                              <span class="label-round-secondary">월세</span>
                              <p>보증금 1000<br>월세 50</p>
                            </div>
                          </td>
                          <td class="center">
                            <a href="sale/_id">mem_idx</a><br>
                            <a href="sale/_id">mem_id</a><br>
                            <a href="sale/_id">mem_name</a>
                          </td>
                          <td class="center">
                            서울특별시<br>
                            중구<br>
                            을지로동
                          </td>
                          <td class="center">
                            <p>2022-12-27</p><p>21:09:09</p>
                            
                          </td>
                          <td class="center">등록대기</td>
                          <td class="center">-</td>
                          <td class="center">
                            <a href="" class="btn btn-sm btn-outline-primary">
                              <span class="text">승인처리</span>
                            </a>
                            <a href="" class="btn btn-sm btn-outline-secondary">
                              <span class="text">주문취소</span>
                            </a>
                          </td>
                        </tr>
                        <tr>
                          <td class="center">
                            <b-form-checkbox id="checkbox-1" v-model="status" name="checkbox-1" value="accepted"
                              unchecked-value="not_accepted">
                            </b-form-checkbox>
                          </td>
                          <td class="center"><a href="sale/_id">order_idx</a></td>
                          <td>
                            <div class="sale_info_group gap-3">
                              <span class="label-round-secondary">월세</span>
                              <p>보증금 1000<br>월세 50</p>
                            </div>
                          </td>
                          <td class="center">
                            <a href="sale/_id">mem_idx</a><br>
                            <a href="sale/_id">mem_id</a><br>
                            <a href="sale/_id">mem_name</a>
                          </td>
                          <td class="center">
                            서울특별시<br>
                            중구<br>
                            을지로동
                          </td>
                          <td class="center">
                            <p>2022-12-27</p><p>21:09:09</p>
                            
                          </td>
                          <td class="center">등록대기</td>
                          <td class="center">-</td>
                          <td class="center">
                            <a href="" class="btn btn-sm btn-outline-primary">
                              <span class="text">승인처리</span>
                            </a>
                            <a href="" class="btn btn-sm btn-outline-secondary">
                              <span class="text">주문취소</span>
                            </a>
                          </td>
                        </tr>
                        <tr>
                          <td class="center">
                            <b-form-checkbox id="checkbox-1" v-model="status" name="checkbox-1" value="accepted"
                              unchecked-value="not_accepted">
                            </b-form-checkbox>
                          </td>
                          <td class="center"><a href="sale/_id">order_idx</a></td>
                          <td>
                            <div class="sale_info_group gap-3">
                              <span class="label-round-secondary">월세</span>
                              <p>보증금 1000<br>월세 50</p>
                            </div>
                          </td>
                          <td class="center">
                            <a href="sale/_id">mem_idx</a><br>
                            <a href="sale/_id">mem_id</a><br>
                            <a href="sale/_id">mem_name</a>
                          </td>
                          <td class="center">
                            서울특별시<br>
                            중구<br>
                            을지로동
                          </td>
                          <td class="center">
                            <p>2022-12-27</p><p>21:09:09</p>
                            
                          </td>
                          <td class="center">등록대기</td>
                          <td class="center">-</td>
                          <td class="center">
                            <a href="" class="btn btn-sm btn-outline-primary">
                              <span class="text">승인처리</span>
                            </a>
                            <a href="" class="btn btn-sm btn-outline-secondary">
                              <span class="text">주문취소</span>
                            </a>
                          </td>
                        </tr>
                        <tr>
                          <td class="center">
                            <b-form-checkbox id="checkbox-1" v-model="status" name="checkbox-1" value="accepted"
                              unchecked-value="not_accepted">
                            </b-form-checkbox>
                          </td>
                          <td class="center"><a href="sale/_id">order_idx</a></td>
                          <td>
                            <div class="sale_info_group gap-3">
                              <span class="label-round-secondary">월세</span>
                              <p>보증금 1000<br>월세 50</p>
                            </div>
                          </td>
                          <td class="center">
                            <a href="sale/_id">mem_idx</a><br>
                            <a href="sale/_id">mem_id</a><br>
                            <a href="sale/_id">mem_name</a>
                          </td>
                          <td class="center">
                            서울특별시<br>
                            중구<br>
                            을지로동
                          </td>
                          <td class="center">
                            <p>2022-12-27</p><p>21:09:09</p>
                            
                          </td>
                          <td class="center">등록대기</td>
                          <td class="center">-</td>
                          <td class="center">
                            <a href="" class="btn btn-sm btn-outline-primary">
                              <span class="text">승인처리</span>
                            </a>
                            <a href="" class="btn btn-sm btn-outline-secondary">
                              <span class="text">주문취소</span>
                            </a>
                          </td>
                        </tr>
                        <tr>
                          <td class="center">
                            <b-form-checkbox id="checkbox-1" v-model="status" name="checkbox-1" value="accepted"
                              unchecked-value="not_accepted">
                            </b-form-checkbox>
                          </td>
                          <td class="center"><a href="sale/_id">order_idx</a></td>
                          <td>
                            <div class="sale_info_group gap-3">
                              <span class="label-round-secondary">월세</span>
                              <p>보증금 1000<br>월세 50</p>
                            </div>
                          </td>
                          <td class="center">
                            <a href="sale/_id">mem_idx</a><br>
                            <a href="sale/_id">mem_id</a><br>
                            <a href="sale/_id">mem_name</a>
                          </td>
                          <td class="center">
                            서울특별시<br>
                            중구<br>
                            을지로동
                          </td>
                          <td class="center">
                            <p>2022-12-27</p><p>21:09:09</p>
                            
                          </td>
                          <td class="center">등록대기</td>
                          <td class="center">-</td>
                          <td class="center">
                            <a href="" class="btn btn-sm btn-outline-primary">
                              <span class="text">승인처리</span>
                            </a>
                            <a href="" class="btn btn-sm btn-outline-secondary">
                              <span class="text">주문취소</span>
                            </a>
                          </td>
                        </tr>
                        <tr>
                          <td class="center">
                            <b-form-checkbox id="checkbox-1" v-model="status" name="checkbox-1" value="accepted"
                              unchecked-value="not_accepted">
                            </b-form-checkbox>
                          </td>
                          <td class="center"><a href="sale/_id">order_idx</a></td>
                          <td>
                            <div class="sale_info_group gap-3">
                              <span class="label-round-secondary">월세</span>
                              <p>보증금 1000<br>월세 50</p>
                            </div>
                          </td>
                          <td class="center">
                            <a href="sale/_id">mem_idx</a><br>
                            <a href="sale/_id">mem_id</a><br>
                            <a href="sale/_id">mem_name</a>
                          </td>
                          <td class="center">
                            서울특별시<br>
                            중구<br>
                            을지로동
                          </td>
                          <td class="center">
                            <p>2022-12-27</p><p>21:09:09</p>
                            
                          </td>
                          <td class="center">등록대기</td>
                          <td class="center">-</td>
                          <td class="center">
                            <a href="" class="btn btn-sm btn-outline-primary">
                              <span class="text">승인처리</span>
                            </a>
                            <a href="" class="btn btn-sm btn-outline-secondary">
                              <span class="text">주문취소</span>
                            </a>
                          </td>
                        </tr>
                        <tr>
                          <td class="center">
                            <b-form-checkbox id="checkbox-1" v-model="status" name="checkbox-1" value="accepted"
                              unchecked-value="not_accepted">
                            </b-form-checkbox>
                          </td>
                          <td class="center"><a href="sale/_id">order_idx</a></td>
                          <td>
                            <div class="sale_info_group gap-3">
                              <span class="label-round-secondary">월세</span>
                              <p>보증금 1000<br>월세 50</p>
                            </div>
                          </td>
                          <td class="center">
                            <a href="sale/_id">mem_idx</a><br>
                            <a href="sale/_id">mem_id</a><br>
                            <a href="sale/_id">mem_name</a>
                          </td>
                          <td class="center">
                            서울특별시<br>
                            중구<br>
                            을지로동
                          </td>
                          <td class="center">
                            <p>2022-12-27</p><p>21:09:09</p>
                            
                          </td>
                          <td class="center">등록대기</td>
                          <td class="center">-</td>
                          <td class="center">
                            <a href="" class="btn btn-sm btn-outline-primary">
                              <span class="text">승인처리</span>
                            </a>
                            <a href="" class="btn btn-sm btn-outline-secondary">
                              <span class="text">주문취소</span>
                            </a>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
                <div class="mx-auto overflow-auto">
                  <b-pagination-nav :link-gen="linkGen" :number-of-pages="10" use-router
                    class="my-4"></b-pagination-nav>
                </div>
              </div>
            </div>
            <!--tab content2 e-->
            </b-tab>
            <b-tab>
              <template #title>
                <p class="text-md font-weight-bold text-gray-500 text-uppercase mb-1">
                  매칭 중</p>
                <h5 class="h5 mb-0 font-weight-bold text-gray-800">10 건</h5>
              </template>
              <!--tab content3 s-->
              <div>
              <!-- Search + Filter-->
              <div class="bg-white py-4 px-4 rounded mb-4 mt-4">
                <!--문의일-->
                <div class="d-flex gap-5 align-items-center pb-3">
                  <div class="admin-menu-title">
                    <h6 class="mb-0">문의일</h6>
                  </div>
                  <b-form-group v-slot="{ ariaDescribedby }">
                    <b-form-radio-group id="btn-radios-1" v-model="selected4" :options="options4"
                      :aria-describedby="ariaDescribedby" button-variant="outline-gray" class="h-48"
                      name="radios-btn-default" buttons></b-form-radio-group>
                  </b-form-group>
                  <div class="d-flex align-items-center gap-3">
                    <b-form-datepicker v-model="value" :min="min" :max="max" locale="kr"></b-form-datepicker>
                    <span>~</span>
                    <b-form-datepicker v-model="value" :min="min" :max="max" locale="kr"></b-form-datepicker>
                  </div>


                </div>

                <div class="d-flex gap-4 pb-4">
                  <!--등록자정보-->
                  <div class="d-flex gap-5 flex-basis-50 align-items-center">
                    <div class="admin-menu-title">
                      <h6 class="mb-0">등록자정보</h6>
                    </div>
                    <b-form-select v-model="selected2" :options="options2" class="w-20"></b-form-select>
                    <div class="input-group ">
                      <b-form-input v-model="text" placeholder="검색 입력"></b-form-input>
                    </div>
                  </div>

                  <!--거래유형-->
                  <div class="d-flex gap-5 flex-basis-50 align-items-center">
                    <div class="admin-menu-title">
                      <h6 class="mb-0">거래유형</h6>
                    </div>
                    <b-form-select v-model="selected3" :options="options3" class="w-20"></b-form-select>

                  </div>
                </div>
                <!--주문번호-->
                <div class="d-flex gap-5 align-items-center">
                  <div class="admin-menu-title">
                    <h6 class="mb-0">주문번호</h6>
                  </div>
                  <div class="input-group w-20">
                    <b-form-input v-model="text" placeholder="검색 입력"></b-form-input>
                  </div>
                </div>

                <!-- button-->

                <div class="d-flex justify-content-center gap-4">
                  <a href="#" class="btn btn-primary w-10">
                    <span class="text">조회</span>
                  </a>
                  <a href="#" class="btn btn-light w-10">
                    <span class="text">초기화</span>
                  </a>

                </div>
              </div>
              <!-- search+filter end-->
              <div class="mb-4 gap-4 d-flex justify-content-start">
                <a href="" class="btn btn-outline-secondary">
                  <span class="text">체크된 주문/매칭 취소처리</span>
                </a>
              </div>
              <!-- table -->
              <div class="card shadow mb-4">

                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                      <thead>
                        <tr>
                          <th class="center">
                            <b-form-checkbox id="checkbox-1" v-model="status" name="checkbox-1" value="accepted"
                              unchecked-value="not_accepted">
                            </b-form-checkbox>
                          </th>
                          <th class="center">주문번호</th>
                          <th class="center">주문정보요약</th>
                          <th class="center">등록자정보</th>
                          <th class="center">주문자위치</th>
                          <th class="center">등록일</th>
                          <th class="center">주문상태</th>
                          <th class="center">중개사 조회 수</th>
                          <th class="center" width="10%">상태변경</th>
                        </tr>
                      </thead>

                      <tbody>

                        <tr>
                          <td class="center">
                            <b-form-checkbox id="checkbox-1" v-model="status" name="checkbox-1" value="accepted"
                              unchecked-value="not_accepted">
                            </b-form-checkbox>
                          </td>
                          <td class="center"><a href="sale/_id">order_idx</a></td>
                          <td>
                            <div class="sale_info_group gap-3">
                              <span class="label-round-secondary">월세</span>
                              <p>보증금 1000<br>월세 50</p>
                            </div>
                          </td>
                          <td class="center">
                            <a href="sale/_id">mem_idx</a><br>
                            <a href="sale/_id">mem_id</a><br>
                            <a href="sale/_id">mem_name</a>
                          </td>
                          <td class="center">
                            서울특별시<br>
                            중구<br>
                            을지로동
                          </td>
                          <td class="center">
                            <p>2022-12-27</p><p>21:09:09</p>
                            
                          </td>
                          <td class="center">매칭중</td>
                          <td class="center">10</td>
                          
                          
                          <td class="center">
                            <a href="" class="btn btn-sm btn-outline-primary w-100 mb-2">
                              <span class="text">매칭현황</span>
                            </a>
                            <a href="" class="btn btn-sm btn-outline-secondary w-100">
                              <span class="text">매칭취소</span>
                            </a>
                          </td>
                        </tr>
                         
                        
                        <tr>
                          <td class="center">
                            <b-form-checkbox id="checkbox-1" v-model="status" name="checkbox-1" value="accepted"
                              unchecked-value="not_accepted">
                            </b-form-checkbox>
                          </td>
                          <td class="center"><a href="sale/_id">order_idx</a></td>
                          <td>
                            <div class="sale_info_group gap-3">
                              <span class="label-round-secondary">월세</span>
                              <p>보증금 1000<br>월세 50</p>
                            </div>
                          </td>
                          <td class="center">
                            <a href="sale/_id">mem_idx</a><br>
                            <a href="sale/_id">mem_id</a><br>
                            <a href="sale/_id">mem_name</a>
                          </td>
                          <td class="center">
                            서울특별시<br>
                            중구<br>
                            을지로동
                          </td>
                          <td class="center">
                            <p>2022-12-27</p><p>21:09:09</p>
                            
                          </td>
                          <td class="center">매칭중</td>
                          <td class="center">10</td>
                          
                          
                          <td class="center">
                            <a href="" class="btn btn-sm btn-outline-primary w-100 mb-2">
                              <span class="text">매칭현황</span>
                            </a>
                            <a href="" class="btn btn-sm btn-outline-secondary w-100">
                              <span class="text">매칭취소</span>
                            </a>
                          </td>
                        </tr>
                        <tr>
                          <td class="center">
                            <b-form-checkbox id="checkbox-1" v-model="status" name="checkbox-1" value="accepted"
                              unchecked-value="not_accepted">
                            </b-form-checkbox>
                          </td>
                          <td class="center"><a href="sale/_id">order_idx</a></td>
                          <td>
                            <div class="sale_info_group gap-3">
                              <span class="label-round-secondary">월세</span>
                              <p>보증금 1000<br>월세 50</p>
                            </div>
                          </td>
                          <td class="center">
                            <a href="sale/_id">mem_idx</a><br>
                            <a href="sale/_id">mem_id</a><br>
                            <a href="sale/_id">mem_name</a>
                          </td>
                          <td class="center">
                            서울특별시<br>
                            중구<br>
                            을지로동
                          </td>
                          <td class="center">
                            <p>2022-12-27</p><p>21:09:09</p>
                            
                          </td>
                          <td class="center">매칭중</td>
                          <td class="center">10</td>
                          
                          
                          <td class="center">
                            <a href="" class="btn btn-sm btn-outline-primary w-100 mb-2">
                              <span class="text">매칭현황</span>
                            </a>
                            <a href="" class="btn btn-sm btn-outline-secondary w-100">
                              <span class="text">매칭취소</span>
                            </a>
                          </td>
                        </tr>
                         
                      </tbody>
                    </table>
                  </div>
                </div>
                <div class="mx-auto overflow-auto">
                  <b-pagination-nav :link-gen="linkGen" :number-of-pages="10" use-router
                    class="my-4"></b-pagination-nav>
                </div>
              </div>
            </div>
            <!--tab content3 e-->
            </b-tab>

            <b-tab>
              <template #title>
                <p class="text-md font-weight-bold text-gray-500 text-uppercase mb-1">
                  매칭 확인</p>
                <h5 class="h5 mb-0 font-weight-bold text-gray-800">10 건</h5>
              </template>
              <!--tab content4 s-->
              <div>
              <!-- Search + Filter-->
              <div class="bg-white py-4 px-4 rounded mb-4 mt-4">
                <!--문의일-->
                <div class="d-flex gap-5 align-items-center pb-3">
                  <div class="admin-menu-title">
                    <h6 class="mb-0">문의일</h6>
                  </div>
                  <b-form-group v-slot="{ ariaDescribedby }">
                    <b-form-radio-group id="btn-radios-1" v-model="selected4" :options="options4"
                      :aria-describedby="ariaDescribedby" button-variant="outline-gray" class="h-48"
                      name="radios-btn-default" buttons></b-form-radio-group>
                  </b-form-group>
                  <div class="d-flex align-items-center gap-3">
                    <b-form-datepicker v-model="value" :min="min" :max="max" locale="kr"></b-form-datepicker>
                    <span>~</span>
                    <b-form-datepicker v-model="value" :min="min" :max="max" locale="kr"></b-form-datepicker>
                  </div>


                </div>

                <div class="d-flex gap-4 pb-4">
                  <!--등록자정보-->
                  <div class="d-flex gap-5 flex-basis-50 align-items-center">
                    <div class="admin-menu-title">
                      <h6 class="mb-0">등록자정보</h6>
                    </div>
                    <b-form-select v-model="selected2" :options="options2" class="w-20"></b-form-select>
                    <div class="input-group ">
                      <b-form-input v-model="text" placeholder="검색 입력"></b-form-input>
                    </div>
                  </div>

                  <!--거래유형-->
                  <div class="d-flex gap-5 flex-basis-50 align-items-center">
                    <div class="admin-menu-title">
                      <h6 class="mb-0">거래유형</h6>
                    </div>
                    <b-form-select v-model="selected3" :options="options3" class="w-20"></b-form-select>

                  </div>
                </div>
                <!--주문번호-->
                <div class="d-flex gap-5 align-items-center">
                  <div class="admin-menu-title">
                    <h6 class="mb-0">주문번호</h6>
                  </div>
                  <div class="input-group w-20">
                    <b-form-input v-model="text" placeholder="검색 입력"></b-form-input>
                  </div>
                </div>

                <!-- button-->

                <div class="d-flex justify-content-center gap-4">
                  <a href="#" class="btn btn-primary w-10">
                    <span class="text">조회</span>
                  </a>
                  <a href="#" class="btn btn-light w-10">
                    <span class="text">초기화</span>
                  </a>

                </div>
              </div>
              <!-- search+filter end-->
              <div class="mb-4 gap-4 d-flex justify-content-start"> 
                <a href="" class="btn btn-outline-danger">
                  <span class="text">체크된 주문/매칭 취소처리</span>
                </a>
              </div>
              <!-- table -->
              <div class="card shadow mb-4">

                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                      <thead>
                        <tr>
                          <th class="center">
                            <b-form-checkbox id="checkbox-1" v-model="status" name="checkbox-1" value="accepted"
                              unchecked-value="not_accepted">
                            </b-form-checkbox>
                          </th>
                          <th class="center">주문번호</th>
                          <th class="center">주문정보요약</th>
                          <th class="center">등록자정보</th>
                          <th class="center">주문자위치</th>
                          <th class="center">등록일</th>
                          <th class="center">주문상태</th>
                          <th class="center">중개사 조회 수</th>
                          <th class="center" width="10%">상태변경</th>
                        </tr>
                      </thead>

                      <tbody>

                        <tr>
                          <td class="center">
                            <b-form-checkbox id="checkbox-1" v-model="status" name="checkbox-1" value="accepted"
                              unchecked-value="not_accepted">
                            </b-form-checkbox>
                          </td>
                          <td class="center"><a href="sale/_id">order_idx</a></td>
                          <td>
                            <div class="sale_info_group gap-3">
                              <span class="label-round-secondary">월세</span>
                              <p>보증금 1000<br>월세 50</p>
                            </div>
                          </td>
                          <td class="center">
                            <a href="sale/_id">mem_idx</a><br>
                            <a href="sale/_id">mem_id</a><br>
                            <a href="sale/_id">mem_name</a>
                          </td>
                          <td class="center">
                            서울특별시<br>
                            중구<br>
                            을지로동
                          </td>
                          <td class="center">
                            <p>2022-12-27</p><p>21:09:09</p>
                            
                          </td>
                          <td class="center">매칭확인</td>
                          <td class="center">10</td>
                          
                          
                          <td class="center">
                            <a href="" class="btn btn-sm btn-outline-primary w-100 mb-2">
                              <span class="text">매칭현황</span>
                            </a> 
                            <a href="" class="btn btn-sm btn-outline-secondary w-100">
                              <span class="text">리뷰현황</span>
                            </a>
                          </td>
                        </tr>
                        
                      
                        <tr>
                          <td class="center">
                            <b-form-checkbox id="checkbox-1" v-model="status" name="checkbox-1" value="accepted"
                              unchecked-value="not_accepted">
                            </b-form-checkbox>
                          </td>
                          <td class="center"><a href="sale/_id">order_idx</a></td>
                          <td>
                            <div class="sale_info_group gap-3">
                              <span class="label-round-secondary">월세</span>
                              <p>보증금 1000<br>월세 50</p>
                            </div>
                          </td>
                          <td class="center">
                            <a href="sale/_id">mem_idx</a><br>
                            <a href="sale/_id">mem_id</a><br>
                            <a href="sale/_id">mem_name</a>
                          </td>
                          <td class="center">
                            서울특별시<br>
                            중구<br>
                            을지로동
                          </td>
                          <td class="center">
                            <p>2022-12-27</p><p>21:09:09</p>
                            
                          </td>
                          <td class="center">매칭확인</td>
                          <td class="center">10</td>
                          
                          
                          <td class="center">
                            <a href="" class="btn btn-sm btn-outline-primary w-100 mb-2">
                              <span class="text">매칭현황</span>
                            </a> 
                            <a href="" class="btn btn-sm btn-outline-secondary w-100">
                              <span class="text">리뷰현황</span>
                            </a>
                          </td>
                        </tr>
                        <tr>
                          <td class="center">
                            <b-form-checkbox id="checkbox-1" v-model="status" name="checkbox-1" value="accepted"
                              unchecked-value="not_accepted">
                            </b-form-checkbox>
                          </td>
                          <td class="center"><a href="sale/_id">order_idx</a></td>
                          <td>
                            <div class="sale_info_group gap-3">
                              <span class="label-round-secondary">월세</span>
                              <p>보증금 1000<br>월세 50</p>
                            </div>
                          </td>
                          <td class="center">
                            <a href="sale/_id">mem_idx</a><br>
                            <a href="sale/_id">mem_id</a><br>
                            <a href="sale/_id">mem_name</a>
                          </td>
                          <td class="center">
                            서울특별시<br>
                            중구<br>
                            을지로동
                          </td>
                          <td class="center">
                            <p>2022-12-27</p><p>21:09:09</p>
                            
                          </td>
                          <td class="center">매칭확인</td>
                          <td class="center">10</td>
                          
                          
                          <td class="center">
                            <a href="" class="btn btn-sm btn-outline-primary w-100 mb-2">
                              <span class="text">매칭현황</span>
                            </a> 
                            <a href="" class="btn btn-sm btn-outline-secondary w-100">
                              <span class="text">리뷰현황</span>
                            </a>
                          </td>
                        </tr>
                          
                      </tbody>
                    </table>
                  </div>
                </div>
                <div class="mx-auto overflow-auto">
                  <b-pagination-nav :link-gen="linkGen" :number-of-pages="10" use-router
                    class="my-4"></b-pagination-nav>
                </div>
              </div>
            </div>
            <!--tab content4 e-->
            </b-tab>

            <b-tab>
              <template #title>
                <p class="text-md font-weight-bold text-gray-500 text-uppercase mb-1">
                  주문/매칭 취소</p>
                <h5 class="h5 mb-0 font-weight-bold text-gray-800">1 건</h5>
              </template>
             <!--tab content5 s-->
             <div>
              <!-- Search + Filter-->
              <div class="bg-white py-4 px-4 rounded mb-4 mt-4">
                <!--문의일-->
                <div class="d-flex gap-5 align-items-center pb-3">
                  <div class="admin-menu-title">
                    <h6 class="mb-0">문의일</h6>
                  </div>
                  <b-form-group v-slot="{ ariaDescribedby }">
                    <b-form-radio-group id="btn-radios-1" v-model="selected4" :options="options4"
                      :aria-describedby="ariaDescribedby" button-variant="outline-gray" class="h-48"
                      name="radios-btn-default" buttons></b-form-radio-group>
                  </b-form-group>
                  <div class="d-flex align-items-center gap-3">
                    <b-form-datepicker v-model="value" :min="min" :max="max" locale="kr"></b-form-datepicker>
                    <span>~</span>
                    <b-form-datepicker v-model="value" :min="min" :max="max" locale="kr"></b-form-datepicker>
                  </div>


                </div>

                <div class="d-flex gap-4 pb-4">
                  <!--등록자정보-->
                  <div class="d-flex gap-5 flex-basis-50 align-items-center">
                    <div class="admin-menu-title">
                      <h6 class="mb-0">등록자정보</h6>
                    </div>
                    <b-form-select v-model="selected2" :options="options2" class="w-20"></b-form-select>
                    <div class="input-group ">
                      <b-form-input v-model="text" placeholder="검색 입력"></b-form-input>
                    </div>
                  </div>

                  <!--거래유형-->
                  <div class="d-flex gap-5 flex-basis-50 align-items-center">
                    <div class="admin-menu-title">
                      <h6 class="mb-0">거래유형</h6>
                    </div>
                    <b-form-select v-model="selected3" :options="options3" class="w-20"></b-form-select>

                  </div>
                </div>
                <!--주문번호-->
                <div class="d-flex gap-5 align-items-center">
                  <div class="admin-menu-title">
                    <h6 class="mb-0">주문번호</h6>
                  </div>
                  <div class="input-group w-20">
                    <b-form-input v-model="text" placeholder="검색 입력"></b-form-input>
                  </div>
                </div>

                <!-- button-->

                <div class="d-flex justify-content-center gap-4">
                  <a href="#" class="btn btn-primary w-10">
                    <span class="text">조회</span>
                  </a>
                  <a href="#" class="btn btn-light w-10">
                    <span class="text">초기화</span>
                  </a>

                </div>
              </div>
              <!-- search+filter end-->
              <div class="mb-4 gap-4 d-flex justify-content-start">
                <a href="#" class="btn btn-primary">
                  <span class="text">체크된 주문 재등록처리</span>
                </a> 
              </div>
              <!-- table -->
              <div class="card shadow mb-4">

                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                      <thead>
                        <tr>
                          <th class="center">
                            <b-form-checkbox id="checkbox-1" v-model="status" name="checkbox-1" value="accepted"
                              unchecked-value="not_accepted">
                            </b-form-checkbox>
                          </th>
                          <th class="center">주문번호</th>
                          <th class="center">주문정보요약</th>
                          <th class="center">등록자정보</th>
                          <th class="center">주문자위치</th>
                          <th class="center">등록일</th>
                          <th class="center">주문상태</th>
                          <th class="center">중개사 조회 수</th>
                          <th class="center" width="10%">상태변경</th>
                        </tr>
                      </thead>

                      <tbody>

                      
                        <tr>
                          <td class="center">
                            <b-form-checkbox id="checkbox-1" v-model="status" name="checkbox-1" value="accepted"
                              unchecked-value="not_accepted">
                            </b-form-checkbox>
                          </td>
                          <td class="center"><a href="sale/_id">order_idx</a></td>
                          <td>
                            <div class="sale_info_group gap-3">
                              <span class="label-round-secondary">월세</span>
                              <p>보증금 1000<br>월세 50</p>
                            </div>
                          </td>
                          <td class="center">
                            <a href="sale/_id">mem_idx</a><br>
                            <a href="sale/_id">mem_id</a><br>
                            <a href="sale/_id">mem_name</a>
                          </td>
                          <td class="center">
                            서울특별시<br>
                            중구<br>
                            을지로동
                          </td>
                          <td class="center">
                            <p>2022-12-27</p><p>21:09:09</p>
                            
                          </td>
                          <td class="center">취소</td>
                          <td class="center">-</td>
                          
                          
                          <td class="center">
                            <a href="" class="btn btn-sm btn-outline-success w-100 mb-2">
                              <span class="text">재등록</span>
                            </a>
                          </td>
                        </tr> 
                      </tbody>
                    </table>
                  </div>
                </div>
                <div class="mx-auto overflow-auto">
                  <b-pagination-nav :link-gen="linkGen" :number-of-pages="10" use-router
                    class="my-4"></b-pagination-nav>
                </div>
              </div>
            </div>
            <!--tab content5 e-->
            </b-tab>

            <b-tab>
              <template #title>
                <p class="text-md font-weight-bold text-gray-500 text-uppercase mb-1">
                  매칭 신고 접수</p>
                <h5 class="h5 mb-0 font-weight-bold text-gray-800">2 건</h5>
              </template>
              <!--tab content6 s-->
              <div>
              <!-- Search + Filter-->
              <div class="bg-white py-4 px-4 rounded mb-4 mt-4">
                <!--문의일-->
                <div class="d-flex gap-5 align-items-center pb-3">
                  <div class="admin-menu-title">
                    <h6 class="mb-0">문의일</h6>
                  </div>
                  <b-form-group v-slot="{ ariaDescribedby }">
                    <b-form-radio-group id="btn-radios-1" v-model="selected4" :options="options4"
                      :aria-describedby="ariaDescribedby" button-variant="outline-gray" class="h-48"
                      name="radios-btn-default" buttons></b-form-radio-group>
                  </b-form-group>
                  <div class="d-flex align-items-center gap-3">
                    <b-form-datepicker v-model="value" :min="min" :max="max" locale="kr"></b-form-datepicker>
                    <span>~</span>
                    <b-form-datepicker v-model="value" :min="min" :max="max" locale="kr"></b-form-datepicker>
                  </div>


                </div>

                <div class="d-flex gap-4 pb-4">
                  <!--등록자정보-->
                  <div class="d-flex gap-5 flex-basis-50 align-items-center">
                    <div class="admin-menu-title">
                      <h6 class="mb-0">등록자정보</h6>
                    </div>
                    <b-form-select v-model="selected2" :options="options2" class="w-20"></b-form-select>
                    <div class="input-group ">
                      <b-form-input v-model="text" placeholder="검색 입력"></b-form-input>
                    </div>
                  </div>

                  <!--거래유형-->
                  <div class="d-flex gap-5 flex-basis-50 align-items-center">
                    <div class="admin-menu-title">
                      <h6 class="mb-0">거래유형</h6>
                    </div>
                    <b-form-select v-model="selected3" :options="options3" class="w-20"></b-form-select>

                  </div>
                </div>
                <!--주문번호-->
                <div class="d-flex gap-5 align-items-center">
                  <div class="admin-menu-title">
                    <h6 class="mb-0">주문번호</h6>
                  </div>
                  <div class="input-group w-20">
                    <b-form-input v-model="text" placeholder="검색 입력"></b-form-input>
                  </div>
                </div>

                <!-- button-->

                <div class="d-flex justify-content-center gap-4">
                  <a href="#" class="btn btn-primary w-10">
                    <span class="text">조회</span>
                  </a>
                  <a href="#" class="btn btn-light w-10">
                    <span class="text">초기화</span>
                  </a>

                </div>
              </div>
              <!-- search+filter end-->
              <div class="mb-4 gap-4 d-flex justify-content-start">
                <a href="#" class="btn btn-primary">
                  <span class="text">체크된 매물 신고확인처리</span>
                </a>
                <a href="" class="btn btn-outline-secondary">
                  <span class="text">체크된 주문 재등록처리</span>
                </a>
              </div>
              <!-- table -->
              <div class="card shadow mb-4">

                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                      <thead>
                        <tr>
                          <th class="center">
                            <b-form-checkbox id="checkbox-1" v-model="status" name="checkbox-1" value="accepted"
                              unchecked-value="not_accepted">
                            </b-form-checkbox>
                          </th>
                          <th class="center">주문번호</th>
                          <th class="center">주문정보요약</th>
                          <th class="center">등록자정보</th>
                          <th class="center">주문자위치</th>
                          <th class="center">등록일</th>
                          <th class="center">주문상태</th>
                          <th class="center">중개사 조회 수</th>
                          <th class="center" width="10%">상태변경</th>
                        </tr>
                      </thead>

                      <tbody>

                        <tr>
                          <td class="center">
                            <b-form-checkbox id="checkbox-1" v-model="status" name="checkbox-1" value="accepted"
                              unchecked-value="not_accepted">
                            </b-form-checkbox>
                          </td>
                          <td class="center"><a href="sale/_id">order_idx</a></td>
                          <td>
                            <div class="sale_info_group gap-3">
                              <span class="label-round-secondary">월세</span>
                              <p>보증금 1000<br>월세 50</p>
                            </div>
                          </td>
                          <td class="center">
                            <a href="sale/_id">mem_idx</a><br>
                            <a href="sale/_id">mem_id</a><br>
                            <a href="sale/_id">mem_name</a>
                          </td>
                          <td class="center">
                            서울특별시<br>
                            중구<br>
                            을지로동
                          </td>
                          <td class="center">
                            <p>2022-12-27</p><p>21:09:09</p>
                            
                          </td>
                          <td class="center">신고접수</td>
                          <td class="center">10</td>
                          
                          
                          <td class="center">
                            <a href="" class="btn btn-sm btn-outline-danger w-100 mb-2">
                              <span class="text">신고확인</span>
                            </a> 
                          </td>
                        </tr>
                        <tr>
                          <td class="center">
                            <b-form-checkbox id="checkbox-1" v-model="status" name="checkbox-1" value="accepted"
                              unchecked-value="not_accepted">
                            </b-form-checkbox>
                          </td>
                          <td class="center"><a href="sale/_id">order_idx</a></td>
                          <td>
                            <div class="sale_info_group gap-3">
                              <span class="label-round-secondary">월세</span>
                              <p>보증금 1000<br>월세 50</p>
                            </div>
                          </td>
                          <td class="center">
                            <a href="sale/_id">mem_idx</a><br>
                            <a href="sale/_id">mem_id</a><br>
                            <a href="sale/_id">mem_name</a>
                          </td>
                          <td class="center">
                            서울특별시<br>
                            중구<br>
                            을지로동
                          </td>
                          <td class="center">
                            <p>2022-12-27</p><p>21:09:09</p>
                            
                          </td>
                          <td class="center">신고확인</td>
                          <td class="center">10</td>
                          
                          
                          <td class="center">
                            <a href="" class="btn btn-sm btn-outline-success w-100 mb-2">
                              <span class="text">재등록</span>
                            </a>
                            <a href="" class="btn btn-sm btn-outline-secondary w-100">
                              <span class="text">매칭취소</span>
                            </a>
                          </td>
                        </tr>
                         
                      </tbody>
                    </table>
                  </div>
                </div>
                <div class="mx-auto overflow-auto">
                  <b-pagination-nav :link-gen="linkGen" :number-of-pages="10" use-router
                    class="my-4"></b-pagination-nav>
                </div>
              </div>
            </div>
            <!--tab content6 e-->
            </b-tab>
          </b-tabs>


        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->


    </div>
    <!-- End of Content Wrapper -->



  </div>
</template>

<script>
export default {
  methods: {
    linkGen(pageNum) {
      return pageNum === 1 ? '?' : `?page=${pageNum}`
    }
  },
  data() {
    const now = new Date()
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())
    // 15th two months prior
    const minDate = new Date(today)
    minDate.setMonth(minDate.getMonth() - 2)
    minDate.setDate(15)
    // 15th in two months
    const maxDate = new Date(today)
    maxDate.setMonth(maxDate.getMonth() + 2)
    maxDate.setDate(15)

    return {
      // Note 'isActive' is left out and will not appear in the rendered table
      value: '',
      min: minDate,
      max: maxDate,
      status: 'not_accepted',

      fields: [
        {
          key: 'No',
          sortable: true
        },
        {
          key: '이름',
          sortable: true
        },
        {
          key: '업체이름',
          sortable: true,
          // Variant applies to the whole column, including the header and footer
        },
        {
          key: '회원유형',
          sortable: true
        },
        {
          key: '로그인방식',
          sortable: false
        },
        {
          key: '연락처',
          sortable: true
        },
        {
          key: '회원Email',
          sortable: true
        },
        {
          key: '가입일',
          sortable: true
        },
        {
          key: '상태',
          sortable: true
        }
      ],
      items: [
        { isActive: true, 상태: '등록', 가입일: '2022-12-20', 회원Email: 'testerkwon@gmail.com', 연락처: '010-2468-1234', 로그인방식: '카카오', 회원유형: '중개사회원', 업체이름: '연남동 명성 공인중개사사무소', 이름: '권오희', No: '1' },
        { isActive: true, 상태: '등록', 가입일: '2022-12-20', 회원Email: 'testerkwon@gmail.com', 연락처: '010-2468-1234', 로그인방식: '네이버', 회원유형: '중개사회원', 업체이름: '연남동 명성 공인중개사사무소', 이름: '권오희', No: '2' },
        { isActive: true, 상태: '등록', 가입일: '2022-12-20', 회원Email: 'testerkwon@gmail.com', 연락처: '010-2468-1234', 로그인방식: '카카오', 회원유형: '중개사회원', 업체이름: '연남동 명성 공인중개사사무소', 이름: '권오희', No: '3' },
        { isActive: true, 상태: '등록', 가입일: '2022-12-20', 회원Email: 'testerkwon@gmail.com', 연락처: '010-2468-1234', 로그인방식: '네이버', 회원유형: '중개사회원', 업체이름: '연남동 명성 공인중개사사무소', 이름: '권오희', No: '4' },
        { isActive: true, 상태: '등록', 가입일: '2022-12-20', 회원Email: 'testerkwon@gmail.com', 연락처: '010-2468-1234', 로그인방식: '카카오', 회원유형: '중개사회원', 업체이름: '연남동 명성 공인중개사사무소', 이름: '권오희', No: '5' },
        { isActive: true, 상태: '확인중', 가입일: '2022-12-20', 회원Email: 'testerkwon@gmail.com', 연락처: '010-2468-1234', 로그인방식: '네이버', 회원유형: '중개사회원', 업체이름: '연남동 명성 공인중개사사무소', 이름: '권오희', No: '6' },
        { isActive: true, 상태: '등록대기', 가입일: '2022-12-20', 회원Email: 'testerkwon@gmail.com', 연락처: '010-2468-1234', 로그인방식: '카카오', 회원유형: '중개사회원', 업체이름: '연남동 명성 공인중개사사무소', 이름: '권오희', No: '7' }
      ],
      selected: 10,
      options: [
        { value: '10', text: '10' },
        { value: '25', text: '25' },
        { value: '50', text: '50' },
        { value: '100', text: '100' }
      ],
      selected2: 'a',
      options2: [
        { value: 'a', text: '전체' },
        { value: 'b', text: '회원이메일' },
        { value: 'c', text: '회원이름 ' }
      ],
      selected3: 'e',
      options3: [
        { value: 'e', text: '전체' },
        { value: 'f', text: '전세' },
        { value: 'g', text: '월세' }
      ],
      selected4: '전체',
      options4: [
        { text: '전체', value: '전체' },
        { text: '오늘', value: '오늘' },
        { text: '3일', value: '3일' },
        { text: '1주일', value: '1주일' },
        { text: '1개월', value: '1개월' },
        { text: '3개월', value: '3개월' }
      ]
    }
  }
}
</script>
