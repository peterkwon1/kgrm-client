<template>

  <div id="app">
 
  
<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

<!-- Main Content -->
<div id="content">
  

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h4 mb-4 text-gray-800">회원관리 - 회원목록</h1>

        <!-- Table -->
        <div class="table_wrap">
            <div class="mb-3 d-flex justify-content-end align-items-center gap-3">
                <span>보여질 개수</span><b-form-select v-model="selected" :options="options" size="sm" class="w-10"></b-form-select>
            </div>
            <b-table striped hover :items="items" :fields="fields"></b-table>
            <div class="mx-auto overflow-auto">
            <b-pagination-nav :link-gen="linkGen" :number-of-pages="10" use-router class="mt-3"></b-pagination-nav>
        </div>
  </div>

    </div>
    <!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
 

</div>
<!-- End of Content Wrapper -->



  </div>
</template>

<script>
  export default {
    methods: {
      linkGen(pageNum) {
        return pageNum === 1 ? '?' : `?page=${pageNum}`
      }
    },
    data() {
      return {
        // Note 'isActive' is left out and will not appear in the rendered table
        fields: [
          {
            key: 'No',
            sortable: true
           },
          {
            key: '이름',
            sortable: true
          },
          {
            key: '닉네임',
            sortable: true,
            // Variant applies to the whole column, including the header and footer
          },
          {
            key: '회원유형',
            sortable: true
          },
          {
            key: '로그인방식',
            sortable: false
          },
          {
            key: '회원Email',
            sortable: true
          },
          {
            key: '가입일',
            sortable: true
          }
        ],
        items: [
          { isActive: true, 가입일:'2022-12-20', 회원Email:'tester01@gmail.com', 로그인방식: '카카오', 회원유형: '일반회원', 닉네임: 'BOOM', 이름: '차범근', No: '1' },
          { isActive: true, 가입일:'2022-12-20', 회원Email:'tester02@gmail.com',로그인방식: '네이버', 회원유형: '일반회원', 닉네임: 'DGDG', 이름: '이동국', No: '2' },
          { isActive: true, 가입일:'2022-12-20', 회원Email:'tester03@gmail.com',로그인방식: '카카오', 회원유형: '일반회원', 닉네임: 'MRAN', 이름: '안정환', No: '3' },
          { isActive: true, 가입일:'2022-12-20', 회원Email:'tester04@gmail.com',로그인방식: '네이버', 회원유형: '일반회원', 닉네임: 'SON7', 이름: '손흥민', No: '4' },
          { isActive: true, 가입일:'2022-12-20', 회원Email:'tester05@gmail.com', 로그인방식: '카카오', 회원유형: '일반회원', 닉네임: '10A', 이름: '박주영', No: '5' },
          { isActive: true, 가입일:'2022-12-20', 회원Email:'tester06@gmail.com',로그인방식: '네이버', 회원유형: '일반회원', 닉네임: 'GGG', 이름: '김승규', No: '6' },
          { isActive: true, 가입일:'2022-12-20', 회원Email:'tester07@gmail.com',로그인방식: '카카오', 회원유형: '일반회원', 닉네임: 'CHO', 이름: '조규성', No: '7' },
          { isActive: true, 가입일:'2022-12-20', 회원Email:'tester08@gmail.com',로그인방식: '네이버', 회원유형: '일반회원', 닉네임: 'SS', 이름: '이강인', No: '8' },
          { isActive: true, 가입일:'2022-12-20', 회원Email:'tester09@gmail.com', 로그인방식: '카카오', 회원유형: '일반회원', 닉네임: '달빛', 이름: '이승우', No: '9' },
          { isActive: true, 가입일:'2022-12-20', 회원Email:'tester10@gmail.com',로그인방식: '네이버', 회원유형: '일반회원', 닉네임: '황금', 이름: '이동욱', No: '10' },

        ],
        selected: 10,
        options: [
          { value: '10', text: '10' },
          { value: '25', text: '25' },
          { value: '50', text: '50' },
          { value: '100', text: '100' }
        ],
      }
    }
  }
</script>
