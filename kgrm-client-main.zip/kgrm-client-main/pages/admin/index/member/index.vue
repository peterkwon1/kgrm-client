<template>

    <div class="main-container">
  
  <!-- Page Wrapper -->
  <div id="wrapper">
    <!-- Sidebar -->
  <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
  
  <!-- Sidebar - Brand -->
  <a class="sidebar-brand d-flex align-items-center justify-content-center" href="main">
  
      <div class="sidebar-brand-text mx-3">KANGAROOM 관리자</div>
  </a>
  
  
  <!-- Nav Item - Dashboard -->
  <li class="nav-item">
      <a class="nav-link" href="main">
          <span class="material-symbols-outlined md-18">grid_view</span>
          <span>대시보드</span></a>
  </li>
  
  
  <!-- Nav Item - 회원 관리-->
  <li class="nav-item">
      <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#member"
         aria-expanded="true" aria-controls="member">
         <span class="material-symbols-outlined md-18">person</span>
          <span>회원 관리</span>
      </a>
      <div id="member" class="collapse show" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
              <a class="collapse-item active" href="member">회원목록</a>
              <a class="collapse-item" href="cards">탈퇴 회원목록</a>
          </div>
      </div>
  </li>
  
  <!-- Nav Item - 중개업체 관리 -->
  <li class="nav-item">
      <a class="nav-link collapsed" href="../broker"  >
          <span class="material-symbols-outlined md-18">manage_accounts</span>
          <span>중개업체 관리</span>
      </a>
  
  </li>
  
  <!-- Nav Item - 매물 관리 -->
  <li class="nav-item">
      <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#salepage"
         aria-expanded="true" aria-controls="salepage">
          <span class="material-symbols-outlined md-18">add_home</span>
          <span>매물 관리</span>
      </a>
      <div id="salepage" class="collapse" aria-labelledby="headingUtilities"
           data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
              <a class="collapse-item" href="sale">매물 목록</a>
              <a class="collapse-item" href="sale_submit">매물 등록</a>
          </div>
      </div>
  </li>
  
  
  <!-- Nav Item - 방찾기 관리 -->
  <li class="nav-item">
      <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#orderpage"
         aria-expanded="true" aria-controls="orderpage">
          <span class="material-symbols-outlined md-18">search</span>
          <span>방찾기 관리</span>
      </a>
      <div id="orderpage" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
              <a class="collapse-item" href="order">방 주문 목록</a>
              <a class="collapse-item" href="order">방찾기 리뷰 관리</a>
          </div>
      </div>
  </li>
  
  <!-- Nav Item - 고객센터 관리 -->
  <li class="nav-item">
      <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#cscenter"
         aria-expanded="true" aria-controls="cscenter">
          <span class="material-symbols-outlined md-18">support_agent</span>
          <span>고객센터 관리</span>
      </a>
      <div id="cscenter" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
              <a class="collapse-item" href="notice">공지사항 관리</a>
              <a class="collapse-item" href="faq">자주 묻는 질문 관리</a>
              <a class="collapse-item" href="qna">문의 관리</a>
          </div>
      </div>
  </li>
   
   
  
   
  
  
  </ul>
  <!-- End of Sidebar -->
    <div class="main-contents">
  
      <nav class="navbar navbar-expand navbar-light bg-lightg topbar static-top shadow">
      <!-- Topbar Navbar -->
      <ul class="navbar-nav ml-auto">
  
  <!-- Nav Item - User Information -->
  <li class="nav-item dropdown no-arrow">
      <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
          data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <span class="mr-2 d-none d-lg-inline text-gray-600 small">Kangaroom</span>
          <img class="img-profile rounded-circle"
          src="../../../../assets/img/icon/user.svg">
      </a>
      <!-- Dropdown - User Information -->
      <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
          aria-labelledby="userDropdown">
          <a class="dropdown-item" href="#">
              <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
              프로필
          </a>
          <a class="dropdown-item" href="#">
              <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
              설정
          </a>
          <a class="dropdown-item" href="#">
              <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
              활동 로그
          </a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
              <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
              로그아웃
          </a>
      </div>
  </li>
  
  </ul>
  
  </nav>
  <!-- End of Topbar -->
        <nuxt-child/>
      </div>
  
   
  </div>
  <!-- End of Page Wrapper -->
  
  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
  </a>
  
  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
      <div class="modal-content">
          <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">로그아웃</h5>
              <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span>
              </button>
          </div>
          <div class="modal-body">로그아웃 하시겠습니까?</div>
          <div class="modal-footer">
              <button class="btn btn-secondary" type="button" data-dismiss="modal">취소</button>
              <a class="btn btn-primary" href="login">로그아웃</a>
          </div>
      </div>
  </div>
  </div>
  
    </div>
  
  
  </template>
  
  
  