<template>
  <Nuxt/>
</template>
