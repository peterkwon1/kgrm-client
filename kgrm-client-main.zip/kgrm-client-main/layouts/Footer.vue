<template>
  <div class="footer">
    <h1>Footer</h1>
  </div>
</template>
<style scoped>
.footer {
  text-align: center;
  background-color: lightgray;
}
</style>