export const state = () => ({
  me: null,
});

export const mutations = {
  SET_USER(state, flag) {
    state.me = flag;
  },
  addNoticeItem(state,noticeItem){
    state.noticeList.push(noticeItem)
  },
};

export const actions = {
  async fetchUser({ commit }, token) {
    try {
      const { data } = await this.$axios({
        url: '/general/users/me',
        method: 'get',
        headers: { Authorization: `Bearer ${token}` },
      });
      commit('SET_USER', data);
    } catch (e) {
      throw e;
    }
  },
};
