export default {
  // Global page headers: https://go.nuxtjs.dev/config-head
  head: {
    titleTemplate: '%s - kgrm-client',
    title: 'KANGAROOM',
    htmlAttrs: {
      lang: 'en'
    },
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'viewport-fit=cover, width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no' },
      { hid: 'description', name: 'description', content: '' },
      { name: 'format-detection', content: 'telephone=no' }
    ],
    link: [
      { rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' },
      { rel: 'style', type: 'stylesheet', href: 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0' },
      { rel: 'style', type: 'stylesheet', href: 'https://fonts.googleapis.com/icon?family=Material+Icons' },
      { rel: 'style', type: 'text/css', href: 'https://cdn.jsdelivr.net/gh/orioncactus/pretendard/dist/web/variable/pretendardvariable.css' },
      { rel: 'style', type: 'text/css', href: 'https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.6/dist/web/static/pretendard.css' },
      { rel: 'style', type: 'text/css', href: 'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css' },
      { rel: 'style', type: 'text/css', href: 'https://unpkg.com/aos@2.3.1/dist/aos.css' }
    ],
    script: [
      { type: "text/javascript", src: "//t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js" },
      { type: 'text/javascript', src: 'https://code.jquery.com/jquery-1.12.4.min.js' },
    ]
  },

  // Global CSS: https://go.nuxtjs.dev/config-css
  css: [
  '~/assets/css/bootstrap.min.css',
  '~/assets/css/style.css',
  '~/assets/css/sb-admin-2.min.css',
  '~/assets/vendor/fontawesome-free/css/all.min.css',
  '~/assets/slick/slick.css',
  '~/assets/slick/slick-theme.css',
  'aos/dist/aos.css',
  'vue-slider-component/dist-css/vue-slider-component.css',
  'vue-slider-component/theme/default.css'
  ],



  // Plugins to run before rendering page: https://go.nuxtjs.dev/config-plugins
  plugins: [
    '@/plugins/axios',
    '@/plugins/vuex-router-sync',
    { src: '@/plugins/aos', ssr: false },
    { src: '@/plugins/vue-slider-component', ssr: false }
  ],

  // Auto import components: https://go.nuxtjs.dev/config-components
  components: true,

  // Modules for dev and build (recommended): https://go.nuxtjs.dev/config-modules
  buildModules: [
    // https://go.nuxtjs.dev/vuetify
  ],

  // Modules: https://go.nuxtjs.dev/config-modules
  modules: [
    '@nuxtjs/axios',
    'cookie-universal-nuxt',
    'bootstrap-vue/nuxt'
  ],
  axios: {
    baseURL: process.env.NODE_ENV === 'production' ? 'https://api.kangaroom.com' : 'http://localhost:8080',
    browserBaseURL: process.env.NODE_ENV === 'production' ? 'https://api.kangaroom.com' : 'http://localhost:8080',
  },

  // Build Configuration: https://go.nuxtjs.dev/config-build
  build: {
    vendor: ['aos']
  },

  router: {
    scrollBehavior: function (to, from, savedPosition) {
      return { x: 0, y: 0 }
    }
  }
}

