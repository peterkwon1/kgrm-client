$('#btn-favorite').on("click", function() {
    $('#favorive-star').css({ fill: "#7571FE", stroke: "#7571FE" });
});

$('#btn-favorite2').on("click", function() {
    $('#favorive-star2').css({ fill: "#7571FE", stroke: "#7571FE" });
});



function myFunction() {
  var x = document.getElementById("change_value");
  if (x.innerHTML === "대지면적 85.16㎡<br>연면적 58.35㎡") {
    x.innerHTML = "공급면적 34.41평<br>전용면적 25.65평";
  } else {
    x.innerHTML = "대지면적 85.16㎡<br>연면적 58.35㎡";
  }
}

const toastTrigger = document.getElementById('liveToastBtn')
const toastLiveExample = document.getElementById('liveToast')
if (toastTrigger) {
  toastTrigger.addEventListener('click', () => {
    const toast = new bootstrap.Toast(toastLiveExample)

    toast.show()
  })
}



$(window).on("scroll", function() {
    if($(window).scrollTop() > 50) {
        $(".sticky-header").addClass("active");
    } else {
        //remove the background property so it comes transparent again (defined in your css)
       $(".sticky-header").removeClass("active");
    }
});


$(document).ready(function() {
  $(".dropdown-toggle").click(function() {
    $(".caret").toggleClass('caret-up');
  });
});




$('.sort-date').click(function(){
   icon = $(this).find("i");
  icon.toggleClass("fa-arrow-up fa-arrow-down light_txt_grey")
})

$('.sort-size').click(function(){
   icon = $(this).find("i");
  icon.toggleClass("fa-arrow-up fa-arrow-down light_txt_grey")
})
$('.sort-amount').click(function(){
   icon = $(this).find("i");
  icon.toggleClass("fa-arrow-up fa-arrow-down light_txt_grey")
})

$('#remove').click( function() {
        $( 'i' ).removeClass( 'fa-arrow-down light_txt_grey' );
        $( 'i' ).addClass("fa-arrow-up");
       });





(function () {
            'use strict';

            var init = function () {

            var slider2 = new rSlider({
                      target: '#slider2',
                      values: {min: 0, max: 400},
                       step: 10,
                       range: true,
                       set: [0, 60],
                       scale: false,
                       labels: false,
                       onChange: function (vals) {
                       console.log(vals);
                       }
                       });

                var slider3 = new rSlider({
                    target: '#slider3',
                    values: {min: 0, max: 15000},
                    step: 1000,
                    range: true,
                    set: [0, 5000],
                    scale: false,
                    labels: false,
                    onChange: function (vals) {
                        console.log(vals);
                    }
                });

                var slider = new rSlider({
                    target: '#slider',
                    values: [2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015],
                    range: true,
                    set: [2010, 2013],
                    onChange: function (vals) {
                        console.log(vals);
                    }
                });
            };
            window.onload = init;
        })();